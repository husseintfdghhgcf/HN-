import json, time
from decimal import Decimal

import httpx
import pytest
from sqlalchemy import select

from app.adapters.azure import AzureRetailAdapter
from app.adapters.base import PricingAdapter, NormalizedPrice, TransientFetchError, PermanentFetchError
from app.adapters.gcp import GcpBillingAdapter
from app.core.config import get_settings
from app.core.permissions import ADMIN, CUSTOMER, SUPER_ADMIN
from app.db.session import SessionLocal
from app.models import AutomationRun, Notification, PricingRecord, PricingSource, SyncRun, User
from app.seed import seed_pricing_sources
from app.services import ai as ai_service
from app.services.n8n import sign
from app.services.pricing_sync import run_sync
from tests.conftest import make_user
from tests.test_evaluations import body
from app.sample_data import seed_sample_data


@pytest.fixture(autouse=True)
def sources():
    with SessionLocal() as db:
        seed_pricing_sources(db)
        db.commit()


def azure_payload(price=0.2, n=1):
    return {"Items": [{"retailPrice": price, "currencyCode": "USD", "unitOfMeasure": "1 Hour", "armRegionName": "westeurope",
                       "productName": "Virtual Machines Dsv3 Series", "skuName": "D4s v3", "skuId": f"S{i}",
                       "effectiveStartDate": "2026-01-01T00:00:00Z"} for i in range(n)], "NextPageLink": None}


def azure_client(payload=None, status=200, fail_times=0):
    calls = {"n": 0}

    def handler(req):
        calls["n"] += 1
        if calls["n"] <= fail_times:
            return httpx.Response(503)
        if status != 200:
            return httpx.Response(status)
        return httpx.Response(200, json=payload if payload is not None else azure_payload())
    return httpx.Client(transport=httpx.MockTransport(handler)), calls


def test_sync_stores_valid_prices_with_provenance_and_history():
    c, _ = azure_client()
    with SessionLocal() as db:
        run = run_sync(db, AzureRetailAdapter(), client=c)
        assert run.status == "success" and run.records_stored >= 1
        rec = db.scalar(select(PricingRecord))
        assert rec.price == Decimal("0.2") and rec.is_sample is False and rec.source_identifier.startswith("S")
        c2, _ = azure_client(azure_payload(price=0.25))
        run_sync(db, AzureRetailAdapter(), client=c2)
        rows = db.scalars(select(PricingRecord)).all()   # mock serves all 4 regions: 4 old + 4 new rows
        assert len(rows) == 8 and {r.price for r in rows} == {Decimal('0.2'), Decimal('0.25')}  # history kept


def test_unchanged_price_not_duplicated_within_24h():
    with SessionLocal() as db:
        run_sync(db, AzureRetailAdapter(), client=azure_client()[0])
        first = len(db.scalars(select(PricingRecord)).all())
        assert first == 4
        run_sync(db, AzureRetailAdapter(), client=azure_client()[0])
        assert len(db.scalars(select(PricingRecord)).all()) == first


@pytest.mark.parametrize("payload", [{"Items": []}, azure_payload(price=-1), azure_payload(price=0)])
def test_empty_or_invalid_responses_never_replace_valid_data(payload):
    with SessionLocal() as db:
        run_sync(db, AzureRetailAdapter(), client=azure_client()[0])
        before = len(db.scalars(select(PricingRecord)).all())
        run = run_sync(db, AzureRetailAdapter(), client=azure_client(payload)[0])
        assert run.status == "rejected" and len(db.scalars(select(PricingRecord)).all()) == before


def test_transient_failures_retry_with_bounded_backoff():
    sleeps = []
    c, calls = azure_client(fail_times=2)
    with SessionLocal() as db:
        run = run_sync(db, AzureRetailAdapter(), client=c, sleep=sleeps.append)
    assert run.status == "success" and sleeps == [1.0, 2.0]
    c, calls = azure_client(status=503)
    with SessionLocal() as db:
        run = run_sync(db, AzureRetailAdapter(), client=c, sleep=lambda s: None)
    assert run.status == "failed" and calls["n"] == get_settings().pricing_max_retries


def test_permanent_error_not_retried():
    c, calls = azure_client(status=404)
    with SessionLocal() as db:
        run = run_sync(db, AzureRetailAdapter(), client=c, sleep=lambda s: pytest.fail("must not retry"))
    assert run.status == "failed" and "404" in run.error_summary


def test_gcp_without_key_reports_not_configured_and_stores_nothing():
    with SessionLocal() as db:
        run = run_sync(db, GcpBillingAdapter(), client=httpx.Client())
        assert run.status == "failed" and "GCP_BILLING_API_KEY" in run.error_summary
        assert db.scalar(select(PricingRecord)) is None


def test_gcp_normalization_from_documented_schema(monkeypatch):
    monkeypatch.setattr(get_settings(), "gcp_billing_api_key", "k")
    def sku(desc, group, nanos, sid):
        return {"skuId": sid, "description": desc, "category": {"usageType": "OnDemand", "resourceGroup": group},
                "serviceRegions": ["europe-west1"], "pricingInfo": [{"pricingExpression": {"tieredRates": [{"unitPrice": {"units": "0", "nanos": nanos}}]}}]}
    payload = {"skus": [sku("E2 Instance Core running in Belgium", "CPU", 20000000, "c1"), sku("E2 Instance Ram running in Belgium", "RAM", 3000000, "r1"),
                        sku("E2 Custom Instance Core running in Belgium", "CPU", 1, "x")]}
    client = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(200, json=payload)))
    rows = GcpBillingAdapter().fetch(client)
    assert len(rows) == 1 and rows[0].price == Decimal("0.02") * 4 + Decimal("0.003") * 16


# ---------------- admin
def test_admin_pricing_endpoints_and_stale_detection(make_client):
    c, h = make_client("adm@x.com", ADMIN)
    items = c.get("/api/v1/admin/pricing/sources", headers=h).json()["items"]
    gcp = next(i for i in items if i["key"].startswith("gcp"))
    assert gcp["stale"] is True and "CONFIGURATION REQUIRED" in gcp["status_note"]
    assert c.post("/api/v1/admin/pricing/sources/nope/sync", headers=h).status_code == 404
    cust, hc = make_client("cu@x.com", CUSTOMER)
    assert cust.get("/api/v1/admin/pricing/sources", headers=hc).status_code == 403
    assert cust.post("/api/v1/admin/pricing/sources/azure-retail-prices/sync", headers=hc).status_code == 403
    r = c.post("/api/v1/admin/pricing/sources/gcp-cloud-billing-catalog/sync", headers=h)
    assert r.status_code == 200 and r.json()["status"] == "failed"
    assert c.get("/api/v1/admin/pricing/sync-runs", headers=h).json()["total"] == 1


def test_user_management_role_rules(make_client):
    adm, ha = make_client("a@x.com", ADMIN)
    sup, hs = make_client("s@x.com", SUPER_ADMIN)
    cid = make_user("c@x.com", CUSTOMER)
    aid = make_user("a2@x.com", ADMIN)
    pw = "Str0ngPassw0rd!"
    assert adm.post("/api/v1/admin/users", json={"email": "n@x.com", "password": pw, "role": "admin"}, headers=ha).status_code == 403
    assert adm.post("/api/v1/admin/users", json={"email": "n@x.com", "password": pw, "role": "customer"}, headers=ha).status_code == 201
    assert adm.patch(f"/api/v1/admin/users/{cid}", json={"is_active": False}, headers=ha).status_code == 200
    assert adm.patch(f"/api/v1/admin/users/{aid}", json={"is_active": False}, headers=ha).status_code == 403
    assert adm.patch(f"/api/v1/admin/users/{cid}", json={"role": "admin"}, headers=ha).status_code == 403   # roles: super only
    assert all(u["role"] == "customer" for u in adm.get("/api/v1/admin/users", headers=ha).json()["items"])
    assert sup.patch(f"/api/v1/admin/users/{cid}", json={"role": "admin"}, headers=hs).json()["role"] == "admin"
    me = sup.get("/api/v1/auth/me").json()["user"]["id"]
    assert sup.patch(f"/api/v1/admin/users/{me}", json={"role": "customer"}, headers=hs).status_code == 409
    assert sup.get("/api/v1/admin/audit", headers=hs).status_code == 200
    assert adm.get("/api/v1/admin/audit", headers=ha).status_code == 403
    assert adm.get("/api/v1/admin/health", headers=ha).status_code == 403
    h = sup.get("/api/v1/admin/health", headers=hs).json()
    assert h["database"] == "ok" and "secret" not in json.dumps(h).lower() and h["ai_configured"] is False


def test_deactivated_user_session_stops_working(make_client):
    sup, hs = make_client("s@x.com", SUPER_ADMIN)
    victim, hv = make_client("v@x.com")
    vid = victim.get("/api/v1/auth/me").json()["user"]["id"]
    sup.patch(f"/api/v1/admin/users/{vid}", json={"is_active": False}, headers=hs)
    assert victim.get("/api/v1/auth/me").status_code == 401


# ---------------- AI
@pytest.fixture
def ai_on(monkeypatch):
    s = get_settings()
    monkeypatch.setattr(s, "ai_api_key", "sk-test"); monkeypatch.setattr(s, "ai_model", "m"); monkeypatch.setattr(s, "ai_provider", "anthropic")


def test_ai_disabled_app_still_works(make_client):
    with SessionLocal() as db:
        seed_sample_data(db); db.commit()
    c, h = make_client("u@x.com")
    ev = c.post("/api/v1/evaluations", json=body(), headers=h).json()
    assert c.post(f"/api/v1/evaluations/{ev['id']}/ai-explanation", headers=h).status_code == 503
    assert c.get("/api/v1/ai/availability", headers=h).json() == {"available": False}


def test_ai_status_never_exposes_key(make_client, ai_on):
    sup, hs = make_client("s@x.com", SUPER_ADMIN)
    r = sup.get("/api/v1/ai/status", headers=hs)
    assert "sk-test" not in r.text and r.json()["configured"] is True
    cust, hc = make_client("c@x.com")
    assert cust.get("/api/v1/ai/status", headers=hc).status_code == 403


def test_grounding_check():
    facts = {"ranking": [{"rank": 1, "closeness": 0.6271}], "x": "cost 146 USD"}
    assert ai_service.check_grounded("Rank 1 with closeness 0.63 and 146 USD", facts)
    assert not ai_service.check_grounded("It costs 99 USD", facts)


def test_ai_explanation_grounded_and_ungrounded(make_client, ai_on, monkeypatch):
    with SessionLocal() as db:
        seed_sample_data(db); db.commit()
    c, h = make_client("u@x.com")
    ev = c.post("/api/v1/evaluations", json=body(), headers=h).json()
    top = next(r for r in ev["results"] if r["rank"] == 1)
    monkeypatch.setattr(ai_service, "complete", lambda s, u, client=None, sleep=None: f"{top['provider_name']} ranks 1.")
    r = c.post(f"/api/v1/evaluations/{ev['id']}/ai-explanation", headers=h)
    assert r.status_code == 200
    assert c.get(f"/api/v1/evaluations/{ev['id']}/explanation", headers=h).json()["ai"]["text"]
    monkeypatch.setattr(ai_service, "complete", lambda s, u, client=None, sleep=None: "AWS costs 12345 USD")
    assert c.post(f"/api/v1/evaluations/{ev['id']}/ai-explanation", headers=h).status_code == 422
    # scores unchanged by AI
    assert c.get(f"/api/v1/evaluations/{ev['id']}", headers=h).json()["results"] == ev["results"]


def test_ai_provider_failures_are_generic_and_retried(ai_on):
    seen = []
    def handler(req):
        seen.append(1)
        return httpx.Response(500, text="secret sk-test leaked")
    client = httpx.Client(transport=httpx.MockTransport(handler))
    with pytest.raises(ai_service.AiError) as e:
        ai_service.complete("s", "u", client, sleep=lambda x: None)
    assert e.value.category == "provider_error" and len(seen) == get_settings().ai_max_retries + 1 and "sk-test" not in str(e.value)
    c2 = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(401)))
    with pytest.raises(ai_service.AiError) as e:
        ai_service.complete("s", "u", c2, sleep=lambda x: None)
    assert e.value.category == "auth"


# ---------------- webhooks
def signed(client, path, payload, secret="test-webhook-secret", ts=None, method="post"):
    raw = json.dumps(payload).encode()
    ts = str(ts if ts is not None else int(time.time()))
    headers = {"X-Timestamp": ts, "X-Signature": sign(secret, ts, raw), "Content-Type": "application/json"}
    return client.request(method, f"/api/v1/webhooks/n8n/{path}", content=raw, headers=headers)


def test_webhook_authentication(client):
    p = {"event_id": "evt-000001", "user_id": "x", "title": "t"}
    assert client.post("/api/v1/webhooks/n8n/notify", json=p).status_code == 401
    assert signed(client, "notify", p, secret="wrong").status_code == 401
    assert signed(client, "notify", p, ts=int(time.time()) - 3600).status_code == 401   # replay window
    assert signed(client, "notify", p).status_code == 404   # signature OK, user unknown


def test_webhook_notify_dedupe_and_correct_user(client):
    uid = make_user("w@x.com"); other = make_user("o@x.com")
    p = {"event_id": "evt-000002", "user_id": uid, "title": "Done", "body": "b"}
    assert signed(client, "notify", p).json()["status"] == "processed"
    assert signed(client, "notify", p).json()["status"] == "duplicate"
    with SessionLocal() as db:
        assert len(db.scalars(select(Notification).where(Notification.user_id == uid)).all()) == 1
        assert db.scalar(select(Notification).where(Notification.user_id == other)) is None


def test_webhook_report_owner_check_and_idempotency(client, make_client):
    with SessionLocal() as db:
        seed_sample_data(db); db.commit()
    c, h = make_client("r@x.com")
    ev = c.post("/api/v1/evaluations", json=body(), headers=h).json()
    uid = c.get("/api/v1/auth/me").json()["user"]["id"]
    bad = {"event_id": "evt-000003", "evaluation_id": ev["id"], "user_id": make_user("z@x.com")}
    assert signed(client, "report", bad).status_code == 404
    good = {"event_id": "evt-000004", "evaluation_id": ev["id"], "user_id": uid}
    r = signed(client, "report", good).json()
    assert r["status"] == "processed" and r["ai_summary"] == "not_configured"
    assert signed(client, "report", good).json()["status"] == "duplicate"
    assert c.get("/api/v1/reports", headers=h).json()["total"] == 1


def test_webhook_pricing_status_and_alert(client):
    make_user("adm@x.com", ADMIN)
    st = signed(client, "pricing-status", {}, method="get").json()
    assert st["ok"] is False and st["problems"]
    a = {"event_id": "evt-000005", "summary": "azure sync failed 3 times"}
    assert signed(client, "admin-alert", a).json()["notified"] == 1
    assert signed(client, "admin-alert", a).json()["status"] == "duplicate"
    with SessionLocal() as db:
        assert "secret" not in db.scalar(select(Notification)).body.lower()


def test_webhook_pricing_sync_event(client, monkeypatch):
    import app.api.v1.webhooks as wh
    from app.adapters.registry import ADAPTERS
    monkeypatch.setattr(ADAPTERS["azure-retail-prices"], "fetch", lambda c: [])
    p = {"event_id": "evt-000006", "source_key": "azure-retail-prices"}
    r = signed(client, "pricing-sync", p).json()
    assert r["status"] == "rejected"          # empty result rejected, nothing stored
    assert signed(client, "pricing-sync", p).json()["status"] == "duplicate"
    assert signed(client, "pricing-sync", {"event_id": "evt-000007", "source_key": "nope"}).status_code == 404


def test_gemini_request_shape_key_in_header_not_url(monkeypatch):
    s = get_settings()
    monkeypatch.setattr(s, "ai_provider", "gemini"); monkeypatch.setattr(s, "ai_api_key", "KEY-XYZ"); monkeypatch.setattr(s, "ai_model", "some-model")
    seen = {}
    def handler(req):
        seen["url"], seen["key"], seen["body"] = str(req.url), req.headers.get("x-goog-api-key"), json.loads(req.content)
        return httpx.Response(200, json={"candidates": [{"content": {"parts": [{"text": "hello 1"}]}}]})
    out = ai_service.complete("sys", "usr", httpx.Client(transport=httpx.MockTransport(handler)))
    assert out == "hello 1" and seen["key"] == "KEY-XYZ" and "KEY-XYZ" not in seen["url"]
    assert seen["url"].endswith("/models/some-model:generateContent")
    assert seen["body"]["systemInstruction"]["parts"][0]["text"] == "sys"


def test_login_and_me_return_csrf_token_usable_cross_origin(client):
    make_user("cs@x.com")
    r = client.post("/api/v1/auth/login", json={"email": "cs@x.com", "password": "Str0ngPassw0rd!"})
    tok = r.json()["csrf_token"]
    assert client.get("/api/v1/auth/me").json()["csrf_token"] == tok
    assert client.patch("/api/v1/auth/me", json={"full_name": "Z"}, headers={"X-CSRF-Token": tok}).status_code == 200

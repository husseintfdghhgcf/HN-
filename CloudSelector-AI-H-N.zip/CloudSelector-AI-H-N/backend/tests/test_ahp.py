import math

import pytest

from app.engine.ahp import (AhpValidationError, InconsistentMatrixError, compute_ahp, explain_weights,
                            matrix_from_upper)


def test_perfectly_consistent_matrix_recovers_exact_weights():
    w = [0.5, 0.3, 0.2]
    m = [[wi / wj for wj in w] for wi in w]
    r = compute_ahp(["a", "b", "c"], m)
    assert r.weights == pytest.approx(w, abs=1e-9)
    assert r.lambda_max == pytest.approx(3.0, abs=1e-9)
    assert r.consistency_index == pytest.approx(0, abs=1e-9)
    assert r.consistent


def test_classic_saaty_example_matches_published_values():
    m = [[1, 3, 5], [1 / 3, 1, 3], [1 / 5, 1 / 3, 1]]
    r = compute_ahp(["a", "b", "c"], m)
    assert r.weights == pytest.approx([0.6370, 0.2583, 0.1047], abs=5e-4)
    assert r.lambda_max == pytest.approx(3.0385, abs=5e-4)
    assert r.consistency_index == pytest.approx(0.01926, abs=5e-4)
    assert r.consistency_ratio == pytest.approx(0.0332, abs=5e-4)  # CI / RI(3)=0.58
    assert sum(r.weights) == pytest.approx(1.0)


def test_weights_agree_with_independent_power_iteration():
    m = [[1, 2, 4, 3], [1 / 2, 1, 3, 2], [1 / 4, 1 / 3, 1, 1 / 2], [1 / 3, 1 / 2, 2, 1]]
    v = [1.0] * 4
    for _ in range(500):  # pure-python power iteration, independent of numpy.linalg
        nv = [sum(m[i][j] * v[j] for j in range(4)) for i in range(4)]
        s = sum(nv)
        v = [x / s for x in nv]
    r = compute_ahp(list("abcd"), m)
    assert r.weights == pytest.approx(v, abs=1e-8)


def test_inconsistent_matrix_is_flagged_not_corrected():
    # a>b, b>c strongly but c>a: cyclic judgements
    m = [[1, 9, 1 / 9], [1 / 9, 1, 9], [9, 1 / 9, 1]]
    r = compute_ahp(list("abc"), m)
    assert not r.consistent and r.consistency_ratio > 0.10
    with pytest.raises(InconsistentMatrixError) as e:
        compute_ahp(list("abc"), m, enforce_consistency=True)
    assert e.value.result.consistency_ratio == r.consistency_ratio  # original input, unchanged


@pytest.mark.parametrize("bad", [
    [[1, 2], [3, 1]],                 # not reciprocal
    [[1, 2, 3], [0.5, 1, 2]],         # not square
    [[2, 1], [1, 2]],                 # diagonal != 1
    [[1, 0], [0, 1]],                 # zeros
    [[1, -2], [-0.5, 1]],             # negatives
    [[1, float("nan")], [1, 1]],      # NaN
    [[1, 10], [0.1, 1]],              # outside 1/9..9
    [],                               # empty
    "abc",
])
def test_invalid_matrices_rejected(bad):
    with pytest.raises(AhpValidationError):
        compute_ahp(["a", "b"], bad)


def test_criteria_count_must_match_and_be_unique():
    with pytest.raises(AhpValidationError):
        compute_ahp(["a"], [[1, 2], [0.5, 1]])
    with pytest.raises(AhpValidationError):
        compute_ahp(["a", "a"], [[1, 2], [0.5, 1]])


def test_order_two_always_consistent_and_exact():
    r = compute_ahp(["a", "b"], [[1, 3], [1 / 3, 1]])
    assert r.weights == pytest.approx([0.75, 0.25])
    assert r.consistency_ratio == 0 and r.consistent


def test_single_criterion():
    assert compute_ahp(["a"], [[1]]).weights == [1.0]


def test_matrix_from_upper_triangle():
    m = matrix_from_upper(3, {(0, 1): 3, (0, 2): 5, (1, 2): 3})
    assert m[1][0] == pytest.approx(1 / 3) and m[2][1] == pytest.approx(1 / 3)
    with pytest.raises(AhpValidationError):
        matrix_from_upper(3, {(0, 1): 3})


def test_explanation_mentions_every_criterion_and_cr():
    r = compute_ahp(list("abc"), [[1, 3, 5], [1 / 3, 1, 3], [1 / 5, 1 / 3, 1]])
    text = " ".join(explain_weights(r))
    assert all(f"'{k}'" in text for k in "abc") and "CR" in text and "consistent" in text

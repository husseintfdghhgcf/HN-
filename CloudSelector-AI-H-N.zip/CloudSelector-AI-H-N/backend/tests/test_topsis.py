import math

import pytest

from app.engine.topsis import Measurement, TopsisValidationError, prepare_decision_matrix, topsis

X = [[400, 80, 3], [300, 70, 4], [350, 90, 5]]
W = [0.5, 0.3, 0.2]
KINDS = ["cost", "benefit", "benefit"]


def test_matches_hand_calculated_reference():
    r = topsis(["A", "B", "C"], ["cost", "perf", "sec"], X, W, KINDS)
    assert r.d_plus == pytest.approx([0.101859, 0.051533, 0.040962], abs=1e-6)
    assert r.d_minus == pytest.approx([0.021539, 0.086668, 0.082058], abs=1e-6)
    assert r.closeness == pytest.approx([0.174547, 0.627116, 0.667032], abs=1e-6)
    assert r.ranks == [3, 2, 1]
    assert r.ranking() == ["C", "B", "A"]


def test_dominating_alternative_has_closeness_one_and_dominated_zero():
    r = topsis(["A", "B"], ["x", "y"], [[10, 10], [5, 5]], [0.5, 0.5], ["benefit", "benefit"])
    assert r.closeness == pytest.approx([1.0, 0.0])
    assert r.ranks == [1, 2]


def test_cost_direction_is_reversed():
    benefit = topsis(["A", "B"], ["x"], [[10], [5]], [1.0], ["benefit"])
    cost = topsis(["A", "B"], ["x"], [[10], [5]], [1.0], ["cost"])
    assert benefit.ranking() == ["A", "B"] and cost.ranking() == ["B", "A"]


def test_normalization_columns_have_unit_norm():
    r = topsis(["A", "B", "C"], ["c", "p", "s"], X, W, KINDS)
    for j in range(3):
        assert math.sqrt(sum(row[j] ** 2 for row in r.normalized)) == pytest.approx(1.0)


def test_closeness_bounded_and_scale_invariant():
    a = topsis(["A", "B", "C"], ["c", "p", "s"], X, W, KINDS)
    scaled = [[row[0] * 1000, row[1], row[2] * 7] for row in X]  # unit rescaling must not change ranking
    b = topsis(["A", "B", "C"], ["c", "p", "s"], scaled, W, KINDS)
    assert all(0 <= c <= 1 for c in a.closeness)
    assert a.closeness == pytest.approx(b.closeness, abs=1e-9)


def test_ranking_depends_on_weights_not_hardcoded():
    cost_heavy = topsis(["A", "B", "C"], ["c", "p", "s"], X, [0.9, 0.05, 0.05], KINDS).ranking()
    sec_heavy = topsis(["A", "B", "C"], ["c", "p", "s"], X, [0.05, 0.05, 0.9], KINDS).ranking()
    assert cost_heavy[0] == "B" and sec_heavy[0] == "C" and cost_heavy != sec_heavy


def test_identical_alternatives_tie_with_note():
    r = topsis(["A", "B"], ["x"], [[5], [5]], [1.0], ["benefit"])
    assert r.ranks == [1, 1] and r.closeness == [0.5, 0.5] and r.notes


def test_zero_column_noted_not_crashing():
    r = topsis(["A", "B"], ["x", "z"], [[1, 0], [2, 0]], [0.5, 0.5], ["benefit", "benefit"])
    assert any("'z'" in n for n in r.notes) and r.ranking() == ["B", "A"]


@pytest.mark.parametrize("args", [
    (["A"], ["x"], [[1]], [1.0], ["benefit"]),                                 # one alternative
    (["A", "B"], ["x"], [[1], [2]], [0.5], ["benefit"]),                       # weights length
    (["A", "B"], ["x"], [[1], [2]], [0.5], ["benefit"]),
    (["A", "B"], ["x"], [[1], [float("nan")]], [1.0], ["benefit"]),            # NaN
    (["A", "B"], ["x"], [[1], [-2]], [1.0], ["benefit"]),                      # negative
    (["A", "B"], ["x"], [[1], [2]], [0.7], ["benefit"]),                       # weights != 1
    (["A", "B"], ["x"], [[1], [2]], [1.0], ["good"]),                          # bad kind
    (["A", "A"], ["x"], [[1], [2]], [1.0], ["benefit"]),                       # duplicate ids
    (["A", "B"], ["x"], [[1, 2], [2, 3]], [1.0], ["benefit"]),                 # shape
])
def test_invalid_inputs_rejected(args):
    with pytest.raises(TopsisValidationError):
        topsis(*args)


# ---- decision matrix preparation: missing / incomparable data
def _data(**over):
    base = {
        "aws": {"cost": Measurement(100, "USD/month"), "perf": Measurement(80, "score")},
        "azure": {"cost": Measurement(90, "USD/month"), "perf": Measurement(70, "score")},
        "gcp": {"cost": Measurement(95, "USD/month"), "perf": Measurement(None, "score")},
    }
    base.update(over)
    return base


def test_missing_data_excludes_alternative_transparently():
    p = prepare_decision_matrix(["aws", "azure", "gcp"], ["cost", "perf"], ["cost", "benefit"], [0.5, 0.5], _data())
    assert p.alternatives == ["aws", "azure"] and "gcp" in p.excluded and "perf" in p.excluded["gcp"]
    assert p.weights == [0.5, 0.5] and p.notes


def test_drop_criterion_policy_renormalises_weights_and_records_it():
    p = prepare_decision_matrix(["aws", "azure", "gcp"], ["cost", "perf"], ["cost", "benefit"], [0.25, 0.75],
                                _data(), missing_policy="drop_criterion")
    assert p.criteria == ["cost"] and p.weights == [1.0] and "perf" in p.dropped_criteria
    assert p.alternatives == ["aws", "azure", "gcp"] and any("renormalised" in n for n in p.notes)


def test_incomparable_units_raise_instead_of_converting():
    d = _data(azure={"cost": Measurement(90, "EUR/month"), "perf": Measurement(70, "score")})
    with pytest.raises(TopsisValidationError, match="Incomparable units"):
        prepare_decision_matrix(["aws", "azure"], ["cost", "perf"], ["cost", "benefit"], [0.5, 0.5], d)


def test_invalid_values_treated_as_missing():
    d = _data(gcp={"cost": Measurement(-5, "USD/month"), "perf": Measurement(float("inf"), "score")})
    p = prepare_decision_matrix(["aws", "azure", "gcp"], ["cost", "perf"], ["cost", "benefit"], [0.5, 0.5], d)
    assert "gcp" in p.excluded


def test_all_criteria_missing_is_an_error():
    d = {"a": {"x": Measurement(None)}, "b": {"x": Measurement(None)}}
    with pytest.raises(TopsisValidationError):
        prepare_decision_matrix(["a", "b"], ["x"], ["benefit"], [1.0], d, missing_policy="drop_criterion")

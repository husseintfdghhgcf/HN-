import pytest

from app.core.permissions import ADMIN, CUSTOMER, SUPER_ADMIN
from app.db.session import SessionLocal
from app.sample_data import PROFILE, seed_sample_data
from tests.test_evaluations import body


@pytest.fixture
def sample():
    with SessionLocal() as db:
        seed_sample_data(db)
        db.commit()


def test_unauthenticated_requests_are_401(client, sample):
    for method, url in [("get", "/api/v1/providers"), ("get", "/api/v1/evaluations"), ("get", "/api/v1/criteria"),
                        ("get", "/api/v1/reports"), ("get", "/api/v1/notifications"), ("get", "/api/v1/auth/me")]:
        assert getattr(client, method)(url).status_code == 401, url


def test_customer_cannot_use_admin_apis_by_crafting_requests(sample, make_client):
    c, h = make_client("cust@x.com", CUSTOMER)
    attempts = [
        ("post", "/api/v1/providers", {"slug": "evil", "name": "Evil"}),
        ("patch", "/api/v1/providers/aws", {"is_active": False}),
        ("post", "/api/v1/providers/aws/metrics", {"criterion_key": "performance", "value": 1, "unit": "x", "source": "me me"}),
        ("post", "/api/v1/criteria", {"key": "evil", "name_en": "Evil", "kind": "benefit", "unit": "x"}),
        ("patch", "/api/v1/criteria/cost", {"is_active": False}),
    ]
    for method, url, payload in attempts:
        r = getattr(c, method)(url, json=payload, headers=h)
        assert r.status_code == 403, (url, r.status_code)


def test_admin_can_manage_catalog_and_audit_is_written(sample, make_client):
    c, h = make_client("adm@x.com", ADMIN)
    r = c.post("/api/v1/providers", json={"slug": "oci", "name": "Oracle Cloud"}, headers=h)
    assert r.status_code == 201
    assert c.post("/api/v1/providers", json={"slug": "oci", "name": "Oracle Cloud"}, headers=h).status_code == 409
    m = {"criterion_key": "performance", "value": 77, "unit": "score 0-100", "source": "Vendor benchmark report 2026"}
    assert c.post("/api/v1/providers/oci/metrics", json=m, headers=h).status_code == 201
    assert c.post("/api/v1/providers/oci/metrics", json={**m, "source": ""}, headers=h).status_code == 422  # unsourced rejected
    assert c.post("/api/v1/providers/oci/metrics", json={**m, "criterion_key": "cost"}, headers=h).status_code == 422
    from sqlalchemy import select
    from app.models import AuditLog
    with SessionLocal() as db:
        actions = {a.action for a in db.scalars(select(AuditLog))}
    assert {"catalog.provider_created", "catalog.metric_recorded"} <= actions


def test_criterion_kind_is_immutable(sample, make_client):
    c, h = make_client("adm2@x.com", ADMIN)
    r = c.patch("/api/v1/criteria/cost", json={"kind": "benefit", "name_en": "Price"}, headers=h)
    assert r.status_code == 200 and r.json()["kind"] == "cost" and r.json()["name_en"] == "Price"


def test_customer_data_isolation_for_evaluations_and_reports(sample, make_client):
    alice, ha = make_client("alice@x.com")
    bob, hb = make_client("bob@x.com")
    ev = alice.post("/api/v1/evaluations", json=body(), headers=ha).json()
    rep = alice.post("/api/v1/reports", json={"evaluation_id": ev["id"]}, headers=ha).json()
    for url in (f"/api/v1/evaluations/{ev['id']}", f"/api/v1/evaluations/{ev['id']}/explanation", f"/api/v1/reports/{rep['id']}"):
        assert bob.get(url, headers=hb).status_code == 404
    assert bob.delete(f"/api/v1/evaluations/{ev['id']}", headers=hb).status_code == 404
    assert bob.post("/api/v1/reports", json={"evaluation_id": ev["id"]}, headers=hb).status_code == 404
    assert bob.get("/api/v1/evaluations", headers=hb).json()["total"] == 0
    assert bob.get("/api/v1/reports", headers=hb).json()["total"] == 0
    assert alice.get(f"/api/v1/evaluations/{ev['id']}", headers=ha).status_code == 200


def test_admins_do_not_automatically_see_customer_private_evaluations(sample, make_client):
    cust, hc = make_client("c2@x.com")
    admin, ha = make_client("a2@x.com", ADMIN)
    sup, hs = make_client("s2@x.com", SUPER_ADMIN)
    ev = cust.post("/api/v1/evaluations", json=body(), headers=hc).json()
    assert admin.get(f"/api/v1/evaluations/{ev['id']}", headers=ha).status_code == 404
    assert sup.get(f"/api/v1/evaluations/{ev['id']}", headers=hs).status_code == 404


def test_notifications_are_private(sample, make_client):
    a, ha = make_client("na@x.com")
    b, hb = make_client("nb@x.com")
    a.post("/api/v1/evaluations", json=body(), headers=ha)
    nid = a.get("/api/v1/notifications", headers=ha).json()["items"][0]["id"]
    assert b.post(f"/api/v1/notifications/{nid}/read", headers=hb).status_code == 404
    assert b.get("/api/v1/notifications", headers=hb).json()["items"] == []

import pytest
from sqlalchemy import select

from app.db.session import SessionLocal
from app.models import Evaluation, PricingRecord
from app.sample_data import PROFILE, seed_sample_data

MATRIX_OK = [[1, 3, 5], [1 / 3, 1, 3], [1 / 5, 1 / 3, 1]]


@pytest.fixture
def sample():
    with SessionLocal() as db:
        seed_sample_data(db)
        db.commit()


def body(**over):
    b = {"title": "t", "criteria": ["cost", "performance", "security"], "pairwise_matrix": MATRIX_OK,
         "requirements": {"profile": PROFILE, "region": "europe", "hours_per_month": 730}}
    b.update(over)
    return b


def test_evaluation_end_to_end_is_computed_not_hardcoded(sample, make_client):
    c, h = make_client("e1@x.com")
    r = c.post("/api/v1/evaluations", json=body(), headers=h)
    assert r.status_code == 201, r.text
    d = r.json()
    assert d["algorithm_version"] == "ahp-topsis-1.0.0"
    assert sum(d["ahp"]["weights"]) == pytest.approx(1.0) and d["ahp"]["consistent"]
    ranks = sorted(x["rank"] for x in d["results"])
    assert ranks == [1, 2, 3] and all(0 <= x["closeness"] <= 1 for x in d["results"])
    # every number used carries provenance and the sample label
    gcp = d["decision_matrix"]["raw"]["gcp"]["cost"]
    assert gcp["is_sample"] is True and gcp["timestamp"] and "SAMPLE" in gcp["source"]
    assert d["cost_assumptions"]["aws"]["formula"] == "monthly = unit_price x hours_per_month"
    assert d["decision_matrix"]["raw"]["aws"]["cost"]["value"] == pytest.approx(0.20 * 730)


def test_ranking_changes_with_inputs(sample, make_client):
    c, h = make_client("e2@x.com")
    cost_first = [[1, 9, 9], [1 / 9, 1, 1], [1 / 9, 1, 1]]
    perf_first = [[1, 1 / 9, 1], [9, 1, 9], [1, 1 / 9, 1]]
    a = c.post("/api/v1/evaluations", json=body(pairwise_matrix=cost_first), headers=h).json()
    b = c.post("/api/v1/evaluations", json=body(pairwise_matrix=perf_first), headers=h).json()
    top = lambda d: next(r["provider"] for r in d["results"] if r["rank"] == 1)
    assert top(a) != top(b)
    # region changes cost data: gcp is cheapest in north_america (sample data), not in europe
    us = c.post("/api/v1/evaluations", json=body(pairwise_matrix=cost_first, requirements={"profile": PROFILE, "region": "north_america"}), headers=h).json()
    assert top(us) == "gcp"


def test_inconsistent_matrix_rejected_with_details_and_nothing_saved(sample, make_client):
    c, h = make_client("e3@x.com")
    bad = [[1, 9, 1 / 9], [1 / 9, 1, 9], [9, 1 / 9, 1]]
    r = c.post("/api/v1/evaluations", json=body(pairwise_matrix=bad), headers=h)
    assert r.status_code == 422 and r.json()["detail"]["ahp"]["consistency_ratio"] > 0.1
    with SessionLocal() as db:
        assert db.scalar(select(Evaluation)) is None


@pytest.mark.parametrize("matrix", [[[1, 2, 3], [0.5, 1, 2]], [[1, 2, 3], [1, 1, 2], [1, 1, 1]]])
def test_malformed_matrix_rejected(sample, make_client, matrix):
    c, h = make_client("e4@x.com")
    assert c.post("/api/v1/evaluations", json=body(pairwise_matrix=matrix), headers=h).status_code == 422


def test_missing_price_excludes_provider_transparently(sample, make_client):
    with SessionLocal() as db:
        from sqlalchemy import delete
        from app.models import Provider, Region
        gcp = db.scalar(select(Provider).where(Provider.slug == "gcp"))
        ids = [r.id for r in db.scalars(select(Region).where(Region.provider_id == gcp.id, Region.geography == "europe"))]
        db.execute(delete(PricingRecord).where(PricingRecord.region_id.in_(ids)))
        db.commit()
    c, h = make_client("e5@x.com")
    d = c.post("/api/v1/evaluations", json=body(), headers=h).json()
    gcp = next(r for r in d["results"] if r["provider"] == "gcp")
    assert gcp["eligible"] is False and gcp["rank"] is None and "cost" in gcp["ineligible_reason"]
    ex = c.get(f"/api/v1/evaluations/{d['id']}/explanation", headers=h).json()["deterministic"]
    assert any("Google Cloud Platform was excluded" in u for u in ex["uncertainty"])
    # drop_criterion policy ranks everyone but records the dropped criterion
    d2 = c.post("/api/v1/evaluations", json=body(missing_policy="drop_criterion"), headers=h).json()
    assert d2["decision_matrix"]["dropped_criteria"].keys() == {"cost"} and len(d2["results"]) == 3


def test_explanation_and_sensitivity_generated_from_results(sample, make_client):
    c, h = make_client("e6@x.com")
    d = c.post("/api/v1/evaluations", json=body(), headers=h).json()
    ex = c.get(f"/api/v1/evaluations/{d['id']}/explanation", headers=h).json()
    det, sens = ex["deterministic"], ex["sensitivity"]
    assert ex["ai"] is None  # no AI key configured -> no generated text, nothing faked
    assert det["leader"] == next(r["provider"] for r in d["results"] if r["rank"] == 1)
    assert any("ranks first" in s for s in det["summary"])
    assert any("Sample (non-market) data" in u for u in det["uncertainty"])
    assert {w["key"] for w in det["criteria"]} == {"cost", "performance", "security"}
    assert len(sens["criteria"]) == 3 and all(len(x["scenarios"]) == 4 for x in sens["criteria"])


def test_evaluation_is_reproducible_after_prices_change(sample, make_client):
    c, h = make_client("e7@x.com")
    d = c.post("/api/v1/evaluations", json=body(), headers=h).json()
    with SessionLocal() as db:
        for rec in db.scalars(select(PricingRecord)):
            rec.price = rec.price * 10
        db.commit()
    again = c.get(f"/api/v1/evaluations/{d['id']}", headers=h).json()
    assert again["decision_matrix"] == d["decision_matrix"] and again["results"] == d["results"]


def test_idempotency_key_prevents_duplicates(sample, make_client):
    c, h = make_client("e8@x.com")
    h2 = {**h, "Idempotency-Key": "abc-123"}
    a = c.post("/api/v1/evaluations", json=body(), headers=h2).json()
    b = c.post("/api/v1/evaluations", json=body(), headers=h2).json()
    assert a["id"] == b["id"]
    assert c.get("/api/v1/evaluations", headers=h).json()["total"] == 1


def test_pagination_and_report_creation(sample, make_client):
    c, h = make_client("e9@x.com")
    ids = [c.post("/api/v1/evaluations", json=body(title=f"t{i}"), headers=h).json()["id"] for i in range(3)]
    page = c.get("/api/v1/evaluations?limit=2&offset=0", headers=h).json()
    assert page["total"] == 3 and len(page["items"]) == 2
    rep = c.post("/api/v1/reports", json={"evaluation_id": ids[0]}, headers=h)
    assert rep.status_code == 201 and rep.json()["body"]["ranking"]
    assert c.get("/api/v1/reports", headers=h).json()["total"] == 1
    assert c.get("/api/v1/notifications", headers=h).json()["unread"] == 3


def test_pricing_history_preserved_and_sourced(sample, make_client):
    c, h = make_client("p1@x.com")
    r = c.get(f"/api/v1/pricing/history?provider=aws&profile={PROFILE}", headers=h).json()
    assert r["total"] == 2 and all(i["is_sample"] and "SAMPLE" in i["source"] for i in r["items"])


def test_ahp_preview_valid_inconsistent_invalid_and_stateless(make_client):
    c, h = make_client("pv@x.com")
    ok = c.post("/api/v1/ahp/preview", json={"criteria": ["a", "b", "c"], "pairwise_matrix": MATRIX_OK}, headers=h)
    assert ok.status_code == 200 and ok.json()["weights"][0] == pytest.approx(0.637, abs=1e-3) and ok.json()["consistent"]
    cyc = [[1, 9, 1 / 9], [1 / 9, 1, 9], [9, 1 / 9, 1]]
    r = c.post("/api/v1/ahp/preview", json={"criteria": ["a", "b", "c"], "pairwise_matrix": cyc}, headers=h)
    assert r.status_code == 200 and r.json()["consistent"] is False        # reported, not corrected, not rejected
    bad = c.post("/api/v1/ahp/preview", json={"criteria": ["a", "b"], "pairwise_matrix": [[1, 2], [3, 1]]}, headers=h)
    assert bad.status_code == 422
    assert c.get("/api/v1/evaluations", headers=h).json()["total"] == 0     # nothing persisted
    anon = TestClientAnon()
    assert anon.post("/api/v1/ahp/preview", json={"criteria": ["a", "b"], "pairwise_matrix": [[1, 2], [0.5, 1]]}).status_code == 401


def TestClientAnon():
    from fastapi.testclient import TestClient
    from app.main import app
    return TestClient(app)


def test_pricing_options_reports_real_coverage(sample, make_client):
    c, h = make_client("po@x.com")
    r = c.get("/api/v1/pricing/options", headers=h).json()
    prof = next(p for p in r["profiles"] if p["profile"] == PROFILE)
    assert {x["region"]: x["providers"] for x in prof["regions"]} == {"europe": 3, "north_america": 3}

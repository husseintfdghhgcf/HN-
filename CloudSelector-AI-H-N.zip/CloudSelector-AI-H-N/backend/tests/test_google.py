"""Google OIDC validation tests. The ID tokens are signed with a LOCAL test key; the real Google
endpoints are never contacted, so this proves our validation logic, not live Google connectivity."""
import time
from urllib.parse import parse_qs, urlparse

import pytest
from authlib.jose import JsonWebKey, jwt
from fastapi.testclient import TestClient
from sqlalchemy import select

from app.db.session import SessionLocal
from app.main import app
from app.models import AuthIdentity, User
from app.services import google_oidc
from tests.conftest import PASSWORD, make_user

CLIENT_ID = "test-client-id.apps.googleusercontent.com"
KEY = JsonWebKey.generate_key("RSA", 2048, is_private=True, options={"kid": "k1"})
OTHER_KEY = JsonWebKey.generate_key("RSA", 2048, is_private=True, options={"kid": "k1"})


def token(key=KEY, **over):
    claims = {"iss": "https://accounts.google.com", "aud": CLIENT_ID, "sub": "g-123", "email": "g@example.com",
              "email_verified": True, "name": "G User", "nonce": "N", "iat": int(time.time()), "exp": int(time.time()) + 600}
    claims.update(over)
    claims = {k: v for k, v in claims.items() if v is not None}
    return jwt.encode({"alg": "RS256", "kid": "k1"}, claims, key).decode()


@pytest.fixture(autouse=True)
def fake_google(monkeypatch):
    monkeypatch.setattr(google_oidc, "jwks_provider", lambda: {"keys": [KEY.as_dict(is_private=False)]})


def run_callback(client, id_token, nonce="N", state="S", cookie_state="S", query_state="S", **extra):
    from app.api.v1.auth import _state_serializer
    client.cookies.set("cs_oidc", _state_serializer().dumps({"state": cookie_state, "nonce": nonce}))
    import app.services.google_oidc as g
    g_exchange = g.exchange_code
    g.exchange_code = lambda code: id_token
    try:
        return client.get("/api/v1/auth/google/callback", params={"code": "c", "state": query_state, **extra}, follow_redirects=False)
    finally:
        g.exchange_code = g_exchange


def ok(r):
    return r.status_code == 302 and r.headers["location"].endswith("/dashboard.html")


def fail_reason(r):
    assert r.status_code == 302
    return parse_qs(urlparse(r.headers["location"]).query)["auth_error"][0]


def test_start_redirects_to_google_with_state_nonce_and_exact_redirect_uri(client):
    r = client.get("/api/v1/auth/google/start", follow_redirects=False)
    q = parse_qs(urlparse(r.headers["location"]).query)
    assert r.status_code == 302 and r.headers["location"].startswith("https://accounts.google.com/")
    assert q["client_id"] == [CLIENT_ID] and q["response_type"] == ["code"] and "openid" in q["scope"][0]
    assert q["redirect_uri"][0].endswith("/api/v1/auth/google/callback") and q["state"] and q["nonce"]
    assert "httponly" in r.headers["set-cookie"].lower()
    assert "test-client-secret" not in r.headers["location"]


def test_valid_token_creates_verified_customer_and_session(client):
    r = run_callback(client, token())
    assert ok(r)
    me = client.get("/api/v1/auth/me").json()["user"]
    assert me["email"] == "g@example.com" and me["role"] == "customer" and me["email_verified"] is True
    with SessionLocal() as db:
        assert db.scalar(select(AuthIdentity)).subject == "g-123"
        assert db.scalar(select(User).where(User.email == "g@example.com")).password_hash is None


def test_second_login_reuses_identity(client):
    run_callback(client, token())
    c2 = TestClient(app)
    assert ok(run_callback(c2, token()))
    with SessionLocal() as db:
        assert len(db.scalars(select(User)).all()) == 1


@pytest.mark.parametrize("label,kw", [
    ("wrong audience", {"aud": "someone-else"}),
    ("wrong issuer", {"iss": "https://evil.example"}),
    ("expired", {"exp": int(time.time()) - 3600, "iat": int(time.time()) - 7200}),
    ("email unverified", {"email_verified": False}),
    ("email missing", {"email": None}),
    ("subject missing", {"sub": None}),
])
def test_invalid_claims_rejected(client, label, kw):
    r = run_callback(client, token(**kw))
    assert fail_reason(r) == "google_invalid", label
    assert client.get("/api/v1/auth/me").status_code == 401


def test_forged_signature_rejected(client):
    assert fail_reason(run_callback(client, token(key=OTHER_KEY))) == "google_invalid"


def test_nonce_mismatch_rejected(client):
    assert fail_reason(run_callback(client, token(nonce="attacker"), nonce="N")) == "google_invalid"


def test_state_mismatch_and_missing_cookie_rejected(client):
    assert fail_reason(run_callback(client, token(), cookie_state="S", query_state="DIFFERENT")) == "google_state"
    c2 = TestClient(app)
    r = c2.get("/api/v1/auth/google/callback", params={"code": "c", "state": "S"}, follow_redirects=False)
    assert fail_reason(r) == "google_state"


def test_user_cancellation_handled(client):
    r = client.get("/api/v1/auth/google/callback", params={"error": "access_denied"}, follow_redirects=False)
    assert fail_reason(r) == "google_cancelled"
    r = client.get("/api/v1/auth/google/callback", follow_redirects=False)
    assert fail_reason(r) == "google_invalid"


def test_links_to_existing_verified_account_without_changing_password(client):
    make_user("g@example.com")  # verified local account
    assert ok(run_callback(client, token()))
    with SessionLocal() as db:
        u = db.scalar(select(User).where(User.email == "g@example.com"))
        assert u.password_hash is not None and db.scalar(select(AuthIdentity)).user_id == u.id
    c2 = TestClient(app)
    assert c2.post("/api/v1/auth/login", json={"email": "g@example.com", "password": PASSWORD}).status_code == 200


def test_linking_to_unverified_local_account_removes_pre_registered_password(client):
    """Pre-hijack defence: an attacker who registered the victim's email must not keep access."""
    attacker = TestClient(app)
    assert attacker.post("/api/v1/auth/register", json={"email": "g@example.com", "password": PASSWORD}).status_code == 201
    assert ok(run_callback(client, token()))
    fresh = TestClient(app)
    assert fresh.post("/api/v1/auth/login", json={"email": "g@example.com", "password": PASSWORD}).status_code == 401


def test_disabled_account_cannot_sign_in(client):
    make_user("g@example.com")
    with SessionLocal() as db:
        db.scalar(select(User).where(User.email == "g@example.com")).is_active = False
        db.commit()
    assert fail_reason(run_callback(client, token())) == "account_disabled"


def test_unconfigured_google_returns_503(client, monkeypatch):
    monkeypatch.setattr(google_oidc, "is_configured", lambda: False)
    assert client.get("/api/v1/auth/google/start", follow_redirects=False).status_code == 503
    assert client.get("/api/v1/auth/google/status").json() == {"configured": False}

import os

# Must be set before the app is imported.
if "DATABASE_URL" not in os.environ:
    raise RuntimeError("Set DATABASE_URL to the *_test database (use scripts\\test.ps1).")
os.environ["ENVIRONMENT"] = "test"
os.environ["SECRET_KEY"] = "test-secret-key-not-for-production-0123456789"
os.environ["GOOGLE_CLIENT_ID"] = "test-client-id.apps.googleusercontent.com"
os.environ["GOOGLE_CLIENT_SECRET"] = "test-client-secret"
os.environ["N8N_WEBHOOK_SECRET"] = "test-webhook-secret"
os.environ["AI_API_KEY"] = ""
os.environ["SMTP_HOST"] = ""

import pytest
from sqlalchemy.engine import make_url

if not (make_url(os.environ["DATABASE_URL"]).database or "").endswith("_test"):
    raise RuntimeError("Refusing to run tests: DATABASE_URL must point to a database whose name ends with '_test' "
                       "(the test suite DROPS the schema). Use scripts\\test.ps1.")

from alembic import command
from alembic.config import Config
from fastapi.testclient import TestClient
from sqlalchemy import text

from app.core.permissions import ADMIN, CUSTOMER, SUPER_ADMIN
from app.core.ratelimit import limiter
from app.core.security import hash_password
from app.db.session import SessionLocal, engine
from app.main import app
from app.models import Role, User
from app.seed import seed_criteria, seed_roles

PASSWORD = "Str0ngPassw0rd!"


@pytest.fixture(scope="session", autouse=True)
def migrated_db():
    """Build the schema through Alembic itself, so the migrations are exercised by every run."""
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
    cfg = Config(os.path.join(os.path.dirname(__file__), "..", "alembic.ini"))
    cfg.set_main_option("script_location", os.path.join(os.path.dirname(__file__), "..", "alembic"))
    command.upgrade(cfg, "head")
    yield


@pytest.fixture(autouse=True)
def clean_state():
    limiter.reset()
    with engine.begin() as conn:
        tables = [r[0] for r in conn.execute(text(
            "select tablename from pg_tables where schemaname='public' and tablename <> 'alembic_version'"))]
        conn.execute(text("TRUNCATE " + ", ".join(f'"{t}"' for t in tables) + " RESTART IDENTITY CASCADE"))
    with SessionLocal() as db:
        seed_roles(db)
        seed_criteria(db)
        db.commit()
    yield


@pytest.fixture
def client():
    with TestClient(app) as c:
        yield c


def make_user(email: str, role: str = CUSTOMER, password: str = PASSWORD, **kw) -> str:
    with SessionLocal() as db:
        r = db.query(Role).filter_by(name=role).one()
        u = User(email=email, password_hash=hash_password(password), role_id=r.id, email_verified=True, **kw)
        db.add(u)
        db.commit()
        return u.id


def login(client: TestClient, email: str, password: str = PASSWORD) -> dict:
    r = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"X-CSRF-Token": client.cookies.get("cs_csrf")}


@pytest.fixture
def make_client():
    """Factory for independent logged-in clients (separate cookie jars)."""
    created = []

    def _make(email, role=CUSTOMER):
        make_user(email, role)
        c = TestClient(app)
        c.__enter__()
        created.append(c)
        h = login(c, email)
        return c, h

    yield _make
    for c in created:
        c.__exit__(None, None, None)

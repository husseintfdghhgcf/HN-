from sqlalchemy import select

from app.db.session import SessionLocal
from app.models import AuditLog, AuthSession, User
from tests.conftest import PASSWORD, login, make_user


def test_register_creates_customer_and_session(client):
    r = client.post("/api/v1/auth/register", json={"email": "New@Example.com", "password": PASSWORD, "full_name": "New"})
    assert r.status_code == 201
    body = r.json()
    assert body["user"]["email"] == "new@example.com"
    assert body["user"]["role"] == "customer"
    assert "password" not in str(body).lower().replace("password_reset", "")
    assert body["verification_email_sent"] is False  # SMTP not configured: must be honest
    assert client.get("/api/v1/auth/me").status_code == 200
    set_cookie = r.headers.get_list("set-cookie")
    session_cookie = next(c for c in set_cookie if c.startswith("cs_session="))
    assert "httponly" in session_cookie.lower()


def test_register_rejects_weak_password_and_duplicate(client):
    assert client.post("/api/v1/auth/register", json={"email": "a@b.com", "password": "short"}).status_code == 422
    assert client.post("/api/v1/auth/register", json={"email": "a@b.com", "password": "alllowercase123"}).status_code == 422
    assert client.post("/api/v1/auth/register", json={"email": "a@b.com", "password": PASSWORD}).status_code == 201
    client.cookies.clear()
    assert client.post("/api/v1/auth/register", json={"email": "A@B.com", "password": PASSWORD}).status_code == 409


def test_password_is_hashed_with_argon2(client):
    make_user("h@x.com")
    with SessionLocal() as db:
        u = db.scalar(select(User).where(User.email == "h@x.com"))
        assert u.password_hash.startswith("$argon2id$")
        assert PASSWORD not in u.password_hash


def test_login_success_and_generic_failure(client):
    make_user("u@x.com")
    bad_pw = client.post("/api/v1/auth/login", json={"email": "u@x.com", "password": "WrongPassw0rd!"})
    no_user = client.post("/api/v1/auth/login", json={"email": "nobody@x.com", "password": PASSWORD})
    assert bad_pw.status_code == no_user.status_code == 401
    assert bad_pw.json() == no_user.json()  # no account enumeration
    assert client.post("/api/v1/auth/login", json={"email": "u@x.com", "password": PASSWORD}).status_code == 200


def test_lockout_after_repeated_failures(client):
    make_user("lock@x.com")
    for _ in range(5):
        assert client.post("/api/v1/auth/login", json={"email": "lock@x.com", "password": "Wrong1234567"}).status_code == 401
    r = client.post("/api/v1/auth/login", json={"email": "lock@x.com", "password": PASSWORD})
    assert r.status_code == 423


def test_login_rate_limit(client):
    for _ in range(10):
        client.post("/api/v1/auth/login", json={"email": "rl@x.com", "password": "Whatever12345"})
    assert client.post("/api/v1/auth/login", json={"email": "rl@x.com", "password": "Whatever12345"}).status_code == 429


def test_csrf_required_for_state_changing_requests(client):
    make_user("c@x.com")
    headers = login(client, "c@x.com")
    assert client.patch("/api/v1/auth/me", json={"full_name": "X"}).status_code == 403  # no header
    assert client.patch("/api/v1/auth/me", json={"full_name": "X"}, headers={"X-CSRF-Token": "bogus"}).status_code == 403
    r = client.patch("/api/v1/auth/me", json={"full_name": "Updated"}, headers=headers)
    assert r.status_code == 200 and r.json()["user"]["full_name"] == "Updated"


def test_foreign_origin_rejected(client):
    r = client.post("/api/v1/auth/login", json={"email": "a@b.com", "password": "x"}, headers={"Origin": "https://evil.example"})
    assert r.status_code == 403


def test_logout_invalidates_session_server_side(client):
    make_user("o@x.com")
    headers = login(client, "o@x.com")
    stolen = client.cookies.get("cs_session")
    assert client.post("/api/v1/auth/logout", headers=headers).status_code == 200
    client.cookies.set("cs_session", stolen)  # replay the old cookie
    assert client.get("/api/v1/auth/me").status_code == 401
    with SessionLocal() as db:
        assert db.scalar(select(AuthSession)).revoked_at is not None


def test_expired_session_rejected(client):
    from datetime import datetime, timedelta, timezone
    make_user("e@x.com")
    login(client, "e@x.com")
    with SessionLocal() as db:
        s = db.scalar(select(AuthSession))
        s.expires_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        db.commit()
    assert client.get("/api/v1/auth/me").status_code == 401


def test_password_reset_flow_and_single_use(client):
    from app.services import auth_service as svc
    uid = make_user("r@x.com")
    r = client.post("/api/v1/auth/forgot-password", json={"email": "r@x.com"})
    r2 = client.post("/api/v1/auth/forgot-password", json={"email": "ghost@x.com"})
    assert r.status_code == r2.status_code == 202 and r.json() == r2.json()
    with SessionLocal() as db:
        raw = svc.issue_one_time_token(db, db.get(User, uid), "reset_password", 30)
        db.commit()
    assert client.post("/api/v1/auth/reset-password", json={"token": raw, "new_password": "weak"}).status_code == 422
    assert client.post("/api/v1/auth/reset-password", json={"token": raw, "new_password": "NewStr0ngPass!"}).status_code == 200
    assert client.post("/api/v1/auth/reset-password", json={"token": raw, "new_password": "Another0ngPass!"}).status_code == 400
    assert client.post("/api/v1/auth/login", json={"email": "r@x.com", "password": "NewStr0ngPass!"}).status_code == 200


def test_reset_revokes_existing_sessions(client):
    from app.services import auth_service as svc
    uid = make_user("rv@x.com")
    login(client, "rv@x.com")
    with SessionLocal() as db:
        raw = svc.issue_one_time_token(db, db.get(User, uid), "reset_password", 30)
        db.commit()
    client.post("/api/v1/auth/reset-password", json={"token": raw, "new_password": "NewStr0ngPass!"})
    assert client.get("/api/v1/auth/me").status_code == 401


def test_email_verification(client):
    from app.services import auth_service as svc
    r = client.post("/api/v1/auth/register", json={"email": "v@x.com", "password": PASSWORD})
    uid = r.json()["user"]["id"]
    assert r.json()["user"]["email_verified"] is False
    with SessionLocal() as db:
        raw = svc.issue_one_time_token(db, db.get(User, uid), "verify_email", 60)
        db.commit()
    assert client.post("/api/v1/auth/verify-email", json={"token": raw}).status_code == 200
    assert client.get("/api/v1/auth/me").json()["user"]["email_verified"] is True


def test_audit_log_records_sensitive_actions_without_secrets(client):
    make_user("au@x.com")
    login(client, "au@x.com")
    with SessionLocal() as db:
        actions = [a.action for a in db.scalars(select(AuditLog))]
        assert "auth.login" in actions
        assert PASSWORD not in str([a.detail for a in db.scalars(select(AuditLog))])


def test_health_and_ready_reveal_nothing_sensitive(client):
    assert client.get("/api/v1/health").json() == {"status": "ok"}
    assert client.get("/api/v1/ready").json() == {"status": "ready"}


def test_validation_errors_do_not_echo_password(client):
    r = client.post("/api/v1/auth/login", json={"email": "not-an-email", "password": "SuperSecret123!"})
    assert r.status_code == 422
    assert "SuperSecret123!" not in r.text

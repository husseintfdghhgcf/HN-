"""Management commands.

  python -m app.cli seed                      roles, permissions, criteria (idempotent)
  python -m app.cli bootstrap-admin           create the FIRST super administrator (one-time)
  python -m app.cli seed-sample               clearly-labelled SAMPLE provider data (development only)
"""
import getpass
import sys

from sqlalchemy import func, select

from app.core.config import get_settings
from app.core.permissions import SUPER_ADMIN
from app.core.security import hash_password, validate_password_strength
from app.db.session import SessionLocal
from app.models import Role, User
from app.seed import seed_criteria, seed_pricing_sources, seed_roles
from app.services.audit import audit


def cmd_seed() -> None:
    with SessionLocal() as db:
        seed_roles(db)
        seed_criteria(db)
        seed_pricing_sources(db)
        db.commit()
    print("Roles, permissions, default criteria and pricing sources are in place.")


def cmd_bootstrap_admin() -> None:
    s = get_settings()
    with SessionLocal() as db:
        seed_roles(db)
        role = db.scalar(select(Role).where(Role.name == SUPER_ADMIN))
        if db.scalar(select(func.count()).select_from(User).where(User.role_id == role.id)):
            print("A super administrator already exists. Refusing to create another via bootstrap.")
            sys.exit(1)
        email = (s.bootstrap_super_admin_email or input("Super admin email: ")).strip().lower()
        password = s.bootstrap_super_admin_password or getpass.getpass("Password (min 10 chars, mixed case + digit): ")
        err = validate_password_strength(password)
        if err or "@" not in email:
            print(err or "Invalid email")
            sys.exit(1)
        user = User(email=email, password_hash=hash_password(password), full_name="Super Administrator",
                    role_id=role.id, email_verified=True)
        db.add(user)
        db.flush()
        audit(db, "bootstrap.super_admin_created", user.id, "user", user.id)
        db.commit()
    print(f"Super administrator created: {email}\nRemove BOOTSTRAP_* variables from your environment now.")


def cmd_seed_sample() -> None:
    from app.sample_data import seed_sample_data

    if get_settings().is_production:
        print("seed-sample is disabled in production.")
        sys.exit(1)
    with SessionLocal() as db:
        seed_roles(db)
        seed_criteria(db)
        seed_sample_data(db)
        db.commit()
    print("SAMPLE data loaded (labelled is_sample=true; not real market data).")


if __name__ == "__main__":
    commands = {"seed": cmd_seed, "bootstrap-admin": cmd_bootstrap_admin, "seed-sample": cmd_seed_sample}
    if len(sys.argv) != 2 or sys.argv[1] not in commands:
        print(__doc__)
        sys.exit(2)
    commands[sys.argv[1]]()

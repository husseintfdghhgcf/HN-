"""Hybrid decision pipeline: AHP weights -> decision matrix from stored data -> TOPSIS -> explanation.

Entry point used by POST /api/v1/evaluations:  run_evaluation()
Pure maths lives in app/engine/*; this module only gathers persisted data and persists results.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.engine.ahp import AhpValidationError, InconsistentMatrixError, compute_ahp, explain_weights
from app.engine.explain import build_explanation
from app.engine.sensitivity import sensitivity
from app.engine.topsis import Measurement, TopsisValidationError, prepare_decision_matrix, topsis
from app.models import (Criterion, Evaluation, EvaluationResult, Explanation, PricingRecord, PricingSource,
                        Provider, ProviderMetric, Region, Service, ServiceConfiguration, utcnow)

ALGORITHM_VERSION = "ahp-topsis-1.0.0"
DEFAULT_HOURS_PER_MONTH = 730


class EvaluationError(ValueError):
    """User-correctable problem with the evaluation request."""

    def __init__(self, message: str, detail: Optional[dict] = None):
        super().__init__(message)
        self.detail = detail or {}


def _iso(dt: Optional[datetime]) -> Optional[str]:
    return dt.astimezone(timezone.utc).isoformat() if dt else None


def latest_price(db: Session, provider: Provider, profile: str, geography: str, billing_model: str = "on_demand"):
    """Cheapest current on-demand price for the comparable profile in the geography.

    'Current' = the most recent observation per (config, region). Returns (record, region, config) or None.
    """
    rows = db.execute(
        select(PricingRecord, Region, ServiceConfiguration)
        .join(ServiceConfiguration, PricingRecord.config_id == ServiceConfiguration.id)
        .join(Service, ServiceConfiguration.service_id == Service.id)
        .join(Region, PricingRecord.region_id == Region.id)
        .where(Service.provider_id == provider.id, ServiceConfiguration.profile == profile,
               Region.geography == geography, PricingRecord.billing_model == billing_model)
        .order_by(PricingRecord.retrieved_at.desc(), PricingRecord.id.desc())
    ).all()
    newest: dict[tuple[int, int], tuple] = {}
    for rec, reg, cfg in rows:
        newest.setdefault((rec.config_id, rec.region_id), (rec, reg, cfg))
    if not newest:
        return None
    return min(newest.values(), key=lambda t: t[0].price)


def latest_metric(db: Session, provider_id: int, key: str) -> Optional[ProviderMetric]:
    return db.scalar(select(ProviderMetric).where(ProviderMetric.provider_id == provider_id,
                     ProviderMetric.criterion_key == key).order_by(ProviderMetric.measured_at.desc(), ProviderMetric.id.desc()))


def run_evaluation(db: Session, owner_id: str, payload: dict[str, Any]) -> Evaluation:
    settings = get_settings()
    idem = payload.get("idempotency_key")
    if idem:
        existing = db.scalar(select(Evaluation).where(Evaluation.owner_id == owner_id, Evaluation.idempotency_key == idem))
        if existing:
            return existing

    crit_keys: list[str] = payload["criteria"]
    criteria = {c.key: c for c in db.scalars(select(Criterion).where(Criterion.key.in_(crit_keys), Criterion.is_active.is_(True)))}
    missing = [k for k in crit_keys if k not in criteria]
    if missing:
        raise EvaluationError("Unknown or inactive criteria", {"criteria": missing})

    # ---- Stage B: AHP
    try:
        ahp = compute_ahp(crit_keys, payload["pairwise_matrix"], enforce_consistency=True)
    except AhpValidationError as exc:
        raise EvaluationError(f"Invalid pairwise matrix: {exc}") from exc
    except InconsistentMatrixError as exc:
        raise EvaluationError(str(exc), {"ahp": exc.result.as_dict()}) from exc
    ahp_dict = ahp.as_dict()
    ahp_dict["derivation"] = explain_weights(ahp)

    # ---- providers & requirements
    req = payload["requirements"]
    profile, geography = req["profile"], req["region"]
    hours = float(req.get("hours_per_month", DEFAULT_HOURS_PER_MONTH))
    q = select(Provider).where(Provider.is_active.is_(True))
    if payload.get("providers"):
        q = q.where(Provider.slug.in_(payload["providers"]))
    providers = list(db.scalars(q.order_by(Provider.slug)))
    if len(providers) < 2:
        raise EvaluationError("At least two active providers are required")

    # ---- Stage C input: decision matrix with provenance (nothing imputed)
    data: dict[str, dict[str, Measurement]] = {}
    raw: dict[str, dict[str, dict[str, Any]]] = {}
    stale_cutoff = utcnow() - timedelta(hours=settings.pricing_stale_after_hours)
    timestamps: dict[str, Any] = {}
    cost_assumptions: dict[str, Any] = {}
    uncertainty: list[str] = []
    for p in providers:
        data[p.slug], raw[p.slug] = {}, {}
        for key in crit_keys:
            c = criteria[key]
            if c.data_source == "price":
                found = latest_price(db, p, profile, geography)
                if found is None:
                    m = Measurement(None, "")
                    info = {"value": None, "unit": "", "source": None, "timestamp": None, "is_sample": False,
                            "note": "no comparable price for this profile and region"}
                else:
                    rec, reg, cfg = found
                    src = db.get(PricingSource, rec.source_id)
                    monthly = float(Decimal(rec.price) * Decimal(str(hours)))
                    unit = f"{rec.currency}/month"
                    m = Measurement(monthly, unit, src.name, _iso(rec.retrieved_at), rec.is_sample)
                    info = {"value": monthly, "unit": unit, "source": src.name, "source_key": src.key,
                            "timestamp": _iso(rec.retrieved_at), "is_sample": rec.is_sample,
                            "region": reg.code, "sku": cfg.sku, "unit_price": float(rec.price), "price_unit": rec.unit}
                    cost_assumptions[p.slug] = {"sku": cfg.sku, "region": reg.code, "billing_model": rec.billing_model,
                                                "unit_price": float(rec.price), "price_unit": rec.unit,
                                                "hours_per_month": hours, "currency": rec.currency,
                                                "formula": "monthly = unit_price x hours_per_month"}
                    timestamps[f"{p.slug}.{key}"] = _iso(rec.retrieved_at)
                    if rec.retrieved_at < stale_cutoff and not rec.is_sample:
                        uncertainty.append(f"Price data for {p.name} is older than "
                                           f"{settings.pricing_stale_after_hours} hours (retrieved {_iso(rec.retrieved_at)}).")
            else:
                metric = latest_metric(db, p.id, key)
                if metric is None:
                    m = Measurement(None, c.unit)
                    info = {"value": None, "unit": c.unit, "source": None, "timestamp": None, "is_sample": False,
                            "note": "no recorded measurement"}
                else:
                    m = Measurement(metric.value, metric.unit, metric.source, _iso(metric.measured_at), metric.is_sample)
                    info = {"value": metric.value, "unit": metric.unit, "source": metric.source,
                            "source_url": metric.source_url, "timestamp": _iso(metric.measured_at), "is_sample": metric.is_sample}
                    timestamps[f"{p.slug}.{key}"] = _iso(metric.measured_at)
            data[p.slug][key] = m
            raw[p.slug][key] = info

    slugs = [p.slug for p in providers]
    kinds = [criteria[k].kind for k in crit_keys]
    try:
        prepared = prepare_decision_matrix(slugs, crit_keys, kinds, ahp.weights, data,
                                           missing_policy=payload.get("missing_policy", "exclude_alternative"))
        if len(prepared.alternatives) < 2:
            raise EvaluationError("Fewer than two providers have complete data for the selected criteria",
                                  {"excluded": prepared.excluded, "dropped_criteria": prepared.dropped_criteria})
        res = topsis(prepared.alternatives, prepared.criteria, prepared.matrix, prepared.weights, prepared.kinds)
    except TopsisValidationError as exc:
        raise EvaluationError(str(exc)) from exc

    names = {p.slug: p.name for p in providers}
    crit_names = {k: criteria[k].name_en for k in crit_keys}
    explanation = build_explanation(res, ahp_dict, raw, names, prepared.excluded, prepared.dropped_criteria,
                                    uncertainty, crit_names)
    sens = sensitivity(res, prepared.matrix)

    ev = Evaluation(
        owner_id=owner_id, title=(payload.get("title") or "").strip()[:200], status="completed", requirements=req,
        criteria_snapshot=[{"key": k, "name": criteria[k].name_en, "kind": criteria[k].kind, "unit": criteria[k].unit,
                            "data_source": criteria[k].data_source} for k in crit_keys],
        ahp_matrix=payload["pairwise_matrix"], ahp_result=ahp_dict,
        decision_matrix={"alternatives": prepared.alternatives, "criteria": prepared.criteria, "matrix": prepared.matrix,
                         "raw": raw, "excluded": prepared.excluded, "dropped_criteria": prepared.dropped_criteria,
                         "policy": prepared.policy, "used_weights": prepared.weights},
        topsis_result=res.as_dict(), algorithm_version=ALGORITHM_VERSION, data_timestamps=timestamps,
        cost_assumptions=cost_assumptions, idempotency_key=idem,
    )
    db.add(ev)
    db.flush()
    by_slug = {p.slug: p for p in providers}
    for i, slug in enumerate(res.alternatives):
        db.add(EvaluationResult(evaluation_id=ev.id, provider_id=by_slug[slug].id, rank=res.ranks[i],
                                closeness=res.closeness[i], d_plus=res.d_plus[i], d_minus=res.d_minus[i], eligible=True,
                                details={"normalized": dict(zip(res.criteria, res.normalized[i])),
                                         "weighted": dict(zip(res.criteria, res.weighted[i]))}))
    for slug, reason in prepared.excluded.items():
        db.add(EvaluationResult(evaluation_id=ev.id, provider_id=by_slug[slug].id, rank=None, closeness=None,
                                eligible=False, ineligible_reason=reason[:255], details={}))
    db.add(Explanation(evaluation_id=ev.id, deterministic=explanation, sensitivity=sens))
    db.flush()
    return ev

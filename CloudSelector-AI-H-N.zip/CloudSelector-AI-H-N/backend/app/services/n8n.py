"""Outbound events to n8n (HMAC-signed). Never blocks or fails the user request."""
import hashlib
import hmac
import json
import logging
import time

import httpx

from app.core.config import get_settings

log = logging.getLogger("n8n")


def sign(secret: str, timestamp: str, body: bytes) -> str:
    return hmac.new(secret.encode(), timestamp.encode() + b"." + body, hashlib.sha256).hexdigest()


def emit_event_safely(event: str, data: dict) -> bool:
    """POST a signed event to N8N_BASE_URL/webhook/<event>. Returns True only on a 2xx response."""
    s = get_settings()
    if not (s.n8n_base_url and s.n8n_webhook_secret):
        return False
    body = json.dumps({"event": event, "data": data}, separators=(",", ":")).encode()
    ts = str(int(time.time()))
    try:
        r = httpx.post(f"{s.n8n_base_url.rstrip('/')}/webhook/{event.replace('.', '-')}", content=body,
                       headers={"Content-Type": "application/json", "X-Timestamp": ts,
                                "X-Signature": sign(s.n8n_webhook_secret, ts, body)},
                       timeout=s.n8n_outbound_timeout_seconds)
        return r.is_success
    except httpx.HTTPError as exc:
        log.warning("n8n event %s not delivered: %s", event, type(exc).__name__)
        return False

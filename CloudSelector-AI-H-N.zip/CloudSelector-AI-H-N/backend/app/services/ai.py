"""Server-side AI adapter. The model only WORDS verified calculation results; it never scores.

  * The API key is read from the environment and used only in outbound request headers.
  * Output is validated: every number in the generated text must be traceable to the supplied
    facts (rounding allowed). Otherwise the text is rejected and nothing is stored.
  * Failures return generic categories, never provider responses (which could echo secrets).
"""
from __future__ import annotations

import json
import re
import time
from typing import Any, Callable

import httpx

from app.core.config import get_settings


class AiNotConfigured(Exception):
    pass


class AiError(Exception):
    """category: timeout | rate_limited | provider_error | auth | bad_output | ungrounded"""

    def __init__(self, category: str):
        super().__init__(category)
        self.category = category


def is_configured() -> bool:
    s = get_settings()
    return bool(s.ai_api_key and s.ai_model and s.ai_provider in ("anthropic", "openai", "gemini"))


def status() -> dict:
    s = get_settings()
    return {"configured": is_configured(), "provider": s.ai_provider, "model": s.ai_model or None,
            "key_present": bool(s.ai_api_key), "model_set": bool(s.ai_model)}


SYSTEM_PROMPT = (
    "You rewrite verified decision-analysis results as clear prose. Use ONLY the facts in the JSON provided by the user. "
    "Do not introduce any number, price, benchmark, rating or provider claim that is not in the JSON. "
    "Do not change rankings or scores. State when data is sample data or missing. Be concise (max 180 words)."
)


def _request_once(client: httpx.Client, system: str, user: str) -> str:
    s = get_settings()
    if s.ai_provider == "gemini":
        base = s.ai_base_url.rstrip("/") if s.ai_base_url else "https://generativelanguage.googleapis.com/v1beta"
        url = f"{base}/models/{s.ai_model}:generateContent"
        headers = {"x-goog-api-key": s.ai_api_key, "content-type": "application/json"}  # key in header, never in URL
        payload = {"systemInstruction": {"parts": [{"text": system}]},
                   "contents": [{"role": "user", "parts": [{"text": user}]}],
                   "generationConfig": {"maxOutputTokens": 700}}
    elif s.ai_provider == "anthropic":
        url = (s.ai_base_url.rstrip("/") if s.ai_base_url else "https://api.anthropic.com") + "/v1/messages"
        headers = {"x-api-key": s.ai_api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"}
        payload = {"model": s.ai_model, "max_tokens": 700, "system": system, "messages": [{"role": "user", "content": user}]}
    else:
        url = (s.ai_base_url.rstrip("/") if s.ai_base_url else "https://api.openai.com/v1") + "/chat/completions"
        headers = {"authorization": f"Bearer {s.ai_api_key}", "content-type": "application/json"}
        payload = {"model": s.ai_model, "max_tokens": 700,
                   "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]}
    try:
        r = client.post(url, headers=headers, json=payload, timeout=s.ai_timeout_seconds)
    except httpx.TimeoutException as exc:
        raise AiError("timeout") from exc
    except httpx.HTTPError as exc:
        raise AiError("provider_error") from exc
    if r.status_code in (401, 403):
        raise AiError("auth")
    if r.status_code == 429:
        raise AiError("rate_limited")
    if r.status_code >= 500:
        raise AiError("provider_error")
    if r.status_code >= 400:
        raise AiError("provider_error")
    try:
        body = r.json()
        if s.ai_provider == "gemini":
            text = body["candidates"][0]["content"]["parts"][0]["text"]
        elif s.ai_provider == "anthropic":
            text = body["content"][0]["text"]
        else:
            text = body["choices"][0]["message"]["content"]
    except (ValueError, KeyError, IndexError, TypeError) as exc:
        raise AiError("bad_output") from exc
    if not isinstance(text, str) or not text.strip():
        raise AiError("bad_output")
    return text.strip()


def complete(system: str, user: str, client: httpx.Client | None = None, sleep: Callable[[float], None] = time.sleep) -> str:
    if not is_configured():
        raise AiNotConfigured()
    s = get_settings()
    own = client is None
    client = client or httpx.Client()
    try:
        for n in range(max(1, s.ai_max_retries + 1)):
            try:
                return _request_once(client, system, user)
            except AiError as exc:
                if exc.category in ("timeout", "rate_limited", "provider_error") and n < s.ai_max_retries:
                    sleep(min(8.0, 1.0 * 2 ** n))
                    continue
                raise
    finally:
        if own:
            client.close()
    raise AiError("provider_error")


# ---------------------------------------------------------------- grounding
_NUM = re.compile(r"(?<![\w.])-?\d+(?:\.\d+)?")


def _numbers_in(obj: Any, acc: set[float]) -> None:
    if isinstance(obj, bool) or obj is None:
        return
    if isinstance(obj, (int, float)):
        acc.add(float(obj))
        acc.add(float(obj) * 100)  # shown as a percentage
    elif isinstance(obj, str):
        acc.update(float(m) for m in _NUM.findall(obj))
    elif isinstance(obj, dict):
        for v in obj.values():
            _numbers_in(v, acc)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            _numbers_in(v, acc)


def check_grounded(text: str, facts: Any) -> bool:
    allowed: set[float] = set()
    _numbers_in(facts, allowed)
    for tok in _NUM.findall(text):
        decimals = len(tok.split(".")[1]) if "." in tok else 0
        x = float(tok)
        if not any(round(a, decimals) == x or abs(a - x) < 1e-9 for a in allowed):
            return False
    return True


def grounded_text(task: str, facts: dict, client: httpx.Client | None = None) -> str:
    user = f"{task}\n\nVERIFIED FACTS (JSON):\n{json.dumps(facts, default=str, separators=(',', ':'))}"
    text = complete(SYSTEM_PROMPT, user, client)
    if not check_grounded(text, facts):
        raise AiError("ungrounded")
    return text

from typing import Any, Optional

from fastapi import Request
from sqlalchemy.orm import Session

from app.models import AuditLog

_SECRET_KEYS = {"password", "token", "secret", "api_key", "authorization", "cookie"}


def _scrub(detail: dict[str, Any]) -> dict[str, Any]:
    return {k: ("[redacted]" if k.lower() in _SECRET_KEYS else v) for k, v in detail.items()}


def audit(
    db: Session,
    action: str,
    actor_id: Optional[str] = None,
    target_type: str = "",
    target_id: str = "",
    detail: Optional[dict[str, Any]] = None,
    request: Optional[Request] = None,
) -> None:
    ip = request.client.host if request and request.client else ""
    db.add(
        AuditLog(
            actor_id=actor_id,
            action=action,
            target_type=target_type,
            target_id=str(target_id),
            detail=_scrub(detail or {}),
            ip=ip,
        )
    )

"""Run a pricing adapter, validate its output, and append valid prices to history.

Safety rules
  * Retries (transient errors only) use bounded exponential backoff.
  * An empty result, or a result where too many rows fail validation, is REJECTED and nothing is
    stored: existing valid data is never replaced by bad data (and nothing is ever deleted).
  * Prices are append-only. An unchanged price is re-recorded at most once per 24 h (heartbeat).
"""
from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Callable

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.adapters.base import NormalizedPrice, PermanentFetchError, PricingAdapter, TransientFetchError
from app.core.config import get_settings
from app.models import (PricingRecord, PricingSource, Provider, Region, Service, ServiceConfiguration, SyncRun, utcnow)

log = logging.getLogger("pricing_sync")
MAX_REJECT_FRACTION = 0.30
HEARTBEAT = timedelta(hours=24)
BACKOFF_BASE, BACKOFF_CAP = 1.0, 30.0


def validate(p: NormalizedPrice) -> str | None:
    """Return a rejection reason or None."""
    try:
        price = Decimal(p.price)
    except Exception:
        return "price is not a number"
    if not price.is_finite() or price < 0:
        return "price is negative or not finite"
    if price == 0:
        return "zero price is not accepted"
    if len(p.currency) != 3 or not p.currency.isalpha():
        return "invalid currency code"
    if not p.unit or not p.region_code or not p.sku or not p.profile:
        return "missing unit, region, sku or profile"
    return None


def fetch_with_retry(adapter: PricingAdapter, client: httpx.Client, sleep: Callable[[float], None] = time.sleep):
    attempts = max(1, get_settings().pricing_max_retries)
    for n in range(attempts):
        try:
            return adapter.fetch(client)
        except TransientFetchError:
            if n == attempts - 1:
                raise
            sleep(min(BACKOFF_CAP, BACKOFF_BASE * (2 ** n)))


def run_sync(db: Session, adapter: PricingAdapter, triggered_by: str = "manual", client: httpx.Client | None = None,
             sleep: Callable[[float], None] = time.sleep) -> SyncRun:
    source = db.scalar(select(PricingSource).where(PricingSource.key == adapter.source_key))
    if source is None:
        raise LookupError(f"Pricing source '{adapter.source_key}' is not registered; run `python -m app.cli seed`")
    run = SyncRun(source_id=source.id, triggered_by=triggered_by)
    db.add(run)
    db.flush()
    own_client = client is None
    client = client or httpx.Client(timeout=get_settings().pricing_http_timeout_seconds, follow_redirects=True)
    try:
        rows = fetch_with_retry(adapter, client, sleep)
    except (TransientFetchError, PermanentFetchError) as exc:
        return _finish(db, run, source, "failed", error=f"{type(exc).__name__}: {exc}")
    except Exception as exc:  # unexpected adapter bug: record without leaking internals
        log.exception("adapter crashed")
        return _finish(db, run, source, "failed", error=f"Unexpected adapter error ({type(exc).__name__})")
    finally:
        if own_client:
            client.close()

    run.records_received = len(rows)
    good, reasons = [], []
    for r in rows:
        why = validate(r)
        (reasons if why else good).append(why or r)
    run.records_rejected = len(reasons)
    if not rows:
        return _finish(db, run, source, "rejected", error="Source returned no records; existing data kept")
    if not good or len(reasons) / len(rows) > MAX_REJECT_FRACTION:
        sample = "; ".join(sorted(set(reasons))[:3])
        return _finish(db, run, source, "rejected", error=f"{len(reasons)}/{len(rows)} records failed validation ({sample}); nothing stored")

    stored = _store(db, source, run, good)
    run.records_stored = stored
    return _finish(db, run, source, "success")


def _store(db: Session, source: PricingSource, run: SyncRun, rows: list[NormalizedPrice]) -> int:
    provider = db.get(Provider, source.provider_id)
    now = utcnow()
    stored = 0
    for r in rows:
        svc = db.scalar(select(Service).where(Service.provider_id == provider.id, Service.code == r.service_code))
        if svc is None:
            svc = Service(provider_id=provider.id, category=r.category, code=r.service_code, name=r.service_name)
            db.add(svc)
            db.flush()
        cfg = db.scalar(select(ServiceConfiguration).where(ServiceConfiguration.service_id == svc.id, ServiceConfiguration.sku == r.sku))
        if cfg is None:
            cfg = ServiceConfiguration(service_id=svc.id, sku=r.sku, profile=r.profile, vcpu=r.vcpu, memory_gib=r.memory_gib, os=r.os)
            db.add(cfg)
            db.flush()
        reg = db.scalar(select(Region).where(Region.provider_id == provider.id, Region.code == r.region_code))
        if reg is None:
            reg = Region(provider_id=provider.id, code=r.region_code, name=r.region_code, geography=r.geography)
            db.add(reg)
            db.flush()
        last = db.scalar(select(PricingRecord).where(
            PricingRecord.config_id == cfg.id, PricingRecord.region_id == reg.id, PricingRecord.source_id == source.id,
            PricingRecord.billing_model == r.billing_model, PricingRecord.tier == r.tier,
        ).order_by(PricingRecord.retrieved_at.desc(), PricingRecord.id.desc()))
        if last is not None and last.price == Decimal(r.price) and last.currency == r.currency and now - last.retrieved_at < HEARTBEAT:
            continue
        db.add(PricingRecord(config_id=cfg.id, region_id=reg.id, source_id=source.id, sync_run_id=run.id, price=Decimal(r.price),
                             currency=r.currency, unit=r.unit, billing_model=r.billing_model, tier=r.tier,
                             source_identifier=r.source_identifier, effective_date=r.effective_date, retrieved_at=now, is_sample=False))
        stored += 1
    return stored


def _finish(db: Session, run: SyncRun, source: PricingSource, status: str, error: str = "") -> SyncRun:
    run.status, run.finished_at, run.error_summary = status, utcnow(), error[:2000]
    source.last_status = status
    if status == "success":
        source.last_success_at = run.finished_at
    db.commit()
    return run


def source_health(source: PricingSource) -> dict:
    stale_h = get_settings().pricing_stale_after_hours
    age = None if source.last_success_at is None else (utcnow() - source.last_success_at).total_seconds() / 3600
    return {"key": source.key, "name": source.name, "kind": source.kind, "requires_credentials": source.requires_credentials,
            "is_sample": source.is_sample, "enabled": source.enabled, "last_status": source.last_status,
            "last_success_at": source.last_success_at, "age_hours": None if age is None else round(age, 2),
            "stale": (not source.is_sample) and (age is None or age > stale_h), "stale_after_hours": stale_h}

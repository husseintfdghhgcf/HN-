"""Google OAuth 2.0 / OpenID Connect (authorization-code flow, server side).

Validation performed on the ID token: RS256 signature against Google's JWKS, issuer,
audience (= our client id), expiry, nonce, and `email_verified`.
JWKS fetching is a module-level callable so tests can substitute a local key set.
"""
import secrets
from typing import Any, Callable
from urllib.parse import urlencode

import httpx
from authlib.jose import JsonWebKey, jwt
from authlib.jose.errors import JoseError

from app.core.config import get_settings

AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URL = "https://oauth2.googleapis.com/token"
JWKS_URL = "https://www.googleapis.com/oauth2/v3/certs"
VALID_ISSUERS = {"https://accounts.google.com", "accounts.google.com"}


class GoogleAuthError(Exception):
    pass


def is_configured() -> bool:
    s = get_settings()
    return bool(s.google_client_id and s.google_client_secret)


def build_authorization_url(state: str, nonce: str) -> str:
    s = get_settings()
    params = {
        "client_id": s.google_client_id, "redirect_uri": s.google_redirect_uri,
        "response_type": "code", "scope": "openid email profile",
        "state": state, "nonce": nonce, "prompt": "select_account",
    }
    return f"{AUTH_URL}?{urlencode(params)}"


def new_state_and_nonce() -> tuple[str, str]:
    return secrets.token_urlsafe(24), secrets.token_urlsafe(24)


def _fetch_jwks() -> dict[str, Any]:
    r = httpx.get(JWKS_URL, timeout=10)
    r.raise_for_status()
    return r.json()


jwks_provider: Callable[[], dict[str, Any]] = _fetch_jwks


def exchange_code(code: str) -> str:
    """Exchange the authorization code for an ID token (raw JWT)."""
    s = get_settings()
    try:
        r = httpx.post(
            TOKEN_URL,
            data={
                "code": code, "client_id": s.google_client_id, "client_secret": s.google_client_secret,
                "redirect_uri": s.google_redirect_uri, "grant_type": "authorization_code",
            },
            timeout=10,
        )
    except httpx.HTTPError as exc:
        raise GoogleAuthError("Could not reach Google token endpoint") from exc
    if r.status_code != 200:
        raise GoogleAuthError("Google rejected the authorization code")
    id_token = r.json().get("id_token")
    if not id_token:
        raise GoogleAuthError("Google response did not include an ID token")
    return id_token


def validate_id_token(id_token: str, expected_nonce: str) -> dict[str, Any]:
    s = get_settings()
    try:
        keys = JsonWebKey.import_key_set(jwks_provider())
        claims = jwt.decode(id_token, keys, claims_options={
            "iss": {"essential": True, "values": list(VALID_ISSUERS)},
            "aud": {"essential": True, "value": s.google_client_id},
            "exp": {"essential": True},
            "sub": {"essential": True},
        })
        claims.validate()  # checks exp / nbf / iat with default leeway
    except (JoseError, ValueError, KeyError, httpx.HTTPError) as exc:
        raise GoogleAuthError("Invalid ID token") from exc
    if not expected_nonce or claims.get("nonce") != expected_nonce:
        raise GoogleAuthError("Nonce mismatch")
    if not claims.get("email") or claims.get("email_verified") is not True:
        raise GoogleAuthError("Google account email is not verified")
    return dict(claims)

from datetime import datetime, timedelta, timezone

from fastapi import Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.permissions import CUSTOMER, ROLE_PERMISSIONS
from app.core.security import hash_token, new_token
from app.models import AuthSession, OneTimeToken, Role, User


def get_role(db: Session, name: str) -> Role:
    role = db.scalar(select(Role).where(Role.name == name))
    if role is None:
        raise RuntimeError(f"Role '{name}' missing: run the seed/bootstrap step")
    return role


def create_session(db: Session, user: User, request: Request, response: Response) -> AuthSession:
    s = get_settings()
    token, csrf = new_token(), new_token()
    sess = AuthSession(
        token_hash=hash_token(token),
        csrf_token=csrf,
        user_id=user.id,
        expires_at=datetime.now(timezone.utc) + timedelta(hours=s.session_ttl_hours),
        user_agent=(request.headers.get("user-agent") or "")[:255],
    )
    db.add(sess)
    max_age = s.session_ttl_hours * 3600
    response.set_cookie(
        s.session_cookie_name, token, max_age=max_age, httponly=True,
        secure=s.cookie_secure, samesite=s.cookie_samesite, path="/",
    )
    # Readable by the frontend so it can echo it in X-CSRF-Token (double-submit).
    response.set_cookie(
        s.csrf_cookie_name, csrf, max_age=max_age, httponly=False,
        secure=s.cookie_secure, samesite=s.cookie_samesite, path="/",
    )
    return sess


def clear_cookies(response: Response) -> None:
    s = get_settings()
    response.delete_cookie(s.session_cookie_name, path="/")
    response.delete_cookie(s.csrf_cookie_name, path="/")


def revoke_all_sessions(db: Session, user_id: str) -> None:
    now = datetime.now(timezone.utc)
    for sess in db.scalars(select(AuthSession).where(AuthSession.user_id == user_id, AuthSession.revoked_at.is_(None))):
        sess.revoked_at = now


def issue_one_time_token(db: Session, user: User, purpose: str, ttl_minutes: int) -> str:
    raw = new_token()
    db.add(
        OneTimeToken(
            user_id=user.id, purpose=purpose, token_hash=hash_token(raw),
            expires_at=datetime.now(timezone.utc) + timedelta(minutes=ttl_minutes),
        )
    )
    return raw


def consume_one_time_token(db: Session, raw: str, purpose: str) -> User | None:
    row = db.scalar(select(OneTimeToken).where(OneTimeToken.token_hash == hash_token(raw), OneTimeToken.purpose == purpose))
    now = datetime.now(timezone.utc)
    if not row or row.used_at is not None or row.expires_at <= now:
        return None
    row.used_at = now
    return db.get(User, row.user_id)


def user_out(user: User) -> dict:
    return {
        "id": user.id, "email": user.email, "full_name": user.full_name,
        "organization": user.organization, "locale": user.locale,
        "preferences": user.preferences or {}, "role": user.role.name,
        "permissions": sorted(ROLE_PERMISSIONS.get(user.role.name, set())),
        "email_verified": user.email_verified, "created_at": user.created_at,
    }

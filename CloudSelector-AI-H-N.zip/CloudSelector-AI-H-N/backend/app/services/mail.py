"""Email delivery. Sends only when SMTP is configured; otherwise reports honestly that it did not."""
import logging
import smtplib
from email.message import EmailMessage

from app.core.config import get_settings

log = logging.getLogger("mail")


def send_email(to: str, subject: str, body: str) -> bool:
    """Return True only if the message was handed to an SMTP server."""
    s = get_settings()
    if not (s.smtp_host and s.smtp_from):
        log.warning("SMTP not configured: email '%s' to a user was NOT sent", subject)
        return False
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = s.smtp_from, to, subject
    msg.set_content(body)
    try:
        with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=15) as smtp:
            if s.smtp_starttls:
                smtp.starttls()
            if s.smtp_user:
                smtp.login(s.smtp_user, s.smtp_password)
            smtp.send_message(msg)
        return True
    except Exception as exc:  # never leak credentials in logs
        log.error("SMTP delivery failed: %s", type(exc).__name__)
        return False

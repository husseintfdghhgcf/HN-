"""SAMPLE data for development and demos ONLY.

Everything here is flagged is_sample=True and uses clearly synthetic numbers. These are NOT real
market prices or measurements and the UI/API label them as sample data. Real prices arrive via
the pricing adapters (app/adapters), real metrics via an administrator or an authorised source.
"""
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import (PricingRecord, PricingSource, Provider, ProviderMetric, Region, Service,
                        ServiceConfiguration)

PROFILE = "general-4vcpu-16gib-linux"

# slug, name, website
PROVIDERS = [
    ("aws", "Amazon Web Services", "https://aws.amazon.com"),
    ("azure", "Microsoft Azure", "https://azure.microsoft.com"),
    ("gcp", "Google Cloud Platform", "https://cloud.google.com"),
]
# slug -> (service code, sku, {region code: (geography, sample hourly price)})
SAMPLE_PRICING = {
    "aws": ("SAMPLE-compute", "sample-4vcpu-16gib", {"eu-sample-1": ("europe", "0.2000"), "us-sample-1": ("north_america", "0.1900")}),
    "azure": ("SAMPLE-compute", "sample-4vcpu-16gib", {"eu-sample-1": ("europe", "0.1950"), "us-sample-1": ("north_america", "0.1850")}),
    "gcp": ("SAMPLE-compute", "sample-4vcpu-16gib", {"eu-sample-1": ("europe", "0.2050"), "us-sample-1": ("north_america", "0.1800")}),
}
# SAMPLE measurements (illustrative placeholders, not benchmarks or certifications)
SAMPLE_METRICS = {
    "aws": {"performance": 82, "reliability": 99.99, "security": 7, "availability": 99.95, "scalability": 90, "regional_coverage": 30, "compliance": 9},
    "azure": {"performance": 79, "reliability": 99.95, "security": 8, "availability": 99.95, "scalability": 86, "regional_coverage": 28, "compliance": 10},
    "gcp": {"performance": 85, "reliability": 99.95, "security": 7, "availability": 99.9, "scalability": 88, "regional_coverage": 22, "compliance": 8},
}
UNITS = {"performance": "score 0-100", "reliability": "% SLA uptime", "security": "certifications count",
         "availability": "% uptime", "scalability": "score 0-100", "regional_coverage": "regions count",
         "compliance": "frameworks count"}
SAMPLE_LABEL = "SAMPLE DATA - illustrative, not measured"


def seed_sample_data(db: Session) -> None:
    now = datetime.now(timezone.utc)
    for slug, name, site in PROVIDERS:
        prov = db.scalar(select(Provider).where(Provider.slug == slug))
        if prov is None:
            prov = Provider(slug=slug, name=name, website=site, is_sample=False, description="")
            db.add(prov)
            db.flush()
        code, sku, regions = SAMPLE_PRICING[slug]
        svc = db.scalar(select(Service).where(Service.provider_id == prov.id, Service.code == code))
        if svc is None:
            svc = Service(provider_id=prov.id, category="compute", code=code, name="Sample compute instance")
            db.add(svc)
            db.flush()
        cfg = db.scalar(select(ServiceConfiguration).where(ServiceConfiguration.service_id == svc.id, ServiceConfiguration.sku == sku))
        if cfg is None:
            cfg = ServiceConfiguration(service_id=svc.id, sku=sku, profile=PROFILE, vcpu=4, memory_gib=16, os="linux")
            db.add(cfg)
            db.flush()
        src = db.scalar(select(PricingSource).where(PricingSource.key == f"sample-{slug}"))
        if src is None:
            src = PricingSource(provider_id=prov.id, key=f"sample-{slug}", name=SAMPLE_LABEL, kind="sample",
                                is_sample=True, last_status="sample")
            db.add(src)
            db.flush()
        for rcode, (geo, price) in regions.items():
            reg = db.scalar(select(Region).where(Region.provider_id == prov.id, Region.code == rcode))
            if reg is None:
                reg = Region(provider_id=prov.id, code=rcode, name=f"{rcode} (sample)", geography=geo)
                db.add(reg)
                db.flush()
            exists = db.scalar(select(PricingRecord.id).where(PricingRecord.config_id == cfg.id,
                               PricingRecord.region_id == reg.id, PricingRecord.source_id == src.id))
            if exists is None:
                db.add(PricingRecord(config_id=cfg.id, region_id=reg.id, source_id=src.id, price=Decimal(price),
                                     currency="USD", unit="hour", billing_model="on_demand",
                                     source_identifier="sample", retrieved_at=now, is_sample=True))
        for crit, value in SAMPLE_METRICS[slug].items():
            exists = db.scalar(select(ProviderMetric.id).where(ProviderMetric.provider_id == prov.id,
                               ProviderMetric.criterion_key == crit, ProviderMetric.is_sample.is_(True)))
            if exists is None:
                db.add(ProviderMetric(provider_id=prov.id, criterion_key=crit, value=float(value), unit=UNITS[crit],
                                      source=SAMPLE_LABEL, measured_at=now, is_sample=True))
    db.flush()

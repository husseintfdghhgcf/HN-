"""Database models for CloudSelector AI.

Design notes
- Pricing and metric rows are append-only: history is preserved, "current" is derived.
- Evaluations persist every input needed to reproduce a result (weights, measurements,
  timestamps, algorithm version), so historical evaluations never depend on later data.
- JSON columns use JSONB on PostgreSQL.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base

JsonType = JSON().with_variant(JSONB(), "postgresql")


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_id() -> str:
    return uuid.uuid4().hex


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=utcnow, onupdate=utcnow, nullable=False
    )


# ---------------------------------------------------------------- roles & users
class Role(Base):
    __tablename__ = "roles"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)  # super_admin | admin | customer
    description: Mapped[str] = mapped_column(String(255), default="")
    permissions: Mapped[list["RolePermission"]] = relationship(back_populates="role", cascade="all, delete-orphan")


class RolePermission(Base):
    __tablename__ = "role_permissions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id", ondelete="CASCADE"), nullable=False)
    permission: Mapped[str] = mapped_column(String(64), nullable=False)
    role: Mapped[Role] = relationship(back_populates="permissions")
    __table_args__ = (UniqueConstraint("role_id", "permission", name="uq_role_permission"),)


class User(Base, TimestampMixin):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    email: Mapped[str] = mapped_column(String(320), unique=True, nullable=False, index=True)
    password_hash: Mapped[Optional[str]] = mapped_column(String(255))  # null for Google-only accounts
    full_name: Mapped[str] = mapped_column(String(120), default="")
    organization: Mapped[str] = mapped_column(String(160), default="")
    locale: Mapped[str] = mapped_column(String(8), default="en")
    preferences: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    role_id: Mapped[int] = mapped_column(ForeignKey("roles.id"), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    email_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0, nullable=False)
    locked_until: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    role: Mapped[Role] = relationship(lazy="joined")
    identities: Mapped[list["AuthIdentity"]] = relationship(back_populates="user", cascade="all, delete-orphan")


class AuthIdentity(Base, TimestampMixin):
    """External identity (e.g. Google `sub`) linked to a user."""

    __tablename__ = "auth_identities"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    provider: Mapped[str] = mapped_column(String(32), nullable=False)
    subject: Mapped[str] = mapped_column(String(255), nullable=False)
    email: Mapped[str] = mapped_column(String(320), default="")
    user: Mapped[User] = relationship(back_populates="identities")
    __table_args__ = (UniqueConstraint("provider", "subject", name="uq_identity_provider_subject"),)


class AuthSession(Base):
    """Server-side session. Only a SHA-256 hash of the token is stored."""

    __tablename__ = "auth_sessions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    csrf_token: Mapped[str] = mapped_column(String(64), nullable=False)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    revoked_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    user_agent: Mapped[str] = mapped_column(String(255), default="")
    user: Mapped[User] = relationship(lazy="joined")


class OneTimeToken(Base):
    """Email verification and password-reset tokens (hash only)."""

    __tablename__ = "one_time_tokens"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    purpose: Mapped[str] = mapped_column(String(32), nullable=False)  # verify_email | reset_password
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    used_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


# ---------------------------------------------------------------- provider catalog
class Provider(Base, TimestampMixin):
    __tablename__ = "providers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    slug: Mapped[str] = mapped_column(String(32), unique=True, nullable=False)  # aws | azure | gcp
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    website: Mapped[str] = mapped_column(String(255), default="")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    services: Mapped[list["Service"]] = relationship(back_populates="provider", cascade="all, delete-orphan")
    regions: Mapped[list["Region"]] = relationship(back_populates="provider", cascade="all, delete-orphan")


class Service(Base, TimestampMixin):
    __tablename__ = "services"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider_id: Mapped[int] = mapped_column(ForeignKey("providers.id", ondelete="CASCADE"), nullable=False)
    category: Mapped[str] = mapped_column(String(48), nullable=False)  # compute | storage | database | network
    code: Mapped[str] = mapped_column(String(120), nullable=False)  # provider service code, e.g. AmazonEC2
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    provider: Mapped[Provider] = relationship(back_populates="services")
    __table_args__ = (UniqueConstraint("provider_id", "code", name="uq_service_provider_code"),)


class Region(Base):
    __tablename__ = "regions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider_id: Mapped[int] = mapped_column(ForeignKey("providers.id", ondelete="CASCADE"), nullable=False)
    code: Mapped[str] = mapped_column(String(64), nullable=False)
    name: Mapped[str] = mapped_column(String(160), default="")
    geography: Mapped[str] = mapped_column(String(64), default="")  # normalized: europe, north_america, ...
    provider: Mapped[Provider] = relationship(back_populates="regions")
    __table_args__ = (UniqueConstraint("provider_id", "code", name="uq_region_provider_code"),)


class ServiceConfiguration(Base, TimestampMixin):
    """A comparable configuration (e.g. 4 vCPU / 16 GiB Linux on-demand instance)."""

    __tablename__ = "service_configurations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    service_id: Mapped[int] = mapped_column(ForeignKey("services.id", ondelete="CASCADE"), nullable=False)
    sku: Mapped[str] = mapped_column(String(160), nullable=False)
    profile: Mapped[str] = mapped_column(String(64), nullable=False)  # normalized comparability key
    vcpu: Mapped[Optional[int]] = mapped_column(Integer)
    memory_gib: Mapped[Optional[float]] = mapped_column(Float)
    os: Mapped[str] = mapped_column(String(32), default="linux")
    attributes: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    __table_args__ = (
        UniqueConstraint("service_id", "sku", name="uq_config_service_sku"),
        Index("ix_config_profile", "profile"),
    )


# ---------------------------------------------------------------- pricing
class PricingSource(Base, TimestampMixin):
    __tablename__ = "pricing_sources"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider_id: Mapped[int] = mapped_column(ForeignKey("providers.id", ondelete="CASCADE"), nullable=False)
    key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(160), nullable=False)
    kind: Mapped[str] = mapped_column(String(32), nullable=False)  # official_api | official_dataset | sample
    url: Mapped[str] = mapped_column(String(500), default="")
    requires_credentials: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    last_success_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_status: Mapped[str] = mapped_column(String(24), default="never_run")


class PricingRecord(Base):
    """Append-only price observation."""

    __tablename__ = "pricing_records"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    config_id: Mapped[int] = mapped_column(ForeignKey("service_configurations.id", ondelete="CASCADE"), nullable=False)
    region_id: Mapped[int] = mapped_column(ForeignKey("regions.id", ondelete="CASCADE"), nullable=False)
    source_id: Mapped[int] = mapped_column(ForeignKey("pricing_sources.id"), nullable=False)
    sync_run_id: Mapped[Optional[int]] = mapped_column(ForeignKey("sync_runs.id", ondelete="SET NULL"))
    price: Mapped[Decimal] = mapped_column(Numeric(18, 8), nullable=False)
    currency: Mapped[str] = mapped_column(String(3), nullable=False)
    unit: Mapped[str] = mapped_column(String(32), nullable=False)  # e.g. hour, GB-month
    billing_model: Mapped[str] = mapped_column(String(32), default="on_demand")
    tier: Mapped[str] = mapped_column(String(64), default="")
    source_identifier: Mapped[str] = mapped_column(String(255), default="")  # provider's own SKU/rate id
    effective_date: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    retrieved_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    __table_args__ = (
        CheckConstraint("price >= 0", name="ck_price_nonneg"),
        Index("ix_price_lookup", "config_id", "region_id", "billing_model", "retrieved_at"),
    )


class SyncRun(Base):
    __tablename__ = "sync_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    source_id: Mapped[int] = mapped_column(ForeignKey("pricing_sources.id"), nullable=False, index=True)
    triggered_by: Mapped[str] = mapped_column(String(32), default="manual")  # manual | schedule | n8n
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(String(24), default="running")  # running | success | failed | rejected
    records_received: Mapped[int] = mapped_column(Integer, default=0)
    records_stored: Mapped[int] = mapped_column(Integer, default=0)
    records_rejected: Mapped[int] = mapped_column(Integer, default=0)
    error_summary: Mapped[str] = mapped_column(Text, default="")


class ProviderMetric(Base):
    """Non-price measurements (performance, reliability, security...). Must carry a source."""

    __tablename__ = "provider_metrics"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    provider_id: Mapped[int] = mapped_column(ForeignKey("providers.id", ondelete="CASCADE"), nullable=False, index=True)
    criterion_key: Mapped[str] = mapped_column(String(48), nullable=False)
    value: Mapped[float] = mapped_column(Float, nullable=False)
    unit: Mapped[str] = mapped_column(String(32), nullable=False)
    source: Mapped[str] = mapped_column(String(255), nullable=False)
    source_url: Mapped[str] = mapped_column(String(500), default="")
    measured_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    is_sample: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    __table_args__ = (Index("ix_metric_lookup", "provider_id", "criterion_key", "measured_at"),)


# ---------------------------------------------------------------- criteria & evaluations
class Criterion(Base, TimestampMixin):
    __tablename__ = "criteria"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key: Mapped[str] = mapped_column(String(48), unique=True, nullable=False)
    name_en: Mapped[str] = mapped_column(String(120), nullable=False)
    name_ar: Mapped[str] = mapped_column(String(120), default="")
    kind: Mapped[str] = mapped_column(String(8), nullable=False)  # benefit | cost
    unit: Mapped[str] = mapped_column(String(32), default="")
    data_source: Mapped[str] = mapped_column(String(16), default="metric")  # price | metric
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    __table_args__ = (CheckConstraint("kind in ('benefit','cost')", name="ck_criterion_kind"),)


class Evaluation(Base, TimestampMixin):
    __tablename__ = "evaluations"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(200), default="")
    status: Mapped[str] = mapped_column(String(16), default="completed")  # completed | failed
    requirements: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)  # region, profile, usage assumptions
    criteria_snapshot: Mapped[list[Any]] = mapped_column(JsonType, default=list)
    ahp_matrix: Mapped[list[Any]] = mapped_column(JsonType, default=list)
    ahp_result: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)  # weights, lambda_max, CI, CR
    decision_matrix: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)  # measurements + provenance
    topsis_result: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    algorithm_version: Mapped[str] = mapped_column(String(32), nullable=False)
    data_timestamps: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    cost_assumptions: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    idempotency_key: Mapped[Optional[str]] = mapped_column(String(64))
    results: Mapped[list["EvaluationResult"]] = relationship(
        back_populates="evaluation", cascade="all, delete-orphan", order_by="EvaluationResult.rank"
    )
    explanation: Mapped[Optional["Explanation"]] = relationship(
        back_populates="evaluation", cascade="all, delete-orphan", uselist=False
    )
    __table_args__ = (UniqueConstraint("owner_id", "idempotency_key", name="uq_eval_owner_idem"),)


class EvaluationResult(Base):
    __tablename__ = "evaluation_results"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    evaluation_id: Mapped[str] = mapped_column(ForeignKey("evaluations.id", ondelete="CASCADE"), nullable=False, index=True)
    provider_id: Mapped[int] = mapped_column(ForeignKey("providers.id"), nullable=False)
    rank: Mapped[Optional[int]] = mapped_column(Integer)  # null when ineligible
    closeness: Mapped[Optional[float]] = mapped_column(Float)
    d_plus: Mapped[Optional[float]] = mapped_column(Float)
    d_minus: Mapped[Optional[float]] = mapped_column(Float)
    eligible: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    ineligible_reason: Mapped[str] = mapped_column(String(255), default="")
    details: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    evaluation: Mapped[Evaluation] = relationship(back_populates="results")
    provider: Mapped[Provider] = relationship(lazy="joined")


class Explanation(Base):
    __tablename__ = "explanations"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    evaluation_id: Mapped[str] = mapped_column(ForeignKey("evaluations.id", ondelete="CASCADE"), unique=True, nullable=False)
    deterministic: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    sensitivity: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    ai_text: Mapped[Optional[str]] = mapped_column(Text)
    ai_model: Mapped[Optional[str]] = mapped_column(String(64))
    ai_generated_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    evaluation: Mapped[Evaluation] = relationship(back_populates="explanation")


class Report(Base, TimestampMixin):
    __tablename__ = "reports"
    id: Mapped[str] = mapped_column(String(32), primary_key=True, default=new_id)
    owner_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    evaluation_id: Mapped[str] = mapped_column(ForeignKey("evaluations.id", ondelete="CASCADE"), nullable=False)
    title: Mapped[str] = mapped_column(String(200), default="")
    body: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    ai_summary: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(16), default="ready")
    idempotency_key: Mapped[Optional[str]] = mapped_column(String(64))
    __table_args__ = (UniqueConstraint("owner_id", "idempotency_key", name="uq_report_owner_idem"),)


class Notification(Base):
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[str] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    kind: Mapped[str] = mapped_column(String(32), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    body: Mapped[str] = mapped_column(Text, default="")
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)


# ---------------------------------------------------------------- ops
class IntegrationSetting(Base, TimestampMixin):
    """Non-secret integration settings only. Secrets live in environment variables."""

    __tablename__ = "integration_settings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    key: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    value: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)


class AutomationRun(Base):
    __tablename__ = "automation_runs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    workflow: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    event_id: Mapped[str] = mapped_column(String(64), nullable=False)
    status: Mapped[str] = mapped_column(String(16), default="received")  # received | processed | failed | duplicate
    detail: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False)
    __table_args__ = (UniqueConstraint("workflow", "event_id", name="uq_automation_event"),)


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    actor_id: Mapped[Optional[str]] = mapped_column(String(32), index=True)
    action: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    target_type: Mapped[str] = mapped_column(String(48), default="")
    target_id: Mapped[str] = mapped_column(String(64), default="")
    detail: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)
    ip: Mapped[str] = mapped_column(String(64), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False, index=True)


class SystemConfig(Base, TimestampMixin):
    __tablename__ = "system_config"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[dict[str, Any]] = mapped_column(JsonType, default=dict)


class AiUsage(Base):
    __tablename__ = "ai_usage"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[Optional[str]] = mapped_column(String(32), index=True)
    feature: Mapped[str] = mapped_column(String(32), nullable=False)
    ok: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, nullable=False, index=True)

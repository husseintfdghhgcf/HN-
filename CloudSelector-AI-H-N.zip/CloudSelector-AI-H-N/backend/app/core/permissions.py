"""Role -> permission map. Seeded into the DB, enforced on the backend for every request."""

SUPER_ADMIN = "super_admin"
ADMIN = "admin"
CUSTOMER = "customer"
ROLES = (SUPER_ADMIN, ADMIN, CUSTOMER)

CUSTOMER_PERMS = {
    "profile:manage",
    "providers:read",
    "pricing:read",
    "criteria:read",
    "evaluations:own",
    "reports:own",
    "notifications:own",
    "ai:use",
}
ADMIN_PERMS = CUSTOMER_PERMS | {
    "catalog:manage",
    "pricing:sync",
    "criteria:manage",
    "users:read",
    "users:manage_customers",
    "dashboards:read",
    "automation:read",
    "notifications:manage",
    "ai:status",
}
SUPER_ADMIN_PERMS = ADMIN_PERMS | {
    "users:manage_admins",
    "roles:manage",
    "config:manage",
    "integrations:manage",
    "audit:read",
    "system:health",
}

ROLE_PERMISSIONS = {
    CUSTOMER: CUSTOMER_PERMS,
    ADMIN: ADMIN_PERMS,
    SUPER_ADMIN: SUPER_ADMIN_PERMS,
}

"""Application settings, loaded only from environment variables / .env (never hardcoded)."""
from functools import lru_cache
from typing import List

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "CloudSelector AI"
    environment: str = "development"  # development | test | production
    database_url: str = "postgresql+psycopg://cs:CHANGE_ME@localhost:5432/cloudselector"

    # Sessions / cookies
    session_cookie_name: str = "cs_session"
    csrf_cookie_name: str = "cs_csrf"
    session_ttl_hours: int = 12
    cookie_secure: bool = False  # MUST be true in production (HTTPS)
    cookie_samesite: str = "lax"
    secret_key: str = "CHANGE_ME_TO_A_LONG_RANDOM_VALUE"

    # CORS / redirects
    cors_origins: str = "http://localhost:8080,http://127.0.0.1:8080"
    frontend_base_url: str = "http://localhost:8080"

    # Rate limiting
    login_rate_limit: int = 10  # attempts
    login_rate_window_seconds: int = 300

    # Google OAuth / OIDC
    google_client_id: str = ""
    google_client_secret: str = ""
    google_redirect_uri: str = "http://localhost:8000/api/v1/auth/google/callback"

    # AI provider (server side only)
    ai_provider: str = "anthropic"
    ai_api_key: str = ""
    ai_model: str = ""
    ai_base_url: str = ""
    ai_timeout_seconds: int = 20
    ai_max_retries: int = 2
    ai_daily_request_limit: int = 200

    # n8n integration
    n8n_webhook_secret: str = ""  # shared HMAC secret for inbound/outbound webhooks
    n8n_base_url: str = ""
    n8n_outbound_timeout_seconds: int = 10

    # Pricing sync
    pricing_stale_after_hours: int = 72
    pricing_http_timeout_seconds: int = 20
    pricing_max_retries: int = 3

    gcp_billing_api_key: str = ""  # Cloud Billing Catalog API key (required for the GCP adapter)

    # Outbound email (SMTP). If unset, emails are NOT sent (development logs a notice only).
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_starttls: bool = True

    # First-admin bootstrap (one-time, documented)
    bootstrap_super_admin_email: str = ""
    bootstrap_super_admin_password: str = ""

    @field_validator("cookie_samesite")
    @classmethod
    def _samesite(cls, v: str) -> str:
        v = v.lower()
        if v not in {"lax", "strict", "none"}:
            raise ValueError("cookie_samesite must be lax, strict or none")
        return v

    @property
    def cors_origin_list(self) -> List[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()

"""Administration. Every route is permission-gated server-side; role rules are enforced here, not in the UI."""
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import func, select, text
from sqlalchemy.orm import Session

from app.adapters.registry import ADAPTERS
from app.api.deps import permissions_of, require
from app.core.config import get_settings
from app.core.permissions import ADMIN, CUSTOMER, ROLES, SUPER_ADMIN
from app.core.security import hash_password, validate_password_strength
from app.db.session import get_db
from app.models import (AuditLog, AutomationRun, Evaluation, PricingSource, Provider, Role, SyncRun, User)
from app.services import auth_service as svc
from app.services import google_oidc
from app.services.audit import audit
from app.services.pricing_sync import run_sync, source_health

router = APIRouter(prefix="/admin", tags=["admin"])


def _user_row(u: User) -> dict:
    return {"id": u.id, "email": u.email, "full_name": u.full_name, "role": u.role.name, "is_active": u.is_active,
            "email_verified": u.email_verified, "created_at": u.created_at, "last_login_at": u.last_login_at}


def _can_manage(actor: User, target_role: str) -> bool:
    perms = permissions_of(actor)
    if target_role == CUSTOMER:
        return "users:manage_customers" in perms
    return "users:manage_admins" in perms          # admin / super_admin targets: super admin only


# ------------------------------------------------------------------ users
@router.get("/users")
def list_users(role: Optional[str] = None, q: Optional[str] = Query(None, max_length=100),
               limit: int = Query(25, ge=1, le=100), offset: int = Query(0, ge=0),
               db: Session = Depends(get_db), actor: User = Depends(require("users:read"))):
    stmt = select(User).join(Role, User.role_id == Role.id).where(User.deleted_at.is_(None))
    if "users:manage_admins" not in permissions_of(actor):      # admins only see customers
        stmt = stmt.where(Role.name == CUSTOMER)
    if role:
        if role not in ROLES:
            raise HTTPException(422, "Unknown role")
        stmt = stmt.where(Role.name == role)
    if q:
        stmt = stmt.where(User.email.ilike(f"%{q.lower()}%"))
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(User.created_at.desc()).limit(limit).offset(offset)).unique().all()
    return {"total": total, "limit": limit, "offset": offset, "items": [_user_row(u) for u in rows]}


class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(max_length=128)
    role: str
    full_name: str = Field(default="", max_length=120)


@router.post("/users", status_code=201)
def create_user(body: UserCreate, request: Request, db: Session = Depends(get_db), actor: User = Depends(require("users:read"))):
    if body.role not in ROLES:
        raise HTTPException(422, "Unknown role")
    if not _can_manage(actor, body.role):
        raise HTTPException(403, "Insufficient permissions for this role")
    err = validate_password_strength(body.password)
    if err:
        raise HTTPException(422, err)
    if db.scalar(select(User).where(User.email == body.email.lower())):
        raise HTTPException(409, "Email already registered")
    u = User(email=body.email.lower(), password_hash=hash_password(body.password), full_name=body.full_name,
             role_id=svc.get_role(db, body.role).id, email_verified=False)
    db.add(u)
    db.flush()
    audit(db, "admin.user_created", actor.id, "user", u.id, {"role": body.role}, request)
    db.commit()
    return _user_row(u)


class UserPatch(BaseModel):
    is_active: Optional[bool] = None
    role: Optional[str] = None


def _super_admin_count(db: Session) -> int:
    return db.scalar(select(func.count()).select_from(User).join(Role, User.role_id == Role.id)
                     .where(Role.name == SUPER_ADMIN, User.is_active.is_(True), User.deleted_at.is_(None)))


@router.patch("/users/{uid}")
def patch_user(uid: str, body: UserPatch, request: Request, db: Session = Depends(get_db), actor: User = Depends(require("users:read"))):
    u = db.get(User, uid)
    if u is None or u.deleted_at is not None:
        raise HTTPException(404, "User not found")
    if not _can_manage(actor, u.role.name):
        raise HTTPException(403, "Insufficient permissions for this user")
    if u.id == actor.id:
        raise HTTPException(409, "You cannot change your own role or status")
    changes = {}
    if body.role is not None and body.role != u.role.name:
        if body.role not in ROLES:
            raise HTTPException(422, "Unknown role")
        if "roles:manage" not in permissions_of(actor):
            raise HTTPException(403, "Only a super administrator can change roles")
        if u.role.name == SUPER_ADMIN and _super_admin_count(db) <= 1:
            raise HTTPException(409, "Cannot demote the last super administrator")
        changes["role"] = body.role
        u.role_id = svc.get_role(db, body.role).id
    if body.is_active is not None and body.is_active != u.is_active:
        if not body.is_active and u.role.name == SUPER_ADMIN and _super_admin_count(db) <= 1:
            raise HTTPException(409, "Cannot disable the last super administrator")
        u.is_active = body.is_active
        changes["is_active"] = body.is_active
        if not body.is_active:
            svc.revoke_all_sessions(db, u.id)
    audit(db, "admin.user_updated", actor.id, "user", u.id, changes, request)
    db.commit()
    db.refresh(u)
    return _user_row(u)


@router.delete("/users/{uid}", status_code=204)
def delete_user(uid: str, request: Request, db: Session = Depends(get_db), actor: User = Depends(require("users:read"))):
    """Soft delete: account is disabled and sessions revoked; audit history is retained."""
    u = db.get(User, uid)
    if u is None or u.deleted_at is not None:
        raise HTTPException(404, "User not found")
    if not _can_manage(actor, u.role.name) or u.id == actor.id:
        raise HTTPException(403, "Insufficient permissions for this user")
    if u.role.name == SUPER_ADMIN and _super_admin_count(db) <= 1:
        raise HTTPException(409, "Cannot delete the last super administrator")
    u.is_active, u.deleted_at = False, datetime.now(timezone.utc)
    svc.revoke_all_sessions(db, u.id)
    audit(db, "admin.user_deleted", actor.id, "user", u.id, request=request)
    db.commit()


# ------------------------------------------------------------------ audit
@router.get("/audit")
def audit_log(action: Optional[str] = Query(None, max_length=64), limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
              db: Session = Depends(get_db), _: User = Depends(require("audit:read"))):
    stmt = select(AuditLog)
    if action:
        stmt = stmt.where(AuditLog.action == action)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(limit).offset(offset)).all()
    return {"total": total, "items": [{"id": a.id, "actor_id": a.actor_id, "action": a.action, "target_type": a.target_type,
                                       "target_id": a.target_id, "detail": a.detail, "ip": a.ip, "created_at": a.created_at} for a in rows]}


# ------------------------------------------------------------------ pricing sync
@router.get("/pricing/sources")
def pricing_sources(db: Session = Depends(get_db), _: User = Depends(require("pricing:sync"))):
    out = []
    for s in db.scalars(select(PricingSource).order_by(PricingSource.key)):
        h = source_health(s)
        a = ADAPTERS.get(s.key)
        h["configured"] = True if s.is_sample else bool(a and a.is_configured())
        h["status_note"] = ("NOT VERIFIED - CONFIGURATION REQUIRED" if (not s.is_sample and not h["configured"]) else
                            ("never synchronised" if s.last_success_at is None and not s.is_sample else ""))
        out.append(h)
    return {"items": out}


@router.post("/pricing/sources/{key}/sync")
def manual_sync(key: str, request: Request, db: Session = Depends(get_db), actor: User = Depends(require("pricing:sync"))):
    adapter = ADAPTERS.get(key)
    if adapter is None:
        raise HTTPException(404, "Unknown pricing source")
    src = db.scalar(select(PricingSource).where(PricingSource.key == key))
    if src is None or not src.enabled:
        raise HTTPException(409, "Pricing source is not registered or is disabled")
    run = run_sync(db, adapter, triggered_by="manual")
    audit(db, "pricing.sync_manual", actor.id, "pricing_source", key, {"status": run.status}, request)
    db.commit()
    return _run_out(run)


def _run_out(r: SyncRun) -> dict:
    return {"id": r.id, "source_id": r.source_id, "triggered_by": r.triggered_by, "status": r.status,
            "started_at": r.started_at, "finished_at": r.finished_at, "records_received": r.records_received,
            "records_stored": r.records_stored, "records_rejected": r.records_rejected, "error_summary": r.error_summary}


@router.get("/pricing/sync-runs")
def sync_runs(limit: int = Query(25, ge=1, le=100), offset: int = Query(0, ge=0), status: Optional[str] = None,
              db: Session = Depends(get_db), _: User = Depends(require("pricing:sync"))):
    stmt = select(SyncRun)
    if status:
        stmt = stmt.where(SyncRun.status == status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    return {"total": total, "items": [_run_out(r) for r in db.scalars(stmt.order_by(SyncRun.started_at.desc()).limit(limit).offset(offset))]}


# ------------------------------------------------------------------ automation, dashboard, health
@router.get("/automation/runs")
def automation_runs(limit: int = Query(50, ge=1, le=200), db: Session = Depends(get_db), _: User = Depends(require("automation:read"))):
    s = get_settings()
    rows = db.scalars(select(AutomationRun).order_by(AutomationRun.created_at.desc()).limit(limit)).all()
    return {"n8n_configured": bool(s.n8n_base_url and s.n8n_webhook_secret),
            "items": [{"workflow": r.workflow, "event_id": r.event_id, "status": r.status, "detail": r.detail, "created_at": r.created_at} for r in rows]}


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), _: User = Depends(require("dashboards:read"))):
    users = dict(db.execute(select(Role.name, func.count(User.id)).join(User, User.role_id == Role.id)
                            .where(User.deleted_at.is_(None)).group_by(Role.name)).all())
    return {"users_by_role": users, "providers": db.scalar(select(func.count()).select_from(Provider)),
            "evaluations_total": db.scalar(select(func.count()).select_from(Evaluation)),
            "sync_failures_24h": db.scalar(select(func.count()).select_from(SyncRun).where(
                SyncRun.status.in_(("failed", "rejected")), SyncRun.started_at > func.now() - text("interval '24 hours'")))}


@router.get("/health")
def system_health(db: Session = Depends(get_db), _: User = Depends(require("system:health"))):
    """Booleans and counts only: no secrets, hostnames or connection strings."""
    s = get_settings()
    rev = db.execute(text("select version_num from alembic_version")).scalar()
    return {"database": "ok", "migration_revision": rev,
            "google_sign_in_configured": google_oidc.is_configured(),
            "ai_configured": bool(s.ai_api_key), "n8n_configured": bool(s.n8n_base_url and s.n8n_webhook_secret),
            "smtp_configured": bool(s.smtp_host and s.smtp_from), "gcp_pricing_key_configured": bool(s.gcp_billing_api_key),
            "environment": s.environment}

"""Providers, criteria, pricing (read) and catalog administration."""
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import require
from app.db.session import get_db
from app.models import (Criterion, PricingRecord, PricingSource, Provider, ProviderMetric, Region, Service,
                        ServiceConfiguration, User)
from app.services.audit import audit

router = APIRouter(tags=["catalog"])


def _provider_out(p: Provider, db: Session) -> dict:
    metrics = {}
    for m in db.scalars(select(ProviderMetric).where(ProviderMetric.provider_id == p.id)
                        .order_by(ProviderMetric.measured_at.asc(), ProviderMetric.id.asc())):
        metrics[m.criterion_key] = {"value": m.value, "unit": m.unit, "source": m.source, "source_url": m.source_url,
                                    "measured_at": m.measured_at, "is_sample": m.is_sample}
    regions = db.scalar(select(func.count()).select_from(Region).where(Region.provider_id == p.id))
    return {"slug": p.slug, "name": p.name, "description": p.description, "website": p.website,
            "is_active": p.is_active, "region_count": regions, "metrics": metrics}


@router.get("/providers")
def list_providers(db: Session = Depends(get_db), _: User = Depends(require("providers:read"))):
    return {"items": [_provider_out(p, db) for p in db.scalars(select(Provider).where(Provider.is_active.is_(True)).order_by(Provider.slug))]}


@router.get("/providers/{slug}")
def get_provider(slug: str, db: Session = Depends(get_db), _: User = Depends(require("providers:read"))):
    p = db.scalar(select(Provider).where(Provider.slug == slug))
    if not p:
        raise HTTPException(404, "Provider not found")
    return _provider_out(p, db)


class ProviderIn(BaseModel):
    slug: str = Field(pattern="^[a-z0-9][a-z0-9_-]{1,30}$")
    name: str = Field(min_length=2, max_length=120)
    description: str = Field(default="", max_length=2000)
    website: str = Field(default="", max_length=255)


@router.post("/providers", status_code=201)
def create_provider(body: ProviderIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("catalog:manage"))):
    if db.scalar(select(Provider).where(Provider.slug == body.slug)):
        raise HTTPException(409, "Provider slug already exists")
    p = Provider(**body.model_dump())
    db.add(p)
    db.flush()
    audit(db, "catalog.provider_created", user.id, "provider", p.slug, request=request)
    db.commit()
    return _provider_out(p, db)


class ProviderPatch(BaseModel):
    name: Optional[str] = Field(default=None, min_length=2, max_length=120)
    description: Optional[str] = Field(default=None, max_length=2000)
    website: Optional[str] = Field(default=None, max_length=255)
    is_active: Optional[bool] = None


@router.patch("/providers/{slug}")
def patch_provider(slug: str, body: ProviderPatch, request: Request, db: Session = Depends(get_db), user: User = Depends(require("catalog:manage"))):
    p = db.scalar(select(Provider).where(Provider.slug == slug))
    if not p:
        raise HTTPException(404, "Provider not found")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(p, k, v)
    audit(db, "catalog.provider_updated", user.id, "provider", slug, body.model_dump(exclude_unset=True), request)
    db.commit()
    return _provider_out(p, db)


class MetricIn(BaseModel):
    criterion_key: str = Field(max_length=48)
    value: float
    unit: str = Field(min_length=1, max_length=32)
    source: str = Field(min_length=3, max_length=255)   # a source is mandatory: no unsourced numbers
    source_url: str = Field(default="", max_length=500)


@router.post("/providers/{slug}/metrics", status_code=201)
def record_metric(slug: str, body: MetricIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("catalog:manage"))):
    p = db.scalar(select(Provider).where(Provider.slug == slug))
    crit = db.scalar(select(Criterion).where(Criterion.key == body.criterion_key))
    if not p or not crit:
        raise HTTPException(404, "Provider or criterion not found")
    if crit.data_source != "metric":
        raise HTTPException(422, "This criterion is derived from pricing data, not a recorded metric")
    if body.value < 0 or body.value != body.value:
        raise HTTPException(422, "Value must be a non-negative number")
    db.add(ProviderMetric(provider_id=p.id, criterion_key=crit.key, value=body.value, unit=body.unit,
                          source=body.source, source_url=body.source_url, is_sample=False))
    audit(db, "catalog.metric_recorded", user.id, "provider", slug, {"criterion": crit.key}, request)
    db.commit()
    return {"message": "Metric recorded"}


# ---------------------------------------------------------------- criteria
def _crit_out(c: Criterion) -> dict:
    return {"key": c.key, "name_en": c.name_en, "name_ar": c.name_ar, "kind": c.kind, "unit": c.unit,
            "data_source": c.data_source, "is_active": c.is_active}


@router.get("/criteria")
def list_criteria(db: Session = Depends(get_db), _: User = Depends(require("criteria:read"))):
    return {"items": [_crit_out(c) for c in db.scalars(select(Criterion).order_by(Criterion.id))]}


class CriterionIn(BaseModel):
    key: str = Field(pattern="^[a-z][a-z0-9_]{1,46}$")
    name_en: str = Field(min_length=2, max_length=120)
    name_ar: str = Field(default="", max_length=120)
    kind: str = Field(pattern="^(benefit|cost)$")
    unit: str = Field(min_length=1, max_length=32)
    data_source: str = Field(default="metric", pattern="^(metric|price)$")


@router.post("/criteria", status_code=201)
def create_criterion(body: CriterionIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require("criteria:manage"))):
    if db.scalar(select(Criterion).where(Criterion.key == body.key)):
        raise HTTPException(409, "Criterion key already exists")
    c = Criterion(**body.model_dump())
    db.add(c)
    audit(db, "criteria.created", user.id, "criterion", body.key, request=request)
    db.commit()
    return _crit_out(c)


class CriterionPatch(BaseModel):
    name_en: Optional[str] = Field(default=None, max_length=120)
    name_ar: Optional[str] = Field(default=None, max_length=120)
    is_active: Optional[bool] = None


@router.patch("/criteria/{key}")
def patch_criterion(key: str, body: CriterionPatch, request: Request, db: Session = Depends(get_db), user: User = Depends(require("criteria:manage"))):
    c = db.scalar(select(Criterion).where(Criterion.key == key))
    if not c:
        raise HTTPException(404, "Criterion not found")
    # kind/unit/data_source are immutable: historical evaluations snapshot them, and changing them
    # would silently change how past and future results compare.
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(c, k, v)
    audit(db, "criteria.updated", user.id, "criterion", key, body.model_dump(exclude_unset=True), request)
    db.commit()
    return _crit_out(c)


# ---------------------------------------------------------------- pricing (read)
@router.get("/pricing/history")
def pricing_history(
    provider: str, profile: str, region: Optional[str] = None,
    limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
    db: Session = Depends(get_db), _: User = Depends(require("pricing:read")),
):
    p = db.scalar(select(Provider).where(Provider.slug == provider))
    if not p:
        raise HTTPException(404, "Provider not found")
    q = (select(PricingRecord, Region, ServiceConfiguration, PricingSource)
         .join(ServiceConfiguration, PricingRecord.config_id == ServiceConfiguration.id)
         .join(Service, ServiceConfiguration.service_id == Service.id)
         .join(Region, PricingRecord.region_id == Region.id)
         .join(PricingSource, PricingRecord.source_id == PricingSource.id)
         .where(Service.provider_id == p.id, ServiceConfiguration.profile == profile))
    if region:
        q = q.where(Region.code == region)
    total = db.scalar(select(func.count()).select_from(q.subquery()))
    rows = db.execute(q.order_by(PricingRecord.retrieved_at.desc(), PricingRecord.id.desc()).limit(limit).offset(offset)).all()
    return {"total": total, "limit": limit, "offset": offset, "items": [
        {"price": str(r.price), "currency": r.currency, "unit": r.unit, "billing_model": r.billing_model,
         "tier": r.tier, "region": reg.code, "sku": cfg.sku, "source": src.name, "source_identifier": r.source_identifier,
         "effective_date": r.effective_date, "retrieved_at": r.retrieved_at, "is_sample": r.is_sample}
        for r, reg, cfg, src in rows]}


@router.get("/pricing/options")
def pricing_options(db: Session = Depends(get_db), _: User = Depends(require("pricing:read"))):
    """Comparable profiles and the regions (geographies) where each has price data, with provider coverage.

    Lets the UI offer only scenarios that can actually be evaluated, and be honest about coverage.
    """
    rows = db.execute(
        select(ServiceConfiguration.profile, Region.geography, func.count(func.distinct(Service.provider_id)))
        .join(Service, ServiceConfiguration.service_id == Service.id)
        .join(PricingRecord, PricingRecord.config_id == ServiceConfiguration.id)
        .join(Region, PricingRecord.region_id == Region.id)
        .join(Provider, Service.provider_id == Provider.id)
        .where(Provider.is_active.is_(True), Region.geography != "")
        .group_by(ServiceConfiguration.profile, Region.geography)
        .order_by(ServiceConfiguration.profile, Region.geography)
    ).all()
    out: dict[str, list] = {}
    for profile, geo, n in rows:
        out.setdefault(profile, []).append({"region": geo, "providers": n})
    return {"profiles": [{"profile": k, "regions": v} for k, v in out.items()]}

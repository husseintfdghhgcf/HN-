from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from fastapi.responses import RedirectResponse
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api import schemas
from app.api.deps import get_current_session, get_current_user
from app.core.config import get_settings
from app.core.permissions import CUSTOMER
from app.core.ratelimit import limiter
from app.core.security import (
    hash_password,
    validate_password_strength,
    verify_password,
)
from app.db.session import get_db
from app.models import AuthIdentity, AuthSession, User
from app.services import auth_service as svc
from app.services import google_oidc
from app.services.audit import audit
from app.services.mail import send_email

router = APIRouter(prefix="/auth", tags=["auth"])

MAX_FAILED = 5
LOCK_MINUTES = 15
GENERIC_LOGIN_ERROR = "Invalid email or password"


def _client_key(request: Request, extra: str = "") -> str:
    ip = request.client.host if request.client else "unknown"
    return f"{ip}:{extra}"


def _rate_limit(request: Request, bucket: str, extra: str = "") -> None:
    s = get_settings()
    if not limiter.check(f"{bucket}:{_client_key(request, extra)}", s.login_rate_limit, s.login_rate_window_seconds):
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS, "Too many attempts. Try again later.")


@router.post("/register", status_code=201)
def register(body: schemas.RegisterIn, request: Request, response: Response, db: Session = Depends(get_db)):
    _rate_limit(request, "register")
    err = validate_password_strength(body.password)
    if err:
        raise HTTPException(422, err)
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Unable to register with these details")
    user = User(
        email=email, password_hash=hash_password(body.password), full_name=body.full_name.strip(),
        organization=body.organization.strip(), locale=body.locale, role_id=svc.get_role(db, CUSTOMER).id,
    )
    db.add(user)
    db.flush()
    raw = svc.issue_one_time_token(db, user, "verify_email", ttl_minutes=60 * 24)
    link = f"{get_settings().frontend_base_url}/verify-email.html?token={raw}"
    sent = send_email(email, "Verify your CloudSelector AI email", f"Open this link to verify your email:\n{link}\n")
    sess = svc.create_session(db, user, request, response)
    audit(db, "auth.register", user.id, "user", user.id, request=request)
    db.commit()
    from app.services import n8n
    n8n.emit_event_safely("user.registered", {"user_id": user.id, "email": user.email, "locale": user.locale})
    return {"user": svc.user_out(user), "verification_email_sent": sent, "csrf_token": sess.csrf_token}


@router.post("/login")
def login(body: schemas.LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    email = body.email.lower()
    _rate_limit(request, "login", email)
    user = db.scalar(select(User).where(User.email == email))
    now = datetime.now(timezone.utc)
    if user and user.locked_until and user.locked_until > now:
        raise HTTPException(status.HTTP_423_LOCKED, "Account temporarily locked. Try again later.")
    ok = verify_password(body.password, user.password_hash if user else None)
    if not user or not ok or not user.is_active or user.deleted_at is not None:
        if user and not ok:
            user.failed_logins += 1
            if user.failed_logins >= MAX_FAILED:
                user.locked_until = now + timedelta(minutes=LOCK_MINUTES)
                user.failed_logins = 0
                audit(db, "auth.lockout", user.id, "user", user.id, request=request)
            db.commit()
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, GENERIC_LOGIN_ERROR)
    user.failed_logins, user.locked_until, user.last_login_at = 0, None, now
    sess = svc.create_session(db, user, request, response)
    audit(db, "auth.login", user.id, "user", user.id, request=request)
    db.commit()
    return {"user": svc.user_out(user), "csrf_token": sess.csrf_token}


@router.post("/logout", status_code=200)
def logout(request: Request, response: Response, sess: AuthSession = Depends(get_current_session), db: Session = Depends(get_db)):
    sess.revoked_at = datetime.now(timezone.utc)
    audit(db, "auth.logout", sess.user_id, "session", str(sess.id), request=request)
    db.commit()
    svc.clear_cookies(response)
    return {"message": "Signed out"}


@router.get("/me")
def me(sess: AuthSession = Depends(get_current_session)):
    # csrf_token lets a frontend on another origin (where it cannot read our cookie) send X-CSRF-Token.
    return {"user": svc.user_out(sess.user), "csrf_token": sess.csrf_token}


@router.patch("/me")
def update_profile(body: schemas.ProfileUpdate, request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    data = body.model_dump(exclude_unset=True)
    for field in ("full_name", "organization", "locale"):
        if data.get(field) is not None:
            setattr(user, field, data[field].strip() if isinstance(data[field], str) else data[field])
    if data.get("preferences") is not None:
        if len(str(data["preferences"])) > 4000:
            raise HTTPException(422, "Preferences too large")
        user.preferences = data["preferences"]
    audit(db, "profile.update", user.id, "user", user.id, request=request)
    db.commit()
    return {"user": svc.user_out(user)}


@router.post("/change-password")
def change_password(body: schemas.PasswordChange, request: Request, sess: AuthSession = Depends(get_current_session), db: Session = Depends(get_db)):
    user = sess.user
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Current password is incorrect")
    err = validate_password_strength(body.new_password)
    if err:
        raise HTTPException(422, err)
    user.password_hash = hash_password(body.new_password)
    for other in db.scalars(select(AuthSession).where(AuthSession.user_id == user.id, AuthSession.revoked_at.is_(None))):
        if other.id != sess.id:
            other.revoked_at = datetime.now(timezone.utc)
    audit(db, "auth.password_change", user.id, "user", user.id, request=request)
    db.commit()
    return {"message": "Password updated"}


@router.post("/forgot-password", status_code=202)
def forgot_password(body: schemas.ForgotIn, request: Request, db: Session = Depends(get_db)):
    _rate_limit(request, "forgot", body.email.lower())
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if user and user.is_active and user.deleted_at is None:
        raw = svc.issue_one_time_token(db, user, "reset_password", ttl_minutes=30)
        link = f"{get_settings().frontend_base_url}/reset-password.html?token={raw}"
        send_email(user.email, "Reset your CloudSelector AI password", f"Open this link within 30 minutes:\n{link}\n")
        audit(db, "auth.password_reset_requested", user.id, "user", user.id, request=request)
        db.commit()
    # Identical response whether or not the account exists.
    return {"message": "If that email is registered, a reset link has been sent."}


@router.post("/reset-password")
def reset_password(body: schemas.ResetIn, request: Request, db: Session = Depends(get_db)):
    _rate_limit(request, "reset")
    err = validate_password_strength(body.new_password)
    if err:
        raise HTTPException(422, err)
    user = svc.consume_one_time_token(db, body.token, "reset_password")
    if not user:
        raise HTTPException(400, "Invalid or expired token")
    user.password_hash = hash_password(body.new_password)
    user.failed_logins, user.locked_until = 0, None
    svc.revoke_all_sessions(db, user.id)
    audit(db, "auth.password_reset", user.id, "user", user.id, request=request)
    db.commit()
    return {"message": "Password has been reset. Please sign in."}


@router.post("/verify-email")
def verify_email(body: schemas.VerifyIn, request: Request, db: Session = Depends(get_db)):
    user = svc.consume_one_time_token(db, body.token, "verify_email")
    if not user:
        raise HTTPException(400, "Invalid or expired token")
    user.email_verified = True
    audit(db, "auth.email_verified", user.id, "user", user.id, request=request)
    db.commit()
    return {"message": "Email verified"}


@router.post("/resend-verification", status_code=202)
def resend_verification(request: Request, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    _rate_limit(request, "resend", user.id)
    if user.email_verified:
        return {"message": "Email already verified", "sent": False}
    raw = svc.issue_one_time_token(db, user, "verify_email", ttl_minutes=60 * 24)
    link = f"{get_settings().frontend_base_url}/verify-email.html?token={raw}"
    sent = send_email(user.email, "Verify your CloudSelector AI email", f"Open this link to verify your email:\n{link}\n")
    db.commit()
    return {"message": "Verification email requested", "sent": sent}


# ------------------------------------------------------------------ Google
def _state_serializer() -> URLSafeTimedSerializer:
    return URLSafeTimedSerializer(get_settings().secret_key, salt="google-oidc-state")


@router.get("/google/status")
def google_status():
    """Reports only whether Google sign-in is configured; never any secret."""
    return {"configured": google_oidc.is_configured()}


@router.get("/google/start")
def google_start():
    if not google_oidc.is_configured():
        raise HTTPException(503, "Google sign-in is not configured")
    s = get_settings()
    state, nonce = google_oidc.new_state_and_nonce()
    resp = RedirectResponse(google_oidc.build_authorization_url(state, nonce), status_code=302)
    resp.set_cookie(
        "cs_oidc", _state_serializer().dumps({"state": state, "nonce": nonce}),
        max_age=600, httponly=True, secure=s.cookie_secure, samesite="lax", path="/api/v1/auth/google",
    )
    return resp


def _fail_redirect(reason: str) -> RedirectResponse:
    base = get_settings().frontend_base_url
    resp = RedirectResponse(f"{base}/index.html?auth_error={reason}", status_code=302)
    resp.delete_cookie("cs_oidc", path="/api/v1/auth/google")
    return resp


@router.get("/google/callback")
def google_callback(request: Request, code: str | None = None, state: str | None = None, error: str | None = None, db: Session = Depends(get_db)):
    if error:  # user cancelled or Google reported an error
        return _fail_redirect("google_cancelled")
    if not code or not state:
        return _fail_redirect("google_invalid")
    cookie = request.cookies.get("cs_oidc")
    try:
        saved = _state_serializer().loads(cookie or "", max_age=600)
    except (BadSignature, SignatureExpired):
        return _fail_redirect("google_state")
    if saved.get("state") != state:
        return _fail_redirect("google_state")
    try:
        claims = google_oidc.validate_id_token(google_oidc.exchange_code(code), saved["nonce"])
    except google_oidc.GoogleAuthError:
        return _fail_redirect("google_invalid")

    email, sub = claims["email"].lower(), claims["sub"]
    identity = db.scalar(select(AuthIdentity).where(AuthIdentity.provider == "google", AuthIdentity.subject == sub))
    if identity:
        user = identity.user
    else:
        user = db.scalar(select(User).where(User.email == email))
        if user is None:
            user = User(
                email=email, password_hash=None, full_name=claims.get("name", "")[:120],
                role_id=svc.get_role(db, CUSTOMER).id, email_verified=True,
            )
            db.add(user)
            db.flush()
        else:
            # Safe linking: Google asserts the email is verified. If the local account's email
            # was never verified, drop its password so a pre-registered attacker cannot keep access.
            if not user.email_verified:
                user.password_hash = None
                user.email_verified = True
        db.add(AuthIdentity(user_id=user.id, provider="google", subject=sub, email=email))
        audit(db, "auth.google_linked", user.id, "user", user.id, request=request)
    if not user.is_active or user.deleted_at is not None:
        return _fail_redirect("account_disabled")
    user.last_login_at = datetime.now(timezone.utc)
    resp = RedirectResponse(f"{get_settings().frontend_base_url}/dashboard.html", status_code=302)
    svc.create_session(db, user, request, resp)
    resp.delete_cookie("cs_oidc", path="/api/v1/auth/google")
    audit(db, "auth.google_login", user.id, "user", user.id, request=request)
    db.commit()
    return resp

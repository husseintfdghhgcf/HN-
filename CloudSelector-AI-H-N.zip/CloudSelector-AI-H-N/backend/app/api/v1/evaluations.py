"""Evaluations (AHP + TOPSIS), reports and notifications. All reads are scoped to the owner."""
from typing import Any, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import require
from app.db.session import get_db
from app.models import Evaluation, Notification, Report, User
from app.services.audit import audit
from app.engine.ahp import AhpValidationError, compute_ahp, explain_weights
from app.services.evaluation_service import EvaluationError, run_evaluation

router = APIRouter(tags=["evaluations"])


class Requirements(BaseModel):
    profile: str = Field(min_length=1, max_length=64)
    region: str = Field(min_length=1, max_length=64)      # geography, e.g. "europe"
    hours_per_month: float = Field(default=730, gt=0, le=744)


class EvaluationIn(BaseModel):
    title: str = Field(default="", max_length=200)
    criteria: list[str] = Field(min_length=2, max_length=15)
    pairwise_matrix: list[list[float]]
    requirements: Requirements
    providers: Optional[list[str]] = Field(default=None, max_length=20)
    missing_policy: str = Field(default="exclude_alternative", pattern="^(exclude_alternative|drop_criterion)$")


class AhpPreviewIn(BaseModel):
    criteria: list[str] = Field(min_length=2, max_length=15)
    pairwise_matrix: list[list[float]]


@router.post("/ahp/preview")
def ahp_preview(body: AhpPreviewIn, _: User = Depends(require("evaluations:own"))):
    """Weights and consistency for a draft comparison matrix. Nothing is stored; invalid input is reported, never corrected."""
    try:
        res = compute_ahp(body.criteria, body.pairwise_matrix)
    except AhpValidationError as exc:
        raise HTTPException(422, {"message": f"Invalid pairwise matrix: {exc}"})
    d = res.as_dict()
    d["derivation"] = explain_weights(res)
    return d


def _summary(ev: Evaluation) -> dict:
    return {"id": ev.id, "title": ev.title, "status": ev.status, "created_at": ev.created_at,
            "algorithm_version": ev.algorithm_version,
            "top": next((r.provider.slug for r in ev.results if r.rank == 1), None),
            "criteria": [c["key"] for c in ev.criteria_snapshot]}


def _detail(ev: Evaluation) -> dict:
    d = _summary(ev)
    d.update({
        "requirements": ev.requirements, "criteria_snapshot": ev.criteria_snapshot, "ahp_matrix": ev.ahp_matrix,
        "ahp": ev.ahp_result, "decision_matrix": ev.decision_matrix, "data_timestamps": ev.data_timestamps,
        "cost_assumptions": ev.cost_assumptions,
        "results": [{"provider": r.provider.slug, "provider_name": r.provider.name, "rank": r.rank,
                     "closeness": r.closeness, "d_plus": r.d_plus, "d_minus": r.d_minus, "eligible": r.eligible,
                     "ineligible_reason": r.ineligible_reason} for r in ev.results],
    })
    return d


def _own(db: Session, eval_id: str, user: User) -> Evaluation:
    ev = db.get(Evaluation, eval_id)
    if ev is None or ev.owner_id != user.id:   # 404, not 403: don't reveal that the id exists
        raise HTTPException(404, "Evaluation not found")
    return ev


@router.post("/evaluations", status_code=201)
def create_evaluation(body: EvaluationIn, request: Request, idempotency_key: Optional[str] = Header(default=None, max_length=64),
                      db: Session = Depends(get_db), user: User = Depends(require("evaluations:own"))):
    payload = body.model_dump()
    payload["idempotency_key"] = idempotency_key
    try:
        ev = run_evaluation(db, user.id, payload)
    except EvaluationError as exc:
        raise HTTPException(422, {"message": str(exc), **exc.detail})
    audit(db, "evaluation.created", user.id, "evaluation", ev.id, request=request)
    db.add(Notification(user_id=user.id, kind="evaluation_completed", title="Evaluation completed",
                        body=ev.title or ev.id))
    db.commit()
    from app.services import n8n
    n8n.emit_event_safely("evaluation.completed", {"evaluation_id": ev.id, "user_id": user.id})
    return _detail(ev)


@router.get("/evaluations")
def list_evaluations(limit: int = Query(20, ge=1, le=100), offset: int = Query(0, ge=0),
                     db: Session = Depends(get_db), user: User = Depends(require("evaluations:own"))):
    base = select(Evaluation).where(Evaluation.owner_id == user.id)
    total = db.scalar(select(func.count()).select_from(base.subquery()))
    items = db.scalars(base.order_by(Evaluation.created_at.desc()).limit(limit).offset(offset)).all()
    return {"total": total, "limit": limit, "offset": offset, "items": [_summary(e) for e in items]}


@router.get("/evaluations/{eval_id}")
def get_evaluation(eval_id: str, db: Session = Depends(get_db), user: User = Depends(require("evaluations:own"))):
    return _detail(_own(db, eval_id, user))


@router.get("/evaluations/{eval_id}/explanation")
def get_explanation(eval_id: str, db: Session = Depends(get_db), user: User = Depends(require("evaluations:own"))):
    ev = _own(db, eval_id, user)
    ex = ev.explanation
    return {"deterministic": ex.deterministic, "sensitivity": ex.sensitivity,
            "ai": {"text": ex.ai_text, "model": ex.ai_model, "generated_at": ex.ai_generated_at,
                   "label": "AI-generated wording of the calculated results; it does not change scores"} if ex.ai_text else None}


@router.delete("/evaluations/{eval_id}", status_code=204)
def delete_evaluation(eval_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(require("evaluations:own"))):
    ev = _own(db, eval_id, user)
    audit(db, "evaluation.deleted", user.id, "evaluation", ev.id, request=request)
    db.delete(ev)
    db.commit()


# ---------------------------------------------------------------- reports
def _report_out(r: Report, full: bool = False) -> dict:
    d = {"id": r.id, "evaluation_id": r.evaluation_id, "title": r.title, "status": r.status,
         "created_at": r.created_at, "ai_summary": r.ai_summary}
    if full:
        d["body"] = r.body
    return d


def build_report_body(ev: Evaluation) -> dict[str, Any]:
    d = _detail(ev)
    return {"evaluation": {"id": d["id"], "title": d["title"], "created_at": d["created_at"].isoformat(),
                           "algorithm_version": d["algorithm_version"], "requirements": d["requirements"]},
            "ranking": d["results"], "weights": d["ahp"]["weights"], "criteria": d["ahp"]["criteria"],
            "consistency_ratio": d["ahp"]["consistency_ratio"],
            "explanation_summary": ev.explanation.deterministic.get("summary", []),
            "uncertainty": ev.explanation.deterministic.get("uncertainty", []),
            "cost_assumptions": d["cost_assumptions"], "data_timestamps": d["data_timestamps"]}


class ReportIn(BaseModel):
    evaluation_id: str = Field(max_length=32)
    title: str = Field(default="", max_length=200)


@router.post("/reports", status_code=201)
def create_report(body: ReportIn, request: Request, idempotency_key: Optional[str] = Header(default=None, max_length=64),
                  db: Session = Depends(get_db), user: User = Depends(require("reports:own"))):
    ev = _own(db, body.evaluation_id, user)
    if idempotency_key:
        ex = db.scalar(select(Report).where(Report.owner_id == user.id, Report.idempotency_key == idempotency_key))
        if ex:
            return _report_out(ex, True)
    r = Report(owner_id=user.id, evaluation_id=ev.id, title=body.title or f"Report: {ev.title or ev.id}",
               body=build_report_body(ev), idempotency_key=idempotency_key)
    db.add(r)
    audit(db, "report.created", user.id, "report", r.id, request=request)
    db.commit()
    return _report_out(r, True)


@router.get("/reports")
def list_reports(limit: int = Query(20, ge=1, le=100), offset: int = Query(0, ge=0),
                 db: Session = Depends(get_db), user: User = Depends(require("reports:own"))):
    base = select(Report).where(Report.owner_id == user.id)
    total = db.scalar(select(func.count()).select_from(base.subquery()))
    items = db.scalars(base.order_by(Report.created_at.desc()).limit(limit).offset(offset)).all()
    return {"total": total, "items": [_report_out(r) for r in items]}


@router.get("/reports/{rid}")
def get_report(rid: str, db: Session = Depends(get_db), user: User = Depends(require("reports:own"))):
    r = db.get(Report, rid)
    if r is None or r.owner_id != user.id:
        raise HTTPException(404, "Report not found")
    return _report_out(r, True)


# ---------------------------------------------------------------- notifications
@router.get("/notifications")
def list_notifications(db: Session = Depends(get_db), user: User = Depends(require("notifications:own"))):
    rows = db.scalars(select(Notification).where(Notification.user_id == user.id).order_by(Notification.created_at.desc()).limit(50)).all()
    return {"items": [{"id": n.id, "kind": n.kind, "title": n.title, "body": n.body, "read": n.read_at is not None,
                       "created_at": n.created_at} for n in rows],
            "unread": sum(1 for n in rows if n.read_at is None)}


@router.post("/notifications/{nid}/read")
def mark_read(nid: int, db: Session = Depends(get_db), user: User = Depends(require("notifications:own"))):
    from datetime import datetime, timezone
    n = db.get(Notification, nid)
    if n is None or n.user_id != user.id:
        raise HTTPException(404, "Notification not found")
    n.read_at = n.read_at or datetime.now(timezone.utc)
    db.commit()
    return {"message": "ok"}

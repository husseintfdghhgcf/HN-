from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.api.deps import permissions_of, require
from app.api.v1.evaluations import _own
from app.core.config import get_settings
from app.db.session import get_db
from app.models import AiUsage, Criterion, Report, User
from app.services import ai as ai_service
from app.services.audit import audit

router = APIRouter(prefix="/ai", tags=["ai"])
eval_router = APIRouter(tags=["ai"])

MESSAGES = {"timeout": "The AI service timed out.", "rate_limited": "The AI service is busy. Try again later.",
            "provider_error": "The AI service returned an error.", "auth": "The AI service rejected the configured credentials.",
            "bad_output": "The AI service returned an unusable response.",
            "ungrounded": "The AI text was discarded because it contained figures not present in the verified results."}


def _guard(db: Session, user: User, feature: str) -> None:
    if not ai_service.is_configured():
        raise HTTPException(503, "AI features are not configured on this server. Calculated results are unaffected.")
    since = datetime.now(timezone.utc) - timedelta(days=1)
    used = db.scalar(select(func.count()).select_from(AiUsage).where(AiUsage.user_id == user.id, AiUsage.created_at > since))
    if used >= get_settings().ai_daily_request_limit:
        raise HTTPException(429, "Daily AI usage limit reached")


def _run(db: Session, user: User, feature: str, fn):
    try:
        out = fn()
        db.add(AiUsage(user_id=user.id, feature=feature, ok=True))
        return out
    except ai_service.AiError as exc:
        db.add(AiUsage(user_id=user.id, feature=feature, ok=False))
        db.commit()
        code = 502 if exc.category != "ungrounded" else 422
        raise HTTPException(code, MESSAGES.get(exc.category, "AI request failed"))


@router.get("/availability")
def availability(_: User = Depends(require("ai:use"))):
    return {"available": ai_service.is_configured()}


@router.get("/status")
def ai_status(_: User = Depends(require("ai:status"))):
    """Configuration state only. The key is never returned."""
    return ai_service.status()


@router.post("/status/check")
def ai_check(db: Session = Depends(get_db), user: User = Depends(require("ai:status"))):
    if not ai_service.is_configured():
        return {"ok": False, "category": "not_configured"}
    try:
        ai_service.complete("Reply with the single word: ok", "ping")
        return {"ok": True, "category": "ok"}
    except ai_service.AiError as exc:
        return {"ok": False, "category": exc.category}


@eval_router.post("/evaluations/{eval_id}/ai-explanation")
def ai_explanation(eval_id: str, request: Request, db: Session = Depends(get_db), user: User = Depends(require("ai:use"))):
    ev = _own(db, eval_id, user)
    _guard(db, user, "explanation")
    ex = ev.explanation
    facts = {"summary": ex.deterministic["summary"], "criteria": ex.deterministic["criteria"],
             "ranking": [{"provider": p["name"], "rank": p["rank"], "closeness": round(p["closeness"], 4),
                          "strengths": p["strengths"], "weaknesses": p["weaknesses"]} for p in ex.deterministic["providers"]],
             "uncertainty": ex.deterministic["uncertainty"]}
    text = _run(db, user, "explanation", lambda: ai_service.grounded_text(
        "Explain in plain language why the leading provider ranked first, and mention uncertainty.", facts))
    ex.ai_text, ex.ai_model, ex.ai_generated_at = text, get_settings().ai_model, datetime.now(timezone.utc)
    audit(db, "ai.explanation", user.id, "evaluation", ev.id, request=request)
    db.commit()
    return {"text": text, "model": ex.ai_model, "label": "AI-generated wording of the calculated results; it does not change scores"}


@eval_router.post("/reports/{rid}/ai-summary")
def report_summary(rid: str, request: Request, db: Session = Depends(get_db), user: User = Depends(require("ai:use"))):
    r = db.get(Report, rid)
    if r is None or r.owner_id != user.id:
        raise HTTPException(404, "Report not found")
    _guard(db, user, "report")
    facts = {k: r.body[k] for k in ("ranking", "criteria", "weights", "consistency_ratio", "explanation_summary", "uncertainty")}
    r.ai_summary = _run(db, user, "report", lambda: ai_service.grounded_text("Write a short executive summary of this report.", facts))
    audit(db, "ai.report_summary", user.id, "report", r.id, request=request)
    db.commit()
    return {"text": r.ai_summary}


class ExtractIn(BaseModel):
    text: str = Field(min_length=10, max_length=2000)


@router.post("/extract-requirements")
def extract_requirements(body: ExtractIn, db: Session = Depends(get_db), user: User = Depends(require("ai:use"))):
    """Suggest criteria priorities from free text. Output is filtered to known criteria; it is a suggestion only."""
    import json
    _guard(db, user, "extract")
    keys = [c.key for c in db.scalars(select(Criterion).where(Criterion.is_active.is_(True)))]
    system = ("Extract which of these criteria the customer cares about most, in priority order: " + ", ".join(keys) +
              '. Reply with JSON only: {"priorities": ["key", ...]}. Use only the listed keys.')
    raw = _run(db, user, "extract", lambda: ai_service.complete(system, body.text))
    db.commit()
    try:
        data = json.loads(raw[raw.index("{"): raw.rindex("}") + 1])
        pr = [k for k in data.get("priorities", []) if k in keys]
    except (ValueError, AttributeError):
        raise HTTPException(502, MESSAGES["bad_output"])
    return {"priorities": list(dict.fromkeys(pr)), "note": "AI suggestion only: review before running an evaluation."}

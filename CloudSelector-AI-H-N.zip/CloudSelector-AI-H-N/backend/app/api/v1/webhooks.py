"""Inbound webhooks for n8n. Authenticated with HMAC-SHA256 over `timestamp.body` (no cookies, no CSRF).

Replay protection: timestamp must be within 5 minutes. Idempotency: (workflow, event_id) is unique,
so a retried event is acknowledged as `duplicate` and not processed twice.
"""
import json
import time
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.adapters.registry import ADAPTERS
from app.api.v1.evaluations import build_report_body
from app.core.config import get_settings
from app.core.permissions import ADMIN, SUPER_ADMIN
from app.core.security import safe_equal
from app.db.session import get_db
from app.models import AutomationRun, Evaluation, Notification, PricingSource, Report, Role, User
from app.services import ai as ai_service
from app.services.n8n import sign
from app.services.pricing_sync import run_sync, source_health

router = APIRouter(prefix="/webhooks/n8n", tags=["webhooks"])
TOLERANCE_SECONDS = 300


async def verify_signature(request: Request) -> bytes:
    secret = get_settings().n8n_webhook_secret
    if not secret:
        raise HTTPException(503, "Webhook integration is not configured")
    ts, sig = request.headers.get("x-timestamp", ""), request.headers.get("x-signature", "")
    body = await request.body()
    try:
        fresh = abs(time.time() - int(ts)) <= TOLERANCE_SECONDS
    except ValueError:
        fresh = False
    if not fresh or not sig or not safe_equal(sig, sign(secret, ts, body)):
        raise HTTPException(401, "Invalid webhook signature")
    return body


def _claim(db: Session, workflow: str, event_id: str) -> Optional[AutomationRun]:
    """Insert the event; return None when it was already seen (duplicate)."""
    run = AutomationRun(workflow=workflow, event_id=event_id, status="received")
    db.add(run)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        return None
    return run


class EventBase(BaseModel):
    event_id: str = Field(min_length=6, max_length=64, pattern=r"^[A-Za-z0-9._:-]+$")


class PricingSyncEvent(EventBase):
    source_key: str = Field(max_length=64)


async def _parse(request: Request, model):
    raw = await verify_signature(request)
    try:
        return model.model_validate(json.loads(raw or b"{}"))
    except (ValueError, TypeError) as exc:
        raise HTTPException(422, "Invalid event payload") from exc


@router.post("/pricing-sync")
async def pricing_sync(request: Request, db: Session = Depends(get_db)):
    """Workflow A: scheduled pricing update."""
    ev = await _parse(request, PricingSyncEvent)
    adapter = ADAPTERS.get(ev.source_key)
    if adapter is None:
        raise HTTPException(404, "Unknown pricing source")
    run = _claim(db, "pricing_sync", ev.event_id)
    if run is None:
        return {"status": "duplicate"}
    result = run_sync(db, adapter, triggered_by="n8n")
    run.status = "processed" if result.status == "success" else "failed"
    run.detail = f"{result.status}: {result.error_summary}"[:500]
    db.commit()
    return {"status": result.status, "stored": result.records_stored, "rejected": result.records_rejected,
            "error": result.error_summary}


@router.get("/pricing-status")
async def pricing_status(request: Request, db: Session = Depends(get_db)):
    """Workflow D: failed / stale source summary for monitoring. Contains no secrets."""
    await verify_signature(request)
    items = [source_health(s) for s in db.scalars(select(PricingSource).where(PricingSource.enabled.is_(True), PricingSource.is_sample.is_(False)))]
    problems = [{"key": i["key"], "last_status": i["last_status"], "stale": i["stale"], "age_hours": i["age_hours"]}
                for i in items if i["stale"] or i["last_status"] in ("failed", "rejected")]
    return {"ok": not problems, "problems": problems}


class AdminAlertEvent(EventBase):
    summary: str = Field(min_length=3, max_length=500)


@router.post("/admin-alert")
async def admin_alert(request: Request, db: Session = Depends(get_db)):
    """Workflow D: record an alert as a notification to every active administrator."""
    ev = await _parse(request, AdminAlertEvent)
    run = _claim(db, "admin_alert", ev.event_id)
    if run is None:
        return {"status": "duplicate"}
    admins = db.scalars(select(User).join(Role, User.role_id == Role.id).where(Role.name.in_((ADMIN, SUPER_ADMIN)), User.is_active.is_(True))).unique().all()
    for a in admins:
        db.add(Notification(user_id=a.id, kind="pricing_alert", title="Pricing alert", body=ev.summary))
    run.status, run.detail = "processed", f"notified {len(admins)} admins"
    db.commit()
    return {"status": "processed", "notified": len(admins)}


class NotifyEvent(EventBase):
    user_id: str = Field(max_length=32)
    title: str = Field(min_length=1, max_length=200)
    body: str = Field(default="", max_length=1000)


@router.post("/notify")
async def notify(request: Request, db: Session = Depends(get_db)):
    """Workflow C: notify the correct customer (the user must exist and be active)."""
    ev = await _parse(request, NotifyEvent)
    run = _claim(db, "notify", ev.event_id)
    if run is None:
        return {"status": "duplicate"}
    user = db.get(User, ev.user_id)
    if user is None or not user.is_active or user.deleted_at is not None:
        run.status, run.detail = "failed", "unknown or inactive user"
        db.commit()
        raise HTTPException(404, "User not found")
    db.add(Notification(user_id=user.id, kind="automation", title=ev.title, body=ev.body))
    run.status = "processed"
    db.commit()
    return {"status": "processed"}


class ReportEvent(EventBase):
    evaluation_id: str = Field(max_length=32)
    user_id: str = Field(max_length=32)


@router.post("/report")
async def report(request: Request, db: Session = Depends(get_db)):
    """Workflow E: create a report for an evaluation (owner must match), with an AI summary when available."""
    ev = await _parse(request, ReportEvent)
    run = _claim(db, "report", ev.event_id)
    if run is None:
        return {"status": "duplicate"}
    evaluation = db.get(Evaluation, ev.evaluation_id)
    if evaluation is None or evaluation.owner_id != ev.user_id:
        run.status, run.detail = "failed", "evaluation not found for user"
        db.commit()
        raise HTTPException(404, "Evaluation not found")
    rep = Report(owner_id=ev.user_id, evaluation_id=evaluation.id, title=f"Report: {evaluation.title or evaluation.id}",
                 body=build_report_body(evaluation), idempotency_key=f"n8n-{ev.event_id}"[:64])
    ai_status = "not_configured"
    if ai_service.is_configured():
        facts = {k: rep.body[k] for k in ("ranking", "criteria", "weights", "consistency_ratio", "explanation_summary", "uncertainty")}
        try:
            rep.ai_summary = ai_service.grounded_text("Write a short executive summary of this report.", facts)
            ai_status = "generated"
        except ai_service.AiError as exc:
            ai_status = exc.category
    db.add(rep)
    run.status, run.detail = "processed", f"ai:{ai_status}"
    db.commit()
    return {"status": "processed", "report_id": rep.id, "ai_summary": ai_status}


class ResultEvent(EventBase):
    workflow: str = Field(max_length=64)
    outcome: str = Field(pattern="^(processed|failed)$")
    detail: str = Field(default="", max_length=500)


@router.post("/result")
async def result(request: Request, db: Session = Depends(get_db)):
    """Workflows B/C/E report back so execution history is visible to administrators."""
    ev = await _parse(request, ResultEvent)
    run = _claim(db, f"result:{ev.workflow}", ev.event_id)
    if run is None:
        return {"status": "duplicate"}
    run.status, run.detail = ev.outcome, ev.detail
    db.commit()
    return {"status": "recorded"}

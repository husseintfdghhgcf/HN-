"""Request dependencies: session auth, CSRF, permission checks."""
from datetime import datetime, timezone
from typing import Callable

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.permissions import ROLE_PERMISSIONS
from app.core.security import hash_token, safe_equal
from app.db.session import get_db
from app.models import AuthSession, User

UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}


def _load_session(request: Request, db: Session) -> AuthSession | None:
    token = request.cookies.get(get_settings().session_cookie_name)
    if not token:
        return None
    sess = db.scalar(select(AuthSession).where(AuthSession.token_hash == hash_token(token)))
    if not sess or sess.revoked_at is not None:
        return None
    if sess.expires_at <= datetime.now(timezone.utc):
        return None
    if not sess.user.is_active or sess.user.deleted_at is not None:
        return None
    return sess


def get_current_session(request: Request, db: Session = Depends(get_db)) -> AuthSession:
    sess = _load_session(request, db)
    if sess is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not authenticated")
    if request.method in UNSAFE:
        header = request.headers.get("x-csrf-token", "")
        if not header or not safe_equal(header, sess.csrf_token):
            raise HTTPException(status.HTTP_403_FORBIDDEN, "CSRF token missing or invalid")
    request.state.session = sess
    return sess


def get_current_user(sess: AuthSession = Depends(get_current_session)) -> User:
    return sess.user


def permissions_of(user: User) -> set[str]:
    return set(ROLE_PERMISSIONS.get(user.role.name, set()))


def require(permission: str) -> Callable:
    def checker(user: User = Depends(get_current_user)) -> User:
        if permission not in permissions_of(user):
            raise HTTPException(status.HTTP_403_FORBIDDEN, "Insufficient permissions")
        return user

    return checker

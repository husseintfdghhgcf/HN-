from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)
    full_name: str = Field(default="", max_length=120)
    organization: str = Field(default="", max_length=160)
    locale: str = Field(default="en", pattern="^(en|ar)$")


class LoginIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=1, max_length=128)


class ProfileUpdate(BaseModel):
    full_name: Optional[str] = Field(default=None, max_length=120)
    organization: Optional[str] = Field(default=None, max_length=160)
    locale: Optional[str] = Field(default=None, pattern="^(en|ar)$")
    preferences: Optional[dict[str, Any]] = None


class PasswordChange(BaseModel):
    current_password: str = Field(max_length=128)
    new_password: str = Field(max_length=128)


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)
    new_password: str = Field(max_length=128)


class VerifyIn(BaseModel):
    token: str = Field(min_length=10, max_length=200)


class UserOut(ORM):
    id: str
    email: str
    full_name: str
    organization: str
    locale: str
    preferences: dict[str, Any]
    role: str
    permissions: list[str]
    email_verified: bool
    created_at: datetime


class MessageOut(BaseModel):
    message: str

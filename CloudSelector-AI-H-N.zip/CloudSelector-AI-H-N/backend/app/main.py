import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text

from app.api.deps import UNSAFE
from app.api.v1 import auth as auth_routes
from app.api.v1 import admin as admin_routes
from app.api.v1 import ai as ai_routes
from app.api.v1 import catalog as catalog_routes
from app.api.v1 import webhooks as webhook_routes
from app.api.v1 import evaluations as eval_routes
from app.core.config import get_settings
from app.db.session import SessionLocal

log = logging.getLogger("app")
settings = get_settings()

app = FastAPI(
    title="CloudSelector AI API", version="1.0.0",
    docs_url="/api/v1/docs", openapi_url="/api/v1/openapi.json", redoc_url=None,
)

app.add_middleware(
    CORSMiddleware, allow_origins=settings.cors_origin_list, allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=["Content-Type", "X-CSRF-Token", "Idempotency-Key"],
)


@app.middleware("http")
async def security_middleware(request: Request, call_next):
    # Reject cross-site state-changing browser requests (defence in depth next to CSRF tokens).
    # Webhook routes authenticate with HMAC instead of cookies and are not browser-driven.
    if request.method in UNSAFE and not request.url.path.startswith("/api/v1/webhooks/"):
        origin = request.headers.get("origin")
        if origin and origin not in settings.cors_origin_list:
            return JSONResponse({"detail": "Origin not allowed"}, status_code=403)
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Cache-Control", "no-store")
    if settings.is_production:
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return response


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    # Report field + message only; never echo submitted values (could contain passwords).
    errors = [{"field": ".".join(str(p) for p in e["loc"][1:]), "message": e["msg"]} for e in exc.errors()]
    return JSONResponse({"detail": "Validation failed", "errors": errors}, status_code=422)


@app.exception_handler(Exception)
async def unhandled_handler(request: Request, exc: Exception):
    log.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse({"detail": "Internal server error"}, status_code=500)


@app.get("/api/v1/health", tags=["system"])
def health():
    """Liveness: process is up. Reveals nothing about infrastructure."""
    return {"status": "ok"}


@app.get("/api/v1/ready", tags=["system"])
def ready():
    """Readiness: database reachable."""
    try:
        with SessionLocal() as db:
            db.execute(text("select 1"))
    except Exception:
        return JSONResponse({"status": "unavailable"}, status_code=503)
    return {"status": "ready"}


app.include_router(auth_routes.router, prefix="/api/v1")
app.include_router(catalog_routes.router, prefix="/api/v1")
app.include_router(eval_routes.router, prefix="/api/v1")
app.include_router(admin_routes.router, prefix="/api/v1")
app.include_router(ai_routes.router, prefix="/api/v1")
app.include_router(ai_routes.eval_router, prefix="/api/v1")
app.include_router(webhook_routes.router, prefix="/api/v1")

"""Azure Retail Prices API (public, no credentials): https://prices.azure.com/api/retail/prices
Documented: https://learn.microsoft.com/rest/api/cost-management/retail-prices/azure-retail-prices
Comparable profile: Standard_D4s_v3 (4 vCPU / 16 GiB), Linux, pay-as-you-go.
"""
from datetime import datetime
from decimal import Decimal, InvalidOperation

import httpx

from app.adapters.base import NormalizedPrice, PermanentFetchError, PricingAdapter, get_json

API = "https://prices.azure.com/api/retail/prices"
SKU = "Standard_D4s_v3"
PROFILE = "general-4vcpu-16gib-linux"
REGIONS = {"westeurope": "europe", "northeurope": "europe", "eastus": "north_america", "westus2": "north_america"}
MAX_PAGES = 5


class AzureRetailAdapter(PricingAdapter):
    provider_slug = "azure"
    source_key = "azure-retail-prices"
    source_name = "Azure Retail Prices API"
    source_url = API
    kind = "official_api"
    requires_credentials = False

    def fetch(self, client: httpx.Client) -> list[NormalizedPrice]:
        out: list[NormalizedPrice] = []
        for region, geo in REGIONS.items():
            flt = (f"serviceName eq 'Virtual Machines' and armSkuName eq '{SKU}' and armRegionName eq '{region}' "
                   f"and priceType eq 'Consumption'")
            url, pages = API, 0
            params = {"$filter": flt}
            while url and pages < MAX_PAGES:
                data = get_json(client, url, params=params if pages == 0 else None)
                if not isinstance(data.get("Items"), list):
                    raise PermanentFetchError("Unexpected Azure response shape")
                for it in data["Items"]:
                    name = f"{it.get('productName', '')} {it.get('skuName', '')}".lower()
                    if any(x in name for x in ("windows", "spot", "low priority")):
                        continue  # keep Linux pay-as-you-go only
                    try:
                        price = Decimal(str(it["retailPrice"]))
                    except (KeyError, InvalidOperation):
                        continue
                    eff = None
                    if it.get("effectiveStartDate"):
                        try:
                            eff = datetime.fromisoformat(it["effectiveStartDate"].replace("Z", "+00:00"))
                        except ValueError:
                            eff = None
                    out.append(NormalizedPrice(
                        service_code="VirtualMachines", service_name="Virtual Machines", category="compute", sku=SKU,
                        profile=PROFILE, vcpu=4, memory_gib=16.0, os="linux", region_code=region, geography=geo,
                        price=price, currency=it.get("currencyCode", ""), unit=_unit(it.get("unitOfMeasure", "")),
                        billing_model="on_demand", tier=str(it.get("tierMinimumUnits", "")),
                        source_identifier=str(it.get("skuId") or it.get("meterId") or ""), effective_date=eff))
                url, pages = data.get("NextPageLink"), pages + 1
        return out


def _unit(u: str) -> str:
    return "hour" if u.strip().lower() in ("1 hour", "hour", "1 hr") else u.strip()

"""AWS Price List bulk offer files (public, no credentials):
https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEC2/current/<region>/index.json
Documented: https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/price-changes.html
Comparable profile: m5.xlarge (4 vCPU / 16 GiB), Linux, shared tenancy, no pre-installed software, On-Demand.

The per-region EC2 files are very large, so they are streamed to a temp file and parsed
incrementally (ijson) instead of being loaded into memory.
"""
import tempfile
from datetime import datetime
from decimal import Decimal

import httpx
import ijson

from app.adapters.base import NormalizedPrice, PermanentFetchError, PricingAdapter, TransientFetchError, classify_response

BASE = "https://pricing.us-east-1.amazonaws.com/offers/v1.0/aws/AmazonEC2/current"
INSTANCE = "m5.xlarge"
PROFILE = "general-4vcpu-16gib-linux"
REGIONS = {"eu-west-1": "europe", "eu-central-1": "europe", "us-east-1": "north_america", "us-west-2": "north_america"}


def parse_offer_stream(fileobj, region: str, geo: str) -> list[NormalizedPrice]:
    wanted: dict[str, dict] = {}
    for sku, prod in ijson.kvitems(fileobj, "products"):
        a = prod.get("attributes", {})
        if (a.get("instanceType") == INSTANCE and a.get("operatingSystem") == "Linux" and a.get("tenancy") == "Shared"
                and a.get("preInstalledSw") == "NA" and a.get("capacitystatus") == "Used" and a.get("regionCode", region) == region):
            wanted[sku] = a
    fileobj.seek(0)
    out = []
    for sku, offers in ijson.kvitems(fileobj, "terms.OnDemand"):
        if sku not in wanted:
            continue
        for offer in offers.values():
            for dim in offer.get("priceDimensions", {}).values():
                usd = dim.get("pricePerUnit", {}).get("USD")
                if usd is None or dim.get("unit") != "Hrs":
                    continue
                eff = None
                if offer.get("effectiveDate"):
                    try:
                        eff = datetime.fromisoformat(offer["effectiveDate"].replace("Z", "+00:00"))
                    except ValueError:
                        eff = None
                out.append(NormalizedPrice(
                    service_code="AmazonEC2", service_name="Amazon EC2", category="compute", sku=INSTANCE, profile=PROFILE,
                    vcpu=4, memory_gib=16.0, os="linux", region_code=region, geography=geo, price=Decimal(str(usd)),
                    currency="USD", unit="hour", billing_model="on_demand", source_identifier=dim.get("rateCode", sku),
                    effective_date=eff))
    return out


class AwsPriceListAdapter(PricingAdapter):
    provider_slug = "aws"
    source_key = "aws-price-list-bulk"
    source_name = "AWS Price List (bulk offer files)"
    source_url = BASE
    kind = "official_dataset"
    requires_credentials = False

    def fetch(self, client: httpx.Client) -> list[NormalizedPrice]:
        out: list[NormalizedPrice] = []
        for region, geo in REGIONS.items():
            with tempfile.TemporaryFile() as tmp:
                try:
                    with client.stream("GET", f"{BASE}/{region}/index.json") as resp:
                        classify_response(resp)
                        for chunk in resp.iter_bytes():
                            tmp.write(chunk)
                except (httpx.TimeoutException, httpx.TransportError) as exc:
                    raise TransientFetchError(type(exc).__name__) from exc
                tmp.seek(0)
                try:
                    out.extend(parse_offer_stream(tmp, region, geo))
                except ijson.JSONError as exc:
                    raise PermanentFetchError("AWS offer file was not valid JSON") from exc
        return out

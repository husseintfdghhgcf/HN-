from app.adapters.aws import AwsPriceListAdapter
from app.adapters.azure import AzureRetailAdapter
from app.adapters.base import PricingAdapter
from app.adapters.gcp import GcpBillingAdapter

ADAPTERS: dict[str, PricingAdapter] = {a.source_key: a for a in (AwsPriceListAdapter(), AzureRetailAdapter(), GcpBillingAdapter())}

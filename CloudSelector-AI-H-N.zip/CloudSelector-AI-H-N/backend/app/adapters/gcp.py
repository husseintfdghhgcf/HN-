"""Google Cloud Billing Catalog API (requires an API key / credentials):
https://cloud.google.com/billing/docs/reference/rest/v1/services.skus/list
Compute Engine service id 6F81-5844-456A. Comparable profile: e2-standard-4 = 4 vCPU + 16 GiB,
priced as 4 x (E2 core hour) + 16 x (E2 RAM GiB-hour), Linux, on-demand.
"""
from decimal import Decimal

import httpx

from app.adapters.base import NormalizedPrice, NotConfiguredError, PermanentFetchError, PricingAdapter, get_json
from app.core.config import get_settings

SERVICE = "6F81-5844-456A"
URL = f"https://cloudbilling.googleapis.com/v1/services/{SERVICE}/skus"
PROFILE = "general-4vcpu-16gib-linux"
REGIONS = {"europe-west1": "europe", "europe-west4": "europe", "us-central1": "north_america", "us-east1": "north_america"}
MAX_PAGES = 40


def _unit_price(sku: dict) -> Decimal | None:
    try:
        rate = sku["pricingInfo"][0]["pricingExpression"]["tieredRates"][0]["unitPrice"]
        return Decimal(rate.get("units", "0") or "0") + Decimal(rate.get("nanos", 0)) / Decimal(10**9)
    except (KeyError, IndexError, TypeError):
        return None


class GcpBillingAdapter(PricingAdapter):
    provider_slug = "gcp"
    source_key = "gcp-cloud-billing-catalog"
    source_name = "Google Cloud Billing Catalog API"
    source_url = URL
    kind = "official_api"
    requires_credentials = True

    def is_configured(self) -> bool:
        return bool(get_settings().gcp_billing_api_key)

    def fetch(self, client: httpx.Client) -> list[NormalizedPrice]:
        key = get_settings().gcp_billing_api_key
        if not key:
            raise NotConfiguredError("GCP_BILLING_API_KEY is not configured")
        core: dict[str, tuple[Decimal, str]] = {}
        ram: dict[str, tuple[Decimal, str]] = {}
        token, pages = None, 0
        while pages < MAX_PAGES:
            params = {"key": key, "pageSize": 5000, **({"pageToken": token} if token else {})}
            data = get_json(client, URL, params=params)
            if not isinstance(data.get("skus"), list):
                raise PermanentFetchError("Unexpected Billing Catalog response shape")
            for sku in data["skus"]:
                desc, cat = sku.get("description", ""), sku.get("category", {})
                if cat.get("usageType") != "OnDemand" or any(x in desc for x in ("Custom", "Spot", "Preemptible", "Commitment", "Sole Tenancy")):
                    continue
                price = _unit_price(sku)
                if price is None:
                    continue
                for region in sku.get("serviceRegions", []):
                    if region not in REGIONS:
                        continue
                    if desc.startswith("E2 Instance Core running in") and cat.get("resourceGroup") == "CPU":
                        core[region] = (price, sku.get("skuId", ""))
                    elif desc.startswith("E2 Instance Ram running in") and cat.get("resourceGroup") == "RAM":
                        ram[region] = (price, sku.get("skuId", ""))
            token, pages = data.get("nextPageToken"), pages + 1
            if not token:
                break
        out = []
        for region, geo in REGIONS.items():
            if region in core and region in ram:
                total = core[region][0] * 4 + ram[region][0] * 16
                out.append(NormalizedPrice(
                    service_code="ComputeEngine", service_name="Compute Engine", category="compute", sku="e2-standard-4",
                    profile=PROFILE, vcpu=4, memory_gib=16.0, os="linux", region_code=region, geography=geo,
                    price=total, currency="USD", unit="hour", billing_model="on_demand",
                    source_identifier=f"core:{core[region][1]}+ram:{ram[region][1]}"))
        return out

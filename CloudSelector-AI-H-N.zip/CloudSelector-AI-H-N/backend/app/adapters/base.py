"""Pricing adapter contract.

Adding a provider = subclass PricingAdapter, return NormalizedPrice rows, register it in
app/adapters/registry.py. Adapters never write to the database; app/services/pricing_sync.py
validates and stores their output.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Optional

import httpx


class TransientFetchError(Exception):
    """Timeouts, 429, 5xx: safe to retry with backoff."""


class PermanentFetchError(Exception):
    """Bad credentials, 4xx, schema change: retrying will not help."""


class NotConfiguredError(PermanentFetchError):
    """Credentials required by the source are not configured."""


@dataclass
class NormalizedPrice:
    service_code: str
    service_name: str
    category: str                 # compute | storage | database | network
    sku: str
    profile: str                  # comparability key shared across providers
    vcpu: Optional[int]
    memory_gib: Optional[float]
    os: str
    region_code: str
    geography: str
    price: Decimal
    currency: str
    unit: str                     # hour, GB-month ...
    billing_model: str = "on_demand"
    tier: str = ""
    source_identifier: str = ""
    effective_date: Optional[datetime] = None


class PricingAdapter(ABC):
    provider_slug: str
    source_key: str
    source_name: str
    source_url: str
    kind: str = "official_api"
    requires_credentials: bool = False

    @abstractmethod
    def fetch(self, client: httpx.Client) -> list[NormalizedPrice]:
        """Return normalized prices. Raise TransientFetchError / PermanentFetchError."""

    def is_configured(self) -> bool:
        return True


def classify_response(resp: httpx.Response) -> None:
    if resp.status_code == 429 or resp.status_code >= 500:
        raise TransientFetchError(f"HTTP {resp.status_code}")
    if resp.status_code >= 400:
        raise PermanentFetchError(f"HTTP {resp.status_code}")


def get_json(client: httpx.Client, url: str, **kw) -> dict:
    try:
        resp = client.get(url, **kw)
    except (httpx.TimeoutException, httpx.TransportError) as exc:
        raise TransientFetchError(type(exc).__name__) from exc
    classify_response(resp)
    try:
        return resp.json()
    except ValueError as exc:
        raise PermanentFetchError("Response was not valid JSON") from exc

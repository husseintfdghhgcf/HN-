"""Deterministic explanations generated only from calculation results and recorded provenance.

`criterion_standing` s_ij in [0, 1] is an explanatory measure, NOT part of the TOPSIS score:
    s_ij = (v_ij - worst_j) / (best_j - worst_j)    (0.5 if best_j == worst_j)
where v is the weighted normalised matrix, so cost criteria are already handled by the
ideal-solution direction. The "advantage" of A over B on criterion j is  w_j * (s_Aj - s_Bj).
"""
from __future__ import annotations

from typing import Any

from app.engine.topsis import TopsisResult

STRONG, WEAK = 0.75, 0.25


def _standing(res: TopsisResult, i: int, j: int) -> float:
    best, worst, v = res.ideal_best[j], res.ideal_worst[j], res.weighted[i][j]
    if abs(best - worst) < 1e-15:
        return 0.5
    return (v - worst) / (best - worst)


def build_explanation(
    res: TopsisResult, ahp: dict[str, Any], raw: dict[str, dict[str, dict[str, Any]]],
    names: dict[str, str], excluded: dict[str, str], dropped: dict[str, str],
    extra_uncertainty: list[str], criteria_names: dict[str, str],
) -> dict[str, Any]:
    order = sorted(range(len(res.alternatives)), key=lambda i: (res.ranks[i], res.alternatives[i]))
    leader_i = order[0]
    leader = res.alternatives[leader_i]
    providers = []
    for i in order:
        key = res.alternatives[i]
        standings = {c: _standing(res, i, j) for j, c in enumerate(res.criteria)}
        providers.append({
            "provider": key, "name": names.get(key, key), "rank": res.ranks[i],
            "closeness": res.closeness[i], "d_plus": res.d_plus[i], "d_minus": res.d_minus[i],
            "measurements": {c: raw[key][c] for c in res.criteria},
            "normalized": dict(zip(res.criteria, res.normalized[i])),
            "weighted": dict(zip(res.criteria, res.weighted[i])),
            "standing": standings,
            "strengths": [c for c, s in standings.items() if s >= STRONG and res.weights[res.criteria.index(c)] > 0],
            "weaknesses": [c for c, s in standings.items() if s <= WEAK and res.weights[res.criteria.index(c)] > 0],
        })

    summary, drivers = [], []
    if len(order) >= 2:
        runner_i = order[1]
        runner = res.alternatives[runner_i]
        adv = []
        for j, c in enumerate(res.criteria):
            a = res.weights[j] * (_standing(res, leader_i, j) - _standing(res, runner_i, j))
            adv.append({"criterion": c, "advantage": a})
        adv.sort(key=lambda d: -d["advantage"])
        drivers = adv
        tied = res.ranks[runner_i] == res.ranks[leader_i]
        if tied:
            summary.append(f"{names.get(leader, leader)} and {names.get(runner, runner)} are tied "
                           f"(closeness {res.closeness[leader_i]:.4f}).")
        else:
            margin = res.closeness[leader_i] - res.closeness[runner_i]
            summary.append(f"{names.get(leader, leader)} ranks first with closeness {res.closeness[leader_i]:.4f}, "
                           f"ahead of {names.get(runner, runner)} ({res.closeness[runner_i]:.4f}) by {margin:.4f}.")
            top = [d for d in adv if d["advantage"] > 1e-9][:2]
            if top:
                summary.append("The lead comes mainly from " + " and ".join(
                    f"{criteria_names.get(d['criterion'], d['criterion'])} (+{d['advantage']:.3f})" for d in top) + ".")
            behind = [d for d in adv if d["advantage"] < -1e-9][:1]
            if behind:
                summary.append(f"{names.get(runner, runner)} is stronger on "
                               f"{criteria_names.get(behind[0]['criterion'], behind[0]['criterion'])} "
                               f"({behind[0]['advantage']:.3f}).")
    else:
        summary.append("Only one provider was eligible, so no comparison could be made.")

    uncertainty = list(extra_uncertainty)
    for a, reason in excluded.items():
        uncertainty.append(f"{names.get(a, a)} was excluded from the ranking: {reason}.")
    for c, reason in dropped.items():
        uncertainty.append(f"Criterion '{criteria_names.get(c, c)}' was not used: {reason}.")
    if not ahp.get("consistent", True):
        uncertainty.append("The AHP judgements are inconsistent (CR above 0.10); weights are less reliable.")
    sample_used = sorted({k for k in res.alternatives for c in res.criteria if raw[k][c].get("is_sample")})
    if sample_used:
        uncertainty.append("Sample (non-market) data was used for: " + ", ".join(names.get(k, k) for k in sample_used)
                           + ". These results are illustrative, not market facts.")
    uncertainty.extend(res.notes)

    return {
        "summary": summary,
        "criteria": [{"key": c, "name": criteria_names.get(c, c), "weight": w, "kind": k}
                     for c, w, k in zip(res.criteria, res.weights, res.kinds)],
        "weight_derivation": ahp.get("derivation", []),
        "providers": providers,
        "leader": leader,
        "drivers": drivers,
        "uncertainty": uncertainty,
        "method": "AHP (principal eigenvector) + TOPSIS (vector normalisation, Euclidean distance)",
    }

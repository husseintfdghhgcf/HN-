"""Analytic Hierarchy Process (AHP): criteria weights from pairwise comparisons.

Method (Saaty):
  1. A is an n x n positive reciprocal matrix, a_ij = importance of criterion i over j on the
     1/9 .. 9 scale, a_ji = 1/a_ij, a_ii = 1.
  2. Weights w are the principal right eigenvector of A, normalised so sum(w) = 1
     (A w = lambda_max w).
  3. Consistency index      CI = (lambda_max - n) / (n - 1)
     Consistency ratio      CR = CI / RI(n), RI = Saaty's random index.
     CR <= 0.10 is considered acceptable. For n <= 2 the matrix is always consistent (CR = 0).

Invalid matrices raise AhpValidationError; matrices with CR above the threshold are reported
as inconsistent (never silently corrected). Callers decide whether to reject them.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

# Saaty's random consistency index, n = 1..15
RANDOM_INDEX = {1: 0.0, 2: 0.0, 3: 0.58, 4: 0.90, 5: 1.12, 6: 1.24, 7: 1.32, 8: 1.41,
                9: 1.45, 10: 1.49, 11: 1.51, 12: 1.48, 13: 1.56, 14: 1.57, 15: 1.59}
MAX_CRITERIA = 15
CR_THRESHOLD = 0.10
RECIPROCAL_TOLERANCE = 1e-6
SCALE_MIN, SCALE_MAX = 1 / 9, 9.0


class AhpValidationError(ValueError):
    """The pairwise comparison matrix is malformed."""


class InconsistentMatrixError(ValueError):
    """CR exceeds the threshold; carries the computed result for display."""

    def __init__(self, result: "AhpResult"):
        super().__init__(f"Pairwise matrix is inconsistent (CR={result.consistency_ratio:.4f} > {CR_THRESHOLD})")
        self.result = result


@dataclass(frozen=True)
class AhpResult:
    criteria: list[str]
    weights: list[float]
    lambda_max: float
    consistency_index: float
    consistency_ratio: float
    random_index: float
    consistent: bool
    method: str = "principal_eigenvector"
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "criteria": self.criteria, "weights": self.weights, "lambda_max": self.lambda_max,
            "consistency_index": self.consistency_index, "consistency_ratio": self.consistency_ratio,
            "random_index": self.random_index, "consistent": self.consistent,
            "threshold": CR_THRESHOLD, "method": self.method, "notes": self.notes,
        }


def matrix_from_upper(n: int, comparisons: dict[tuple[int, int], float]) -> list[list[float]]:
    """Build a reciprocal matrix from upper-triangle judgements {(i, j): a_ij} with i < j."""
    expected = {(i, j) for i in range(n) for j in range(i + 1, n)}
    if set(comparisons) != expected:
        raise AhpValidationError("Comparisons must cover every pair (i < j) exactly once")
    m = [[1.0] * n for _ in range(n)]
    for (i, j), v in comparisons.items():
        m[i][j] = float(v)
        m[j][i] = 1.0 / float(v) if v else math.nan
    return m


def validate_matrix(matrix: list[list[float]]) -> np.ndarray:
    try:
        a = np.array(matrix, dtype=float)
    except (TypeError, ValueError) as exc:
        raise AhpValidationError("Matrix must contain only numbers") from exc
    if a.ndim != 2 or a.shape[0] != a.shape[1] or a.shape[0] < 1:
        raise AhpValidationError("Matrix must be square")
    n = a.shape[0]
    if n > MAX_CRITERIA:
        raise AhpValidationError(f"At most {MAX_CRITERIA} criteria are supported")
    if not np.all(np.isfinite(a)) or np.any(a <= 0):
        raise AhpValidationError("All entries must be finite and strictly positive")
    if np.any(np.abs(np.diag(a) - 1.0) > RECIPROCAL_TOLERANCE):
        raise AhpValidationError("Diagonal entries must equal 1")
    if np.any(a < SCALE_MIN - 1e-9) or np.any(a > SCALE_MAX + 1e-9):
        raise AhpValidationError("Entries must lie on the 1/9 .. 9 scale")
    if np.any(np.abs(a * a.T - 1.0) > 1e-4):
        raise AhpValidationError("Matrix must be reciprocal (a_ji = 1 / a_ij)")
    return a


def compute_ahp(criteria: list[str], matrix: list[list[float]], enforce_consistency: bool = False) -> AhpResult:
    a = validate_matrix(matrix)
    n = a.shape[0]
    if len(criteria) != n or len(set(criteria)) != n:
        raise AhpValidationError("Criteria list must match the matrix size and contain unique keys")

    if n == 1:
        weights, lam = np.array([1.0]), 1.0
    else:
        vals, vecs = np.linalg.eig(a)
        k = int(np.argmax(vals.real))
        lam = float(vals[k].real)
        vec = np.abs(vecs[:, k].real)
        weights = vec / vec.sum()
    ci = 0.0 if n <= 2 else max(0.0, (lam - n) / (n - 1))
    ri = RANDOM_INDEX[n]
    cr = 0.0 if ri == 0 else ci / ri
    consistent = cr <= CR_THRESHOLD
    notes = []
    if n <= 2:
        notes.append("Matrices of order <= 2 are always consistent (CR = 0).")
    if not consistent:
        notes.append(f"CR {cr:.4f} exceeds {CR_THRESHOLD}: the judgements are inconsistent and should be revised.")
    if not math.isclose(float(weights.sum()), 1.0, rel_tol=1e-9):  # defensive; should never trigger
        raise AhpValidationError("Weights failed to normalise")
    result = AhpResult(criteria=list(criteria), weights=[float(w) for w in weights], lambda_max=lam,
                       consistency_index=float(ci), consistency_ratio=float(cr), random_index=ri,
                       consistent=consistent, notes=notes)
    if enforce_consistency and not consistent:
        raise InconsistentMatrixError(result)
    return result


def explain_weights(result: AhpResult) -> list[str]:
    """Plain-language derivation steps generated from the numbers (deterministic)."""
    n = len(result.criteria)
    lines = [f"Weights were derived from a {n}x{n} pairwise comparison matrix using the principal eigenvector method."]
    for key, w in sorted(zip(result.criteria, result.weights), key=lambda kv: -kv[1]):
        lines.append(f"Criterion '{key}' received weight {w:.4f} ({w * 100:.1f}%).")
    lines.append(f"lambda_max = {result.lambda_max:.4f}; CI = {result.consistency_index:.4f}; "
                 f"RI({n}) = {result.random_index}; CR = {result.consistency_ratio:.4f}.")
    lines.append("The judgements are acceptably consistent (CR <= 0.10)." if result.consistent
                 else "The judgements are NOT acceptably consistent (CR > 0.10).")
    return lines

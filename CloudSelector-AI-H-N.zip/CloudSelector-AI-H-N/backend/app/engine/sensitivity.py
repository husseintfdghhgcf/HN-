"""Weight sensitivity analysis for TOPSIS rankings (deterministic)."""
from __future__ import annotations

from app.engine.topsis import TopsisResult, topsis

DELTAS = (-0.5, -0.25, 0.25, 0.5)


def _rescale(weights: list[float], j: int, new_wj: float) -> list[float]:
    """Set weight j to new_wj and scale the others proportionally so the total stays 1."""
    others = sum(w for i, w in enumerate(weights) if i != j)
    out = []
    for i, w in enumerate(weights):
        if i == j:
            out.append(new_wj)
        elif others > 0:
            out.append(w * (1 - new_wj) / others)
        else:
            out.append((1 - new_wj) / (len(weights) - 1) if len(weights) > 1 else 0.0)
    return out


def sensitivity(base: TopsisResult, matrix: list[list[float]]) -> dict:
    leader = base.ranking()[0]
    n = len(base.criteria)
    report = {"leader": leader, "criteria": []}
    if n < 2:
        return {**report, "note": "Sensitivity analysis needs at least two criteria."}
    for j, crit in enumerate(base.criteria):
        w0 = base.weights[j]
        scenarios = []
        for d in DELTAS:
            w1 = min(max(w0 * (1 + d), 0.0), 1.0)
            r = topsis(base.alternatives, base.criteria, matrix, _rescale(base.weights, j, w1), base.kinds)
            scenarios.append({"change": d, "weight": w1, "ranking": r.ranking(), "leader": r.ranking()[0],
                              "leader_changed": r.ranking()[0] != leader})
        # smallest absolute weight change (sweep 0..1) that changes the leader
        flip = None
        for step in range(0, 101):
            cand = step / 100
            r = topsis(base.alternatives, base.criteria, matrix, _rescale(base.weights, j, cand), base.kinds)
            if r.ranking()[0] != leader and (flip is None or abs(cand - w0) < abs(flip["weight"] - w0)):
                flip = {"weight": cand, "new_leader": r.ranking()[0]}
        report["criteria"].append({"criterion": crit, "base_weight": w0, "scenarios": scenarios,
                                   "leader_flip": flip, "robust": flip is None})
    report["leader_robust_to_all_single_weight_changes"] = all(c["robust"] for c in report["criteria"])
    return report

"""TOPSIS: Technique for Order Preference by Similarity to Ideal Solution (Hwang & Yoon, 1981).

Given m alternatives, n criteria, matrix X = [x_ij], weights w (sum 1) and criterion types:
  1. Vector normalisation       r_ij = x_ij / sqrt(sum_i x_ij^2)
  2. Weighted matrix            v_ij = w_j * r_ij
  3. Ideal solutions            A+_j = max_i v_ij (benefit) | min_i v_ij (cost)
                                A-_j = min_i v_ij (benefit) | max_i v_ij (cost)
  4. Separation measures        D+_i = sqrt(sum_j (v_ij - A+_j)^2),  D-_i = sqrt(sum_j (v_ij - A-_j)^2)
  5. Relative closeness         C_i = D-_i / (D+_i + D-_i)   in [0, 1]; higher is better
  6. Rank alternatives by C_i descending (ties share a rank: 1, 1, 3, ...).

Assumptions / edge cases (all reported, none silent):
  * A criterion whose column is all zero has no discriminating power: its normalised values are 0
    and a note is added.
  * If D+_i + D-_i = 0 for all alternatives (all identical after weighting) C_i is set to 0.5 and
    every alternative gets rank 1, with a note.
  * Missing values are handled by `prepare_decision_matrix` (see missing_policy), never imputed.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Optional

import numpy as np

BENEFIT, COST = "benefit", "cost"


class TopsisValidationError(ValueError):
    pass


@dataclass(frozen=True)
class TopsisResult:
    alternatives: list[str]
    criteria: list[str]
    weights: list[float]
    kinds: list[str]
    normalized: list[list[float]]
    weighted: list[list[float]]
    ideal_best: list[float]
    ideal_worst: list[float]
    d_plus: list[float]
    d_minus: list[float]
    closeness: list[float]
    ranks: list[int]
    notes: list[str] = field(default_factory=list)

    def ranking(self) -> list[str]:
        order = sorted(range(len(self.alternatives)), key=lambda i: (self.ranks[i], self.alternatives[i]))
        return [self.alternatives[i] for i in order]

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def topsis(alternatives: list[str], criteria: list[str], matrix: list[list[float]],
           weights: list[float], kinds: list[str]) -> TopsisResult:
    m, n = len(alternatives), len(criteria)
    if m < 2:
        raise TopsisValidationError("At least two alternatives are required")
    if n < 1 or len(weights) != n or len(kinds) != n:
        raise TopsisValidationError("Criteria, weights and kinds must have the same length")
    if len(set(alternatives)) != m or len(set(criteria)) != n:
        raise TopsisValidationError("Alternative and criterion identifiers must be unique")
    if any(k not in (BENEFIT, COST) for k in kinds):
        raise TopsisValidationError("Criterion kind must be 'benefit' or 'cost'")
    try:
        x = np.array(matrix, dtype=float)
        w = np.array(weights, dtype=float)
    except (TypeError, ValueError) as exc:
        raise TopsisValidationError("Matrix and weights must be numeric") from exc
    if x.shape != (m, n):
        raise TopsisValidationError("Matrix shape must be alternatives x criteria")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(w)):
        raise TopsisValidationError("Matrix and weights must be finite (missing values must be handled first)")
    if np.any(x < 0):
        raise TopsisValidationError("Negative measurements are not supported")
    if np.any(w < 0) or not math.isclose(float(w.sum()), 1.0, abs_tol=1e-6):
        raise TopsisValidationError("Weights must be non-negative and sum to 1")

    notes: list[str] = []
    norms = np.sqrt((x ** 2).sum(axis=0))
    r = np.zeros_like(x)
    for j in range(n):
        if norms[j] == 0:
            notes.append(f"Criterion '{criteria[j]}' is zero for every alternative and does not discriminate.")
        else:
            r[:, j] = x[:, j] / norms[j]
    v = r * w

    benefit = np.array([k == BENEFIT for k in kinds])
    best = np.where(benefit, v.max(axis=0), v.min(axis=0))
    worst = np.where(benefit, v.min(axis=0), v.max(axis=0))
    d_plus = np.sqrt(((v - best) ** 2).sum(axis=1))
    d_minus = np.sqrt(((v - worst) ** 2).sum(axis=1))
    denom = d_plus + d_minus
    if np.all(denom < 1e-15):
        closeness = np.full(m, 0.5)
        notes.append("All alternatives are identical on the weighted criteria; closeness set to 0.5 and ranks tie.")
    else:
        closeness = np.where(denom < 1e-15, 0.5, d_minus / np.where(denom < 1e-15, 1, denom))

    # competition ranking with tolerance for float noise
    keyed = np.round(closeness, 12)
    ranks = [int(1 + (keyed > keyed[i]).sum()) for i in range(m)]
    return TopsisResult(
        alternatives=list(alternatives), criteria=list(criteria), weights=w.tolist(), kinds=list(kinds),
        normalized=r.tolist(), weighted=v.tolist(), ideal_best=best.tolist(), ideal_worst=worst.tolist(),
        d_plus=d_plus.tolist(), d_minus=d_minus.tolist(), closeness=closeness.tolist(), ranks=ranks, notes=notes,
    )


# ------------------------------------------------------------ decision-matrix preparation
@dataclass
class Measurement:
    value: Optional[float]
    unit: str = ""
    source: str = ""
    timestamp: Optional[str] = None
    is_sample: bool = False


@dataclass
class PreparedMatrix:
    alternatives: list[str]            # eligible alternatives only
    criteria: list[str]                # criteria actually used
    weights: list[float]               # renormalised over used criteria
    kinds: list[str]
    matrix: list[list[float]]
    excluded: dict[str, str]           # alternative -> reason
    dropped_criteria: dict[str, str]   # criterion -> reason
    notes: list[str]
    policy: str


def prepare_decision_matrix(
    alternatives: list[str], criteria: list[str], kinds: list[str], weights: list[float],
    data: dict[str, dict[str, Measurement]], missing_policy: str = "exclude_alternative",
) -> PreparedMatrix:
    """Turn raw per-alternative measurements into a complete numeric matrix, transparently.

    missing_policy:
      exclude_alternative - an alternative with a missing/invalid value on any (positively weighted)
                            criterion is excluded from the ranking and the reason is recorded.
      drop_criterion      - a criterion missing for any alternative is dropped and the remaining
                            AHP weights are renormalised (recorded in notes).
    Units must be identical across alternatives for a criterion, otherwise they are incomparable
    and a TopsisValidationError is raised: values are never converted or guessed.
    """
    if missing_policy not in ("exclude_alternative", "drop_criterion"):
        raise TopsisValidationError("Unknown missing-data policy")
    notes: list[str] = []
    excluded: dict[str, str] = {}
    dropped: dict[str, str] = {}

    def valid(mm: Optional[Measurement]) -> bool:
        return mm is not None and mm.value is not None and isinstance(mm.value, (int, float)) \
            and math.isfinite(mm.value) and mm.value >= 0

    # unit compatibility
    for c in criteria:
        units = {data[a][c].unit for a in alternatives if valid(data.get(a, {}).get(c)) and data[a][c].unit}
        if len(units) > 1:
            raise TopsisValidationError(f"Incomparable units for criterion '{c}': {sorted(units)}")

    keep_criteria = list(criteria)
    if missing_policy == "drop_criterion":
        for c in criteria:
            missing = [a for a in alternatives if not valid(data.get(a, {}).get(c))]
            if missing:
                dropped[c] = f"missing for: {', '.join(missing)}"
                keep_criteria.remove(c)
        if dropped:
            notes.append("Criteria dropped because of missing data: " + "; ".join(f"{k} ({v})" for k, v in dropped.items()))
        eligible = list(alternatives)
    else:
        eligible = []
        for a in alternatives:
            bad = [c for c in criteria if not valid(data.get(a, {}).get(c))]
            if bad:
                excluded[a] = "missing or invalid data for: " + ", ".join(bad)
            else:
                eligible.append(a)
        if excluded:
            notes.append("Alternatives excluded because of missing data: " +
                         "; ".join(f"{k} ({v})" for k, v in excluded.items()))

    idx = [criteria.index(c) for c in keep_criteria]
    raw_w = [weights[i] for i in idx]
    total = sum(raw_w)
    if not keep_criteria or total <= 0:
        raise TopsisValidationError("No usable criteria remain after handling missing data")
    new_w = [w / total for w in raw_w]
    if dropped:
        notes.append("AHP weights were renormalised over the remaining criteria.")
    matrix = [[float(data[a][c].value) for c in keep_criteria] for a in eligible]
    return PreparedMatrix(eligible, keep_criteria, new_w, [kinds[i] for i in idx], matrix,
                          excluded, dropped, notes, missing_policy)

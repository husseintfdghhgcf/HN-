"""Idempotent seeding: roles/permissions and criteria. Never deletes or overwrites existing data."""
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.permissions import ROLE_PERMISSIONS
from app.models import Criterion, Role, RolePermission

ROLE_DESCRIPTIONS = {
    "super_admin": "Full platform control",
    "admin": "Operational management",
    "customer": "Evaluates providers and manages own data",
}

DEFAULT_CRITERIA = [
    # key, English, Arabic, kind, unit, data source
    ("cost", "Cost", "التكلفة", "cost", "USD/month", "price"),
    ("performance", "Performance", "الأداء", "benefit", "score 0-100", "metric"),
    ("reliability", "Reliability", "الموثوقية", "benefit", "% SLA uptime", "metric"),
    ("security", "Security", "الأمان", "benefit", "certifications count", "metric"),
    ("availability", "Availability", "التوافر", "benefit", "% uptime", "metric"),
    ("scalability", "Scalability", "قابلية التوسع", "benefit", "score 0-100", "metric"),
    ("regional_coverage", "Regional availability", "التوفر الإقليمي", "benefit", "regions count", "metric"),
    ("compliance", "Compliance", "الامتثال", "benefit", "frameworks count", "metric"),
]


def seed_roles(db: Session) -> None:
    for name, perms in ROLE_PERMISSIONS.items():
        role = db.scalar(select(Role).where(Role.name == name))
        if role is None:
            role = Role(name=name, description=ROLE_DESCRIPTIONS[name])
            db.add(role)
            db.flush()
        have = {p.permission for p in role.permissions}
        for perm in sorted(perms - have):
            db.add(RolePermission(role_id=role.id, permission=perm))
    db.flush()


def seed_criteria(db: Session) -> None:
    for key, en, ar, kind, unit, src in DEFAULT_CRITERIA:
        if db.scalar(select(Criterion).where(Criterion.key == key)) is None:
            db.add(Criterion(key=key, name_en=en, name_ar=ar, kind=kind, unit=unit, data_source=src))
    db.flush()


def seed_pricing_sources(db: Session) -> None:
    """Register the real (non-sample) pricing sources and their providers. No prices are created."""
    from app.adapters.registry import ADAPTERS
    from app.models import PricingSource, Provider

    names = {"aws": ("Amazon Web Services", "https://aws.amazon.com"), "azure": ("Microsoft Azure", "https://azure.microsoft.com"),
             "gcp": ("Google Cloud Platform", "https://cloud.google.com")}
    for a in ADAPTERS.values():
        prov = db.scalar(select(Provider).where(Provider.slug == a.provider_slug))
        if prov is None:
            n, site = names[a.provider_slug]
            prov = Provider(slug=a.provider_slug, name=n, website=site)
            db.add(prov)
            db.flush()
        if db.scalar(select(PricingSource).where(PricingSource.key == a.source_key)) is None:
            db.add(PricingSource(provider_id=prov.id, key=a.source_key, name=a.source_name, kind=a.kind, url=a.source_url,
                                 requires_credentials=a.requires_credentials, is_sample=False))
    db.flush()

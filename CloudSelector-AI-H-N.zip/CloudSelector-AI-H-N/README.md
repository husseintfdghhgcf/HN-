# CloudSelector AI — H&N

منصة لاختيار مزوّد الخدمات السحابية (AWS / Azure / GCP) بنموذج قرار هجين: **AHP + TOPSIS + طبقة شرح** مع باك‌إند FastAPI وقاعدة PostgreSQL.

العنوان الأكاديمي: *An Explainable AI and Multi-Criteria Decision-Making Hybrid Framework for Cloud Service Provider Selection.*

## التشغيل على ويندوز (3 أوامر)
افتح PowerShell داخل مجلد المشروع:
```powershell
powershell -ExecutionPolicy Bypass -File scripts\setup.ps1 -InstallPrerequisites -SampleData
powershell -ExecutionPolicy Bypass -File scripts\run.ps1
powershell -ExecutionPolicy Bypass -File scripts\test.ps1
```
- `setup.ps1`: يثبّت Python وPostgreSQL (winget)، ينشئ قاعدة البيانات والمستخدم بكلمة سر عشوائية، يكتب `backend\.env` (مع `SECRET_KEY` عشوائي)، يثبّت المكتبات، يشغّل الـ migrations، يزرع الأدوار والمعايير، ثم يسألك عن إنشاء أول Super Admin. `-SampleData` يحمّل بيانات **عيّنة موسومة SAMPLE** للتجربة فقط.
- `run.ps1`: يشغّل الباك‌إند (8000) والواجهة (8080) ويفتح المتصفح. التوثيق التفاعلي: `http://localhost:8000/api/v1/docs`.
- `test.ps1`: يشغّل الاختبارات على قاعدة منفصلة `cloudselector_test` (لا تلمس بياناتك).

أي سكربت لا يطبع كلمات السر. إن ظهر خطأ `running scripts is disabled` شغّل مرة واحدة: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.

## البنية
```
frontend/   الواجهة الأصلية (HTML/CSS/JS) + config.js + api.js
backend/    FastAPI, SQLAlchemy 2, Alembic, PostgreSQL
  app/engine/        ahp.py  topsis.py  sensitivity.py  explain.py   (المحرك الرياضي، بدون قاعدة بيانات)
  app/services/      evaluation_service.py (الربط)  pricing_sync.py  ai.py  google_oidc.py  n8n.py ...
  app/adapters/      aws.py  azure.py  gcp.py  (محوّلات الأسعار)
  app/api/v1/        auth, catalog, evaluations, admin, ai, webhooks
  alembic/           migrations
n8n/        5 workflows جاهزة للاستيراد
scripts/    setup.ps1  run.ps1  test.ps1
```

## حالة الميزات (صريحة)
| الميزة | الحالة |
|---|---|
| الباك‌إند، قاعدة البيانات، migrations (26 جدول) | **مُجرَّب**: 115 اختبار ناجح على PostgreSQL 16 |
| تسجيل/دخول/خروج، Argon2، جلسات HttpOnly، CSRF، قفل الحساب، rate limit | مُجرَّب بالاختبارات |
| الأدوار (Super Admin / Admin / Customer) وعزل بيانات العملاء | مُجرَّب بالاختبارات (طلبات HTTP يدوية) |
| AHP + TOPSIS + الشرح + الحساسية | مُجرَّب بأرقام محسوبة بشكل مستقل |
| توقيع webhooks بين n8n والباك‌إند | مُجرَّب: كود JavaScript الخاص بـ n8n يطابق تحقق Python (حتى مع العربية) |
| محوّلات الأسعار (AWS/Azure/GCP): التطبيع والتحقق والتاريخ ورفض الاستجابات الفارغة | مُجرَّبة على **استجابات تجريبية** مبنية على التوثيق الرسمي |
| جلب الأسعار **الحية** من AWS/Azure/GCP | **NOT VERIFIED — لم يُجرَّب على الإنترنت**. GCP يتطلب `GCP_BILLING_API_KEY` |
| Google sign-in | منطق التحقق مُجرَّب بمفتاح محلي. **NOT VERIFIED — CONFIGURATION REQUIRED** حتى تضيف Client ID/Secret وتجرّبه |
| AI (Gemini / Anthropic / OpenAI) | الشكل والتحقق من المخرجات مُجرَّب بمحاكاة. **NOT VERIFIED** بمفتاح حقيقي |
| ملفات n8n (5) | بنيتها سليمة. **NOT DEPLOYED / NOT VERIFIED**: لم تُستورد في n8n حي |
| سكربتات ويندوز | كُتبت بدقة لكن **لم تُشغَّل على ويندوز** (بيئتي Linux) |
| ربط الواجهة | تسجيل الدخول، التحقق من الجلسة، الخروج، إخفاء روابط الإدارة للعملاء، زر Google: **مربوطة**. صفحات `dashboard` و`providers` ما زالت تعرض **بيانات عرض ثابتة** |
| صفحة **evaluate** (تقييم جديد) | **مبنية ومربوطة**: اختيار السيناريو والمعايير، مقارنات زوجية بمؤشرات، أوزان AHP ونسبة الاتساق مباشرة، تشغيل التقييم |
| صفحة **results** (النتائج) | **مبنية ومربوطة**: الترتيب، الأوزان، القياسات ومصادرها، الافتراضات، الشرح، عدم اليقين، الحساسية، شرح AI، إنشاء تقرير، قائمة التقييمات |
| اختبار صفحتي evaluate/results | سلوك DOM والأمان (XSS) والعربي/RTL مُجرَّب بـ jsdom على سيرفر حقيقي (25 فحص، `scripts/ui-smoke.js`). **الشكل البصري لم يُفحص بمتصفح حقيقي**: راجعه بنفسك |
| صفحات compare / explainability / history / reports / settings / admin / integrations | **ما زالت فارغة بالتصميم الأصلي، لم تُبنَ بعد**. الـ API الخاص بها جاهز ومُجرَّب |
| النشر على الإنترنت | **لم يُنفَّذ** (لا رابط منشور) |

## المتغيرات المطلوبة (`backend/.env`)
`DATABASE_URL`, `SECRET_KEY`, `ENVIRONMENT`, `COOKIE_SECURE`, `COOKIE_SAMESITE`, `CORS_ORIGINS`, `FRONTEND_BASE_URL` — أساسية.
اختيارية حسب الميزة: `GOOGLE_CLIENT_ID/SECRET/REDIRECT_URI`, `AI_PROVIDER/AI_API_KEY/AI_MODEL/AI_BASE_URL`, `N8N_BASE_URL/N8N_WEBHOOK_SECRET`, `GCP_BILLING_API_KEY`, `SMTP_*`. بدون SMTP لا تُرسل إيميلات (الباك‌إند يقول ذلك صراحة ولا يدّعي الإرسال).

## إعداد Google sign-in
1. Google Cloud Console ثم APIs & Services ثم OAuth consent screen: أنشئ التطبيق (External للتجربة) وأضف نفسك كـ Test user.
2. Credentials ثم Create OAuth client ID ثم نوع **Web application**.
3. Authorized redirect URIs: `http://localhost:8000/api/v1/auth/google/callback` (وللإنتاج رابط الباك‌إند الحقيقي بـ https).
4. ضع `GOOGLE_CLIENT_ID` و`GOOGLE_CLIENT_SECRET` في `backend\.env` وأعد تشغيل الباك‌إند. يظهر زر Google في صفحة الدخول تلقائياً عند الإعداد.

## إعداد الـ AI (مثال Gemini)
في `backend\.env`: `AI_PROVIDER=gemini`، `AI_API_KEY=<مفتاحك>`، `AI_MODEL=<اسم الموديل من AI Studio>`. المفتاح يُستخدم من السيرفر فقط (ترويسة `x-goog-api-key`)، ولا يظهر في الواجهة ولا في الردود. تحقّق من الاتصال بدون كشف المفتاح: `POST /api/v1/ai/status/check` (Admin). الـ AI يعيد صياغة النتائج فقط؛ أي رقم غير موجود في الحسابات يُرفض النص. بدون مفتاح يبقى كل شيء آخر يعمل.
**لا تلصق مفاتيح API في أي محادثة أو ملف مرفوع. إن انكشف مفتاح احذفه فوراً وأنشئ غيره.**

## النموذج الهجين
- الملفات: `backend/app/engine/ahp.py`, `topsis.py`, `sensitivity.py`, `explain.py`؛ الربط: `backend/app/services/evaluation_service.py`؛ نقطة التنفيذ: `POST /api/v1/evaluations`.
- **AHP**: مصفوفة مقارنات زوجية `A` (مقياس 1/9 إلى 9، متبادلة). الأوزان = المتجه الذاتي الرئيسي `A·w = λmax·w` بحيث `Σw = 1`. `CI = (λmax − n)/(n − 1)`، `CR = CI / RI(n)`. تُرفض المصفوفة إذا `CR > 0.10` (لا تُصحَّح بصمت).
- **TOPSIS**: تطبيع شعاعي `r_ij = x_ij / √(Σ x_ij²)`، ثم `v_ij = w_j·r_ij`، الحل المثالي الموجب/السالب (max/min للمنفعة، العكس للتكلفة)، المسافات `D⁺, D⁻`، والقرب النسبي `C_i = D⁻/(D⁺ + D⁻)`. الترتيب تنازلياً بـ `C_i`.
- **بيانات ناقصة**: السياسة الافتراضية تستبعد المزوّد صراحةً وتشرح السبب؛ البديل `drop_criterion` يحذف المعيار ويعيد تطبيع الأوزان. لا يوجد تعويض بقيم مخمّنة. وحدات غير متوافقة تُرفض.
- **إعادة الإنتاج**: كل تقييم يحفظ المدخلات والأوزان والقياسات ومصدرها وتوقيتها ونسخة الخوارزمية (`ahp-topsis-1.0.0`). تغيّر الأسعار لاحقاً لا يغيّر التقييمات القديمة.
- بيانات العيّنة تظهر دائماً بوسم SAMPLE في الشرح ولا تُقدَّم كأسعار سوق.

## أهم الـ API (التوثيق الكامل: `/api/v1/docs`)
`POST /auth/register|login|logout|forgot-password|reset-password|verify-email`, `GET|PATCH /auth/me`, `GET /auth/google/start`
`GET /providers`, `GET /criteria`, `GET /pricing/history`, `GET /pricing/options` (السيناريوهات المتاحة وتغطية المزوّدين), `POST /ahp/preview` (أوزان ونسبة الاتساق دون حفظ)
`POST /evaluations` (يقبل `Idempotency-Key`), `GET /evaluations`, `GET /evaluations/{id}`, `GET /evaluations/{id}/explanation`
`POST /reports`, `GET /reports`, `GET /notifications`
`POST /evaluations/{id}/ai-explanation`, `POST /reports/{id}/ai-summary`, `POST /ai/extract-requirements`
Admin: `/admin/users`, `/admin/audit`, `/admin/pricing/sources`, `POST /admin/pricing/sources/{key}/sync`, `/admin/pricing/sync-runs`, `/admin/automation/runs`, `/admin/health`, `/admin/dashboard`
Webhooks (HMAC): `/webhooks/n8n/pricing-sync|pricing-status|admin-alert|notify|report|result`
مثال تقييم (JSON): `{"criteria":["cost","performance","security"],"pairwise_matrix":[[1,3,5],[0.333,1,3],[0.2,0.333,1]],"requirements":{"profile":"general-4vcpu-16gib-linux","region":"europe","hours_per_month":730}}`

## أسعار حقيقية
بعد `setup.ps1` سجّل مصادر الأسعار (يتم تلقائياً) ثم من حساب Admin: `POST /admin/pricing/sources/azure-retail-prices/sync` (و`aws-price-list-bulk`). GCP يحتاج `GCP_BILLING_API_KEY`. تقتصر المحوّلات حالياً على **مقارنة instance واحد (4 vCPU / 16 GiB، Linux، on-demand)** في مناطق محددة في كل محوّل؛ لا يوجد ادّعاء بتغطية متساوية لكل المزودين. AWS: ملف المنطقة كبير، لذلك يُبثّ ويُحلَّل تدريجياً.

## n8n
1. في n8n: Workflows ثم Import from file، لكل ملف في `n8n/`.
2. متغيرات بيئة n8n المطلوبة: `BACKEND_API_URL` (مثال `http://localhost:8000/api/v1`)، `BACKEND_WEBHOOK_SECRET` (نفس `N8N_WEBHOOK_SECRET` في الباك‌إند)، `NODE_FUNCTION_ALLOW_BUILTIN=crypto`، `N8N_BLOCK_ENV_ACCESS_IN_NODE=false`.
3. اختر SMTP credential على عقدة البريد في Workflow B، وأنشئ Header Auth credential لـ Workflow E.
4. في الباك‌إند: `N8N_BASE_URL` و`N8N_WEBHOOK_SECRET`. فعّل الـ workflows يدوياً. **لا تُعدّ منشورة قبل تفعيلها واختبارها فعلاً.**
اختبار: سجّل مستخدماً جديداً (يفعّل B)، شغّل تقييماً (يفعّل C)، وراجع `/admin/automation/runs`.

## النشر (لم يُنفَّذ)
- واجهة: Vercel أو ما يعادله (ملفات ثابتة)، وعدّل `frontend/config.js` إلى رابط الباك‌إند.
- باك‌إند: أي استضافة Python/Docker (`backend/Dockerfile`)، وقاعدة PostgreSQL مُدارة. الأمر: `alembic upgrade head` ثم `uvicorn`.
- إنتاج: `ENVIRONMENT=production`, `COOKIE_SECURE=true`, HTTPS، `CORS_ORIGINS` بدومين الواجهة فقط، وحدّث Redirect URI في Google.
- **مهم**: الأفضل أن تكون الواجهة والباك‌إند تحت نفس الدومين الأب (`app.example.com` و`api.example.com`) حتى تعمل `SameSite=Lax`. دومينان مختلفان تماماً يحتاجان `COOKIE_SAMESITE=none` مع `COOKIE_SECURE=true`.
- rate limiter داخل العملية: مع أكثر من instance استعمل Redis أو حدّ على مستوى البوابة.
- Docker محلي: انسخ `.env.docker.example` إلى `.env.docker` واملأه، ثم `docker compose up --build` (لم يُجرَّب هنا).

## قائمة الأمان
- كلمات السر Argon2id؛ جلسات HttpOnly؛ CSRF double-submit؛ فحص Origin؛ CORS مقيّد.
- صلاحيات تُفحص بالسيرفر على كل طلب؛ العملاء معزولون؛ الأدمن لا يرى تقييمات العملاء الخاصة.
- لا أسرار في الواجهة؛ المفاتيح بـ `.env` فقط؛ `.env` في `.gitignore`.
- سجل تدقيق للعمليات الحساسة بدون كلمات سر؛ حذف المستخدمين soft-delete مع إلغاء الجلسات.
- أول admin عبر `python -m app.cli bootstrap-admin` ورفض أي ثاني؛ لا كلمة سر افتراضية.
- أغلق أي مفتاح انكشف، فعّل HTTPS، وأزل متغيرات `BOOTSTRAP_*` بعد الاستعمال.

## استكشاف الأخطاء
- `connection refused` على 5432: شغّل خدمة PostgreSQL (`services.msc`).
- `password authentication failed`: `DATABASE_URL` بالـ `.env` لا يطابق كلمة سر المستخدم `cs`؛ احذف `backend\.env` وأعد `setup.ps1`.
- تسجيل الدخول لا يعمل من المتصفح: تأكد أن `CORS_ORIGINS` يطابق عنوان الواجهة بالضبط (`http://localhost:8080`) وأن `frontend\config.js` يشير للباك‌إند.
- الصفحة تعيدك لتسجيل الدخول: الباك‌إند غير شغّال أو الجلسة انتهت.
- `Refusing to run tests`: شغّل الاختبارات عبر `scripts\test.ps1` فقط.

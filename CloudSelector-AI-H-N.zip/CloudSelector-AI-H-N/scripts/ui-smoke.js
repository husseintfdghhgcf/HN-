/* UI smoke test for the Evaluate and Results pages (jsdom, no real browser).
   Needs: a running backend with SAMPLE data and an admin account.
     cd scripts; npm install jsdom
     $env:UI_TEST_EMAIL="..."; $env:UI_TEST_PASSWORD="..."; node ui-smoke.js
   It renames provider "aws" temporarily (XSS probe) and restores the name afterwards.
   It checks DOM behaviour and safety, NOT how the pages look: review the layout in a real browser. */
const { JSDOM } = require('jsdom');
const fs = require('fs');
const FE = require('path').join(__dirname, '..', 'frontend') + '/';
const EMAIL = process.env.UI_TEST_EMAIL, PASSWORD = process.env.UI_TEST_PASSWORD;
if (!EMAIL || !PASSWORD) { console.error('Set UI_TEST_EMAIL and UI_TEST_PASSWORD (an admin account) first.'); process.exit(2); }
const API = 'http://localhost:8000';
const jar = {};
async function jfetch(url, opts = {}) {
  const headers = Object.assign({ Origin: 'http://localhost:8080' }, opts.headers || {});
  const cookie = Object.entries(jar).map(([k, v]) => k + '=' + v).join('; ');
  if (cookie) headers.Cookie = cookie;
  const r = await fetch(url, Object.assign({}, opts, { headers, credentials: undefined }));
  (r.headers.getSetCookie ? r.headers.getSetCookie() : []).forEach(c => { const [kv] = c.split(';'); const i = kv.indexOf('='); jar[kv.slice(0, i)] = kv.slice(i + 1); });
  return r;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function until(fn, label, ms = 8000) { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { const v = fn(); if (v) return v; } catch (e) {} await sleep(50); } throw new Error('timeout waiting for ' + label); }
const errors = [];
function open(file, query = '') {
  const html = fs.readFileSync(FE + file, 'utf8');
  const dom = new JSDOM(html, { url: 'http://localhost:8080/' + file + query, runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window;
  w.fetch = (u, o) => jfetch(u, o);
  w.matchMedia = w.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }));
  w.addEventListener('error', e => errors.push(file + ': ' + e.message));
  ['config.js', 'i18n.js', 'api.js', 'app.js', 'pages.js'].forEach(s => { try { w.eval(fs.readFileSync(FE + s, 'utf8')); } catch (e) { errors.push(file + ' ' + s + ': ' + e.message); } });
  return w;
}
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
(async () => {
  // login through the real client code (api.js) in a throwaway window
  let r = await jfetch(API + '/api/v1/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: EMAIL, password: PASSWORD }) });
  const csrf = (await r.json()).csrf_token; ok(r.status === 200 && csrf, 'login OK');

  // XSS probe: hostile provider name set via the admin API
  const evil = '<img src=x onerror="window.__xss=1">Evil';
  r = await jfetch(API + '/api/v1/providers/aws', { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ name: evil }) });
  ok(r.status === 200, 'provider renamed to hostile string');

  // ---------- EVALUATE PAGE
  let w = open('evaluate.html'); w.sessionStorage.setItem('cs-csrf', csrf);
  await until(() => w.document.querySelectorAll('.cs-check').length >= 8, 'criteria rendered');
  const d = w.document;
  ok(d.querySelectorAll('.cs-pair').length === 3, 'three default criteria -> 3 pair sliders (' + d.querySelectorAll('.cs-pair').length + ')');
  await until(() => d.querySelector('.cs-w-row'), 'weights preview');
  ok(d.querySelectorAll('.cs-w-row').length === 3, 'live AHP preview shows 3 weights');
  ok(/Consistent/.test(d.body.textContent), 'preview reports consistency');
  const sliders = d.querySelectorAll('.cs-slider');
  const setSlider = (s, v) => { s.value = v; s.dispatchEvent(new w.Event('input', { bubbles: true })); };
  setSlider(sliders[0], 8); setSlider(sliders[1], 6); setSlider(sliders[2], -6);   // inconsistent on purpose
  await sleep(700); await until(() => d.querySelector('.cs-badge-danger'), 'inconsistent badge');
  ok(/Inconsistent/.test(d.body.textContent), 'inconsistent judgements flagged live (not corrected)');
  setSlider(sliders[0], 4); setSlider(sliders[1], 6); setSlider(sliders[2], 2);
  await sleep(700); await until(() => d.querySelector('.cs-badge-success'), 'consistent badge again');
  // criteria change rebuilds pairs
  const boxes = [...d.querySelectorAll('.cs-check input')];
  boxes[2].checked = true; boxes[2].dispatchEvent(new w.Event('change', { bubbles: true }));
  ok(d.querySelectorAll('.cs-pair').length === 6, 'adding a 4th criterion -> 6 pairs');
  boxes[2].checked = false; boxes[2].dispatchEvent(new w.Event('change', { bubbles: true }));
  ok(d.querySelectorAll('.cs-pair').length === 3, 'removing it -> 3 pairs');
  ok(d.querySelector('.cs-alert') === null, 'no error shown before submit');

  // capture the POST result
  let created = null; const orig = w.fetch;
  w.fetch = async (u, o) => { const res = await orig(u, o); if (/\/evaluations$/.test(u) && o && o.method === 'POST') { created = await res.clone().json(); createdStatus = res.status; } return res; };
  var createdStatus = 0;
  // validation: deselect providers
  const provBoxes = [...d.querySelectorAll('.cs-card')].pop && [...d.querySelectorAll('.cs-check-grid')][1].querySelectorAll('input');
  provBoxes.forEach(b => { b.checked = false; b.dispatchEvent(new w.Event('change', { bubbles: true })); });
  d.querySelector('.cs-btn').click(); await sleep(100);
  ok(d.querySelector('.cs-alert.is-error') && /at least two providers/.test(d.body.textContent), 'client validation: needs >= 2 providers');
  provBoxes.forEach(b => { b.checked = true; b.dispatchEvent(new w.Event('change', { bubbles: true })); });
  d.querySelector('input#ev-title').value = 'UI test'; d.querySelector('input#ev-title').dispatchEvent(new w.Event('input', { bubbles: true }));
  d.querySelector('.cs-btn').click();
  await until(() => created, 'evaluation created');
  ok(createdStatus === 201 && created.results.length === 3, 'POST /evaluations from the UI -> 201 with 3 results');
  const evalId = created.id;

  // ---------- RESULTS PAGE
  w = open('results.html', '?id=' + evalId); w.sessionStorage.setItem('cs-csrf', csrf);
  const rd = w.document;
  await until(() => rd.querySelectorAll('.cs-card').length >= 7, 'results sections');
  const titles = [...rd.querySelectorAll('.cs-card > h2')].map(x => x.textContent);
  console.log('sections:', JSON.stringify(titles));
  ok(rd.querySelectorAll('.cs-rank').length === 3, 'ranking has 3 rows');
  ok(rd.querySelector('.cs-rank.is-first'), 'rank 1 highlighted');
  ok(/SAMPLE data/.test(rd.body.textContent), 'sample-data warning visible');
  ok(rd.querySelectorAll('.cs-badge-warning').length > 0, 'sample badges on measurements');
  ok(/Sensitivity analysis/.test(rd.body.textContent) && rd.querySelectorAll('.cs-table').length >= 5, 'sensitivity + tables rendered');
  ok(w.__xss === undefined && !rd.querySelector('img'), 'XSS: hostile provider name NOT executed / no <img> created');
  ok(rd.body.textContent.includes('<img src=x'), 'XSS: hostile name shown literally as text');
  ok(/not configured on this server/.test(rd.body.textContent), 'AI unavailable state shown (no key configured)');
  // language switch to Arabic -> re-render + RTL
  rd.querySelector('[data-action="toggle-lang"]').click(); await sleep(300);
  ok(rd.documentElement.dir === 'rtl', 'RTL applied');
  ok([...rd.querySelectorAll('.cs-card > h2')].some(h => /الترتيب/.test(h.textContent)), 'Arabic section titles after language switch');
  ok(/متسق/.test(rd.body.textContent), 'Arabic consistency badge');
  // report action
  rd.querySelector('[data-action="toggle-lang"]').click(); await sleep(200);
  const rb = [...rd.querySelectorAll('.cs-btn')].find(b => b.tagName === 'BUTTON' && !b.disabled && /report/i.test(b.textContent));
  rb.click(); await until(() => rd.querySelector('.toast'), 'report toast'); ok(/Report saved/.test(rd.querySelector('.toast').textContent), 'report created from UI');
  // list view without id
  w = open('results.html'); w.sessionStorage.setItem('cs-csrf', csrf);
  await until(() => w.document.querySelector('.cs-table'), 'recent list');
  ok(/UI test/.test(w.document.body.textContent), 'results list shows the new evaluation');
  // 404 view
  w = open('results.html', '?id=' + 'f'.repeat(32)); await until(() => w.document.querySelector('.cs-alert.is-error'), '404 state');
  ok(/not found/i.test(w.document.body.textContent), 'unknown id -> not-found state');

  // restore provider name
  await jfetch(API + '/api/v1/providers/aws', { method: 'PATCH', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ name: 'Amazon Web Services' }) });
  console.log('uncaught page errors:', JSON.stringify(errors));
})().catch(e => { console.error('HARNESS FAILURE:', e.message); process.exit(1); });

<# Starts the backend (port 8000) and the static frontend (port 8080), then opens the browser. #>
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$py = Join-Path $root "backend\.venv\Scripts\python.exe"
if (-not (Test-Path $py)) { throw "Run scripts\setup.ps1 first." }
Start-Process powershell -ArgumentList "-NoExit","-Command","Set-Location '$root\backend'; & '$py' -m uvicorn app.main:app --port 8000 --reload"
Start-Process powershell -ArgumentList "-NoExit","-Command","Set-Location '$root\frontend'; & '$py' -m http.server 8080"
Start-Sleep -Seconds 4
Start-Process "http://localhost:8080/index.html"
Write-Host "Backend docs: http://localhost:8000/api/v1/docs   Frontend: http://localhost:8080"

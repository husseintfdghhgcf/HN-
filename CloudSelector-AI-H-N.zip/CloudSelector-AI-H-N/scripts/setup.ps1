<#
 CloudSelector AI - one-time Windows setup (idempotent: safe to run again).
 Run from the project root:   powershell -ExecutionPolicy Bypass -File scripts\setup.ps1
 Options: -InstallPrerequisites (installs Python 3.12 + PostgreSQL 16 with winget)
          -SampleData           (loads clearly-labelled SAMPLE data, development only)
 This script never prints or stores your passwords anywhere except backend\.env (ignored by git).
#>
param([switch]$InstallPrerequisites, [switch]$SampleData)
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

function Find-Psql {
  $c = Get-Command psql -ErrorAction SilentlyContinue
  if ($c) { return $c.Source }
  $p = Get-ChildItem "C:\Program Files\PostgreSQL\*\bin\psql.exe" -ErrorAction SilentlyContinue | Sort-Object FullName -Descending | Select-Object -First 1
  if ($p) { return $p.FullName }
  return $null
}
function New-RandomString([int]$n) { -join ((48..57) + (65..90) + (97..122) | Get-Random -Count $n | ForEach-Object { [char]$_ }) }

Write-Host "== 1/7 Prerequisites" -ForegroundColor Cyan
if ($InstallPrerequisites) {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { throw "winget not found. Install Python 3.12 and PostgreSQL 16 manually, then re-run." }
  if (-not (Get-Command py -ErrorAction SilentlyContinue)) { winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements }
  if (-not (Find-Psql)) { winget install -e --id PostgreSQL.PostgreSQL.16 --accept-package-agreements --accept-source-agreements }
  Write-Host "If a command is still not found, close this window, open a new PowerShell and re-run the script." -ForegroundColor Yellow
}
if (-not (Get-Command py -ErrorAction SilentlyContinue)) { throw "Python launcher 'py' not found. Re-run with -InstallPrerequisites or install Python 3.12 from python.org." }
$psql = Find-Psql
if (-not $psql) { throw "psql not found. Re-run with -InstallPrerequisites or install PostgreSQL 16." }
Write-Host "Python: $(py --version)   psql: $psql"

Write-Host "== 2/7 Database" -ForegroundColor Cyan
$envFile = "backend\.env"
$dbName = "cloudselector"; $dbUser = "cs"
if (Test-Path $envFile) {
  Write-Host "backend\.env already exists: keeping it (delete it to regenerate)."
} else {
  $sec = Read-Host "PostgreSQL 'postgres' superuser password (typed during PostgreSQL installation)" -AsSecureString
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec)
  $env:PGPASSWORD = [Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
  [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
  $dbPass = New-RandomString 28
  try {
    $exists = & $psql -h localhost -U postgres -tAc "SELECT 1 FROM pg_roles WHERE rolname='$dbUser'"
    if ($LASTEXITCODE -ne 0) { throw "Could not connect to PostgreSQL. Is the service running and is the password correct?" }
    if ($exists -eq "1") { & $psql -h localhost -U postgres -c "ALTER ROLE $dbUser WITH LOGIN PASSWORD '$dbPass' CREATEDB" | Out-Null }
    else { & $psql -h localhost -U postgres -c "CREATE ROLE $dbUser WITH LOGIN PASSWORD '$dbPass' CREATEDB" | Out-Null }
    foreach ($d in @($dbName, "${dbName}_test")) {
      $has = & $psql -h localhost -U postgres -tAc "SELECT 1 FROM pg_database WHERE datname='$d'"
      if ($has -ne "1") { & $psql -h localhost -U postgres -c "CREATE DATABASE $d OWNER $dbUser" | Out-Null }
    }
  } finally { Remove-Item Env:\PGPASSWORD -ErrorAction SilentlyContinue }

  Write-Host "== 3/7 Writing backend\.env" -ForegroundColor Cyan
  $secret = (New-RandomString 64)
  $content = Get-Content "backend\.env.example" -Raw
  $content = $content -replace "(?m)^DATABASE_URL=.*$", "DATABASE_URL=postgresql+psycopg://${dbUser}:${dbPass}@localhost:5432/${dbName}"
  $content = $content -replace "(?m)^SECRET_KEY=.*$", "SECRET_KEY=$secret"
  [IO.File]::WriteAllText((Join-Path $root $envFile), $content, (New-Object Text.UTF8Encoding($false)))
}

Write-Host "== 4/7 Python environment" -ForegroundColor Cyan
Set-Location backend
if (-not (Test-Path ".venv")) { py -3.12 -m venv .venv; if ($LASTEXITCODE -ne 0) { py -m venv .venv } }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip | Out-Null
& .\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

Write-Host "== 5/7 Migrations" -ForegroundColor Cyan
& .\.venv\Scripts\python.exe -m alembic upgrade head
if ($LASTEXITCODE -ne 0) { throw "Migration failed. Check DATABASE_URL in backend\.env" }

Write-Host "== 6/7 Seed roles, criteria and pricing sources" -ForegroundColor Cyan
& .\.venv\Scripts\python.exe -m app.cli seed
if ($SampleData) { & .\.venv\Scripts\python.exe -m app.cli seed-sample }

Write-Host "== 7/7 First super administrator" -ForegroundColor Cyan
$ans = Read-Host "Create the first super administrator now? (y/n)"
if ($ans -eq "y") { & .\.venv\Scripts\python.exe -m app.cli bootstrap-admin }
Set-Location $root
Write-Host "`nDone. Start the app with:  powershell -ExecutionPolicy Bypass -File scripts\run.ps1" -ForegroundColor Green

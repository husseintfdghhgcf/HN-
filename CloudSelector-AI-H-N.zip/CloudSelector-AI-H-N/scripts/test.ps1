<# Runs the backend test suite against the separate *_test database (never your real data). #>
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location "$root\backend"
$line = (Get-Content .env | Where-Object { $_ -match "^DATABASE_URL=" } | Select-Object -First 1)
if (-not $line) { throw "DATABASE_URL not found in backend\.env" }
$url = $line.Substring("DATABASE_URL=".Length)
$env:DATABASE_URL = ($url -replace "/([^/]+)$", '/$1_test')
& .\.venv\Scripts\python.exe -m pytest tests -q -p no:warnings

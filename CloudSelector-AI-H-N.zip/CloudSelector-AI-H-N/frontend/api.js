/* CloudSelector AI — API client. Session lives in an HttpOnly cookie set by the server;
   this file never sees or stores credentials or the session token. */
(function () {
  var BASE = (window.CS_CONFIG && window.CS_CONFIG.API_BASE_URL) || "/api/v1";
  var CSRF_KEY = "cs-csrf";

  function cookie(name) {
    var m = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return m ? decodeURIComponent(m[1]) : "";
  }
  function csrf() {
    try {
      return sessionStorage.getItem(CSRF_KEY) || cookie("cs_csrf");
    } catch (e) {
      return cookie("cs_csrf");
    }
  }
  function setCsrf(token) {
    try {
      if (token) sessionStorage.setItem(CSRF_KEY, token);
      else sessionStorage.removeItem(CSRF_KEY);
    } catch (e) {
      /* ignore */
    }
  }

  function ApiError(status, message, detail) {
    this.status = status;
    this.message = message;
    this.detail = detail;
  }

  function request(method, path, body, extraHeaders) {
    var headers = { Accept: "application/json" };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (method !== "GET") headers["X-CSRF-Token"] = csrf();
    for (var k in extraHeaders || {}) headers[k] = extraHeaders[k];
    return fetch(BASE + path, {
      method: method,
      credentials: "include",
      headers: headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    }).then(
      function (res) {
        if (res.status === 204) return null;
        return res
          .json()
          .catch(function () {
            return {};
          })
          .then(function (data) {
            if (!res.ok) {
              var d = data && data.detail;
              var msg = typeof d === "string" ? d : (d && d.message) || "Request failed";
              throw new ApiError(res.status, msg, d);
            }
            return data;
          });
      },
      function () {
        throw new ApiError(0, "Cannot reach the server", null);
      }
    );
  }

  window.CS_API = {
    ApiError: ApiError,
    get: function (p) { return request("GET", p); },
    post: function (p, b, h) { return request("POST", p, b === undefined ? {} : b, h); },
    patch: function (p, b) { return request("PATCH", p, b); },
    del: function (p) { return request("DELETE", p); },
    login: function (email, password) {
      return request("POST", "/auth/login", { email: email, password: password }).then(function (r) {
        setCsrf(r.csrf_token);
        return r.user;
      });
    },
    me: function () {
      return request("GET", "/auth/me").then(function (r) {
        setCsrf(r.csrf_token);
        return r.user;
      });
    },
    logout: function () {
      return request("POST", "/auth/logout", {}).then(
        function () { setCsrf(""); },
        function () { setCsrf(""); }
      );
    },
    googleStartUrl: function () { return BASE + "/auth/google/start"; },
    googleConfigured: function () {
      return request("GET", "/auth/google/status").then(function (r) { return !!r.configured; });
    },
  };
})();

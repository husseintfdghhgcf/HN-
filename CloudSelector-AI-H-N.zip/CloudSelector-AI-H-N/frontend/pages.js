/* CloudSelector AI — Evaluate and Results pages.
   Every value that comes from the API is inserted with textContent (never innerHTML). */
(function () {
  "use strict";
  var page = document.body.dataset.page;
  if (page !== "evaluate" && page !== "results") return;

  var API = window.CS_API;
  var T = window.CS_T;
  var lang = function () {
    return window.CS_LANG();
  };

  /* ---------- helpers ---------- */
  function t(key, vars) {
    var s = T(key);
    for (var k in vars || {}) s = s.split("{" + k + "}").join(String(vars[k]));
    return s;
  }

  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      var v = attrs[k];
      if (v === false || v === null || v === undefined) return;
      if (k === "class") n.className = v;
      else if (k === "text") n.textContent = v;
      else if (k === "i18n") {
        n.setAttribute("data-i18n", v);
        n.textContent = T(v);
      } else if (k.slice(0, 2) === "on") n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? "" : String(v));
    });
    (kids || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      n.appendChild(typeof c === "string" || typeof c === "number" ? document.createTextNode(String(c)) : c);
    });
    return n;
  }

  function card(titleKey, subKey, body) {
    var c = el("section", { class: "cs-card" }, [el("h2", { i18n: titleKey })]);
    if (subKey) c.appendChild(el("p", { class: "cs-sub", i18n: subKey }));
    c.appendChild(el("div", { class: "cs-body" }, [].concat(body)));
    return c;
  }

  function badge(text, kind) {
    return el("span", { class: "cs-badge" + (kind ? " cs-badge-" + kind : ""), text: text });
  }

  function bar(fraction, signal) {
    var fill = el("div", { class: "cs-bar-fill" + (signal ? " is-signal" : "") });
    fill.style.width = Math.max(0, Math.min(100, fraction * 100)).toFixed(1) + "%";
    return el("div", { class: "cs-bar", role: "presentation" }, [fill]);
  }

  function table(headers, rows) {
    var thead = el("thead", {}, [el("tr", {}, headers.map(function (h) { return el("th", { scope: "col", text: h }); }))]);
    var tbody = el("tbody", {}, rows.map(function (r) {
      return el("tr", {}, r.map(function (c) { return el("td", {}, [c]); }));
    }));
    return el("div", { class: "cs-table-wrap" }, [el("table", { class: "cs-table" }, [thead, tbody])]);
  }

  function pct(x, d) {
    return (x * 100).toFixed(d === undefined ? 1 : d) + "%";
  }
  function num(x, d) {
    return typeof x === "number" ? x.toFixed(d === undefined ? 4 : d) : "—";
  }
  function when(iso) {
    if (!iso) return "—";
    var loc = lang() === "ar" ? "ar-IQ-u-nu-latn" : "en-GB";
    return new Date(iso).toLocaleString(loc, { dateStyle: "medium", timeStyle: "short" });
  }
  function cname(c) {
    return lang() === "ar" && c.name_ar ? c.name_ar : c.name_en || c.name;
  }

  function mainRoot() {
    var main = document.querySelector("main");
    var placeholder = main.querySelector(".border-dashed");
    var root = el("div", { class: "cs-stack" });
    if (placeholder) placeholder.replaceWith(root);
    else main.appendChild(root);
    return { main: main, root: root };
  }

  function showError(root, titleKey, message, extra) {
    var box = el("div", { class: "cs-alert is-error", role: "alert" }, [el("strong", { text: titleKey ? t(titleKey) : "" }), message]);
    if (extra) box.appendChild(extra);
    root.appendChild(box);
    return box;
  }

  /* =====================================================================
     EVALUATE
     ===================================================================== */
  function initEvaluate() {
    var ctx = mainRoot();
    var root = ctx.root;
    ctx.main.querySelector("h1").insertAdjacentElement("afterend", el("p", { class: "cs-lead", i18n: "ev.lead" }));

    var st = {
      criteria: [], providers: [], options: [], selected: {}, pairs: {}, chosen: {},
      profile: "", region: "", hours: 730, title: "", policy: "exclude_alternative",
      preview: null, previewError: "", previewState: "idle", busy: false, previewSeq: 0, timer: null,
    };

    var slots = {};
    function build() {
      root.textContent = "";
      slots.scenario = el("div");
      slots.criteria = el("div");
      slots.pairs = el("div", { class: "cs-grid cs-grid-2" });
      slots.preview = el("div");
      slots.providers = el("div");
      slots.actions = el("div");
      slots.error = el("div");

      var titleInput = el("input", { class: "cs-input", id: "ev-title", maxlength: "200", "data-i18n-placeholder": "ev.titlePh", placeholder: T("ev.titlePh"),
        oninput: function (e) { st.title = e.target.value; } });
      titleInput.value = st.title;

      var policy = el("select", { class: "cs-select", id: "ev-policy", onchange: function (e) { st.policy = e.target.value; } }, [
        el("option", { value: "exclude_alternative", i18n: "ev.policy.exclude" }),
        el("option", { value: "drop_criterion", i18n: "ev.policy.drop" }),
      ]);
      policy.value = st.policy;

      root.appendChild(card("ev.scenario", null, [
        el("div", { class: "cs-field", style: "margin-bottom:1rem" }, [el("label", { for: "ev-title", i18n: "ev.title" }), titleInput]),
        slots.scenario,
      ]));
      root.appendChild(card("ev.criteria", "ev.criteriaHint", [slots.criteria]));
      root.appendChild(el("div", { class: "cs-grid cs-grid-2" }, [
        card("ev.pairwise", "ev.pairwiseHint", [slots.pairs]),
        card("ev.weights", null, [slots.preview]),
      ]));
      root.appendChild(card("ev.providers", null, [slots.providers,
        el("div", { class: "cs-field", style: "margin-top:1rem" }, [el("label", { for: "ev-policy", i18n: "ev.policy" }), policy])]));
      root.appendChild(slots.error);
      root.appendChild(slots.actions);
      renderAll();
    }

    function selectedKeys() {
      return st.criteria.filter(function (c) { return st.selected[c.key]; }).map(function (c) { return c.key; });
    }
    function critByKey(k) {
      return st.criteria.filter(function (c) { return c.key === k; })[0];
    }
    function regionsFor(profile) {
      var p = st.options.filter(function (o) { return o.profile === profile; })[0];
      return p ? p.regions : [];
    }

    function renderScenario() {
      slots.scenario.textContent = "";
      if (!st.options.length) {
        slots.scenario.appendChild(el("div", { class: "cs-alert", i18n: "ev.noOptions" }));
        return;
      }
      var prof = el("select", { class: "cs-select", id: "ev-profile", onchange: function (e) {
        st.profile = e.target.value;
        st.region = (regionsFor(st.profile)[0] || {}).region || "";
        renderScenario();
      } }, st.options.map(function (o) { return el("option", { value: o.profile, text: o.profile }); }));
      prof.value = st.profile;
      var regs = regionsFor(st.profile);
      var reg = el("select", { class: "cs-select", id: "ev-region", onchange: function (e) { st.region = e.target.value; renderScenario(); } },
        regs.map(function (r) { return el("option", { value: r.region, text: r.region }); }));
      reg.value = st.region;
      var cur = regs.filter(function (r) { return r.region === st.region; })[0];
      var hours = el("input", { class: "cs-input", id: "ev-hours", type: "number", min: "1", max: "744", step: "1",
        oninput: function (e) { st.hours = Number(e.target.value); } });
      hours.value = st.hours;
      slots.scenario.appendChild(el("div", { class: "cs-grid cs-grid-2" }, [
        el("div", { class: "cs-field" }, [el("label", { for: "ev-profile", i18n: "ev.profile" }), prof]),
        el("div", { class: "cs-field" }, [el("label", { for: "ev-region", i18n: "ev.region" }), reg,
          cur ? el("span", { class: "cs-hint", text: t("ev.coverage", { n: cur.providers }) }) : null]),
        el("div", { class: "cs-field" }, [el("label", { for: "ev-hours", i18n: "ev.hours" }), hours, el("span", { class: "cs-hint", i18n: "ev.hoursHint" })]),
      ]));
    }

    function renderCriteria() {
      slots.criteria.textContent = "";
      slots.criteria.appendChild(el("div", { class: "cs-check-grid" }, st.criteria.map(function (c) {
        var input = el("input", { type: "checkbox", onchange: function (e) {
          st.selected[c.key] = e.target.checked;
          renderPairs();
          schedulePreview();
        } });
        input.checked = !!st.selected[c.key];
        return el("label", { class: "cs-check" }, [input, el("span", { class: "cs-grow", text: cname(c) }),
          badge(t(c.kind === "cost" ? "ev.kind.cost" : "ev.kind.benefit"), c.kind === "cost" ? "warning" : "success")]);
      })));
    }

    function pairKey(a, b) { return a + "|" + b; }
    function pairLabel(a, b, v) {
      if (v === 0) return t("ev.equal");
      var k = Math.abs(v) + 1;
      return t("ev.moreImportant", { a: cname(critByKey(v > 0 ? a : b)), n: k });
    }
    function buildMatrix(keys) {
      var n = keys.length;
      var m = [];
      for (var i = 0; i < n; i++) { m.push([]); for (var j = 0; j < n; j++) m[i].push(1); }
      for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) {
        var v = st.pairs[pairKey(keys[i], keys[j])] || 0;
        var k = Math.abs(v) + 1;
        m[i][j] = v >= 0 ? k : 1 / k;
        m[j][i] = v >= 0 ? 1 / k : k;
      }
      return m;
    }

    function renderPairs() {
      var keys = selectedKeys();
      slots.pairs.textContent = "";
      for (var i = 0; i < keys.length; i++) for (var j = i + 1; j < keys.length; j++) {
        (function (a, b) {
          var pk = pairKey(a, b);
          var label = el("div", { class: "cs-pair-label", "aria-live": "polite" });
          var slider = el("input", { class: "cs-slider", type: "range", min: "-8", max: "8", step: "1",
            "aria-label": cname(critByKey(a)) + " / " + cname(critByKey(b)),
            oninput: function (e) {
              st.pairs[pk] = Number(e.target.value);
              label.textContent = pairLabel(a, b, st.pairs[pk]);
              schedulePreview();
            } });
          slider.value = st.pairs[pk] || 0;
          label.textContent = pairLabel(a, b, st.pairs[pk] || 0);
          slots.pairs.appendChild(el("div", { class: "cs-pair" }, [
            el("div", { class: "cs-pair-names" }, [el("span", { text: cname(critByKey(a)) }), el("span", { text: "↔" }), el("span", { text: cname(critByKey(b)) })]),
            slider, label]));
        })(keys[i], keys[j]);
      }
    }

    function renderPreview() {
      slots.preview.textContent = "";
      var keys = selectedKeys();
      if (keys.length < 2) { slots.preview.appendChild(el("p", { class: "cs-sub", i18n: "ev.previewIdle" })); return; }
      if (st.previewState === "loading" && !st.preview) { slots.preview.appendChild(el("p", { class: "cs-sub", i18n: "ev.previewLoading" })); return; }
      if (st.previewError) { slots.preview.appendChild(el("div", { class: "cs-alert is-error", role: "alert", text: st.previewError })); return; }
      var p = st.preview;
      if (!p) return;
      p.criteria.forEach(function (k, i) {
        slots.preview.appendChild(el("div", { class: "cs-w-row" }, [el("span", { text: cname(critByKey(k)) }), bar(p.weights[i]), el("span", { text: pct(p.weights[i]) })]));
      });
      slots.preview.appendChild(el("div", { class: "cs-meta" }, [
        el("span", { text: t("ev.cr") + ": " + num(p.consistency_ratio, 3) }),
        badge(p.consistent ? t("ev.consistent") : t("ev.inconsistent"), p.consistent ? "success" : "danger"),
      ]));
    }

    function schedulePreview() {
      clearTimeout(st.timer);
      var keys = selectedKeys();
      if (keys.length < 2) { st.preview = null; st.previewError = ""; renderPreview(); return; }
      st.previewState = "loading";
      renderPreview();
      st.timer = setTimeout(function () {
        var seq = ++st.previewSeq;
        API.post("/ahp/preview", { criteria: keys, pairwise_matrix: buildMatrix(keys) }).then(function (r) {
          if (seq !== st.previewSeq) return;
          st.preview = r; st.previewError = ""; st.previewState = "ready"; renderPreview();
        }, function (err) {
          if (seq !== st.previewSeq) return;
          st.preview = null; st.previewError = err.message; st.previewState = "error"; renderPreview();
        });
      }, 300);
    }

    function renderProviders() {
      slots.providers.textContent = "";
      slots.providers.appendChild(el("div", { class: "cs-check-grid" }, st.providers.map(function (p) {
        var input = el("input", { type: "checkbox", onchange: function (e) { st.chosen[p.slug] = e.target.checked; } });
        input.checked = !!st.chosen[p.slug];
        return el("label", { class: "cs-check" }, [input, el("span", { class: "cs-grow", text: p.name })]);
      })));
    }

    function renderActions() {
      slots.actions.textContent = "";
      var btn = el("button", { class: "cs-btn", type: "button", onclick: submit, text: st.busy ? t("ev.running") : t("ev.run") });
      if (st.busy) btn.disabled = true;
      slots.actions.appendChild(el("div", { class: "cs-actions" }, [btn]));
    }

    function renderAll() { renderScenario(); renderCriteria(); renderPairs(); renderPreview(); renderProviders(); renderActions(); }

    function uuid() {
      return "ev-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
    }

    function submit() {
      slots.error.textContent = "";
      var keys = selectedKeys();
      var provs = st.providers.filter(function (p) { return st.chosen[p.slug]; }).map(function (p) { return p.slug; });
      var problem = null;
      if (keys.length < 2) problem = "ev.needTwo";
      else if (provs.length < 2) problem = "ev.needProviders";
      else if (!st.profile || !st.region || !(st.hours > 0 && st.hours <= 744)) problem = "ev.needScenario";
      if (problem) { showError(slots.error, "ev.errorTitle", t(problem)); return; }

      st.busy = true; renderActions();
      var body = {
        title: st.title.trim(), criteria: keys, pairwise_matrix: buildMatrix(keys), providers: provs, missing_policy: st.policy,
        requirements: { profile: st.profile, region: st.region, hours_per_month: st.hours },
      };
      API.post("/evaluations", body, { "Idempotency-Key": st.idemKey || (st.idemKey = uuid()) }).then(function (r) {
        location.href = "results.html?id=" + encodeURIComponent(r.id);
      }, function (err) {
        st.busy = false; renderActions(); st.idemKey = null;
        var extra = null, d = err.detail;
        if (d && typeof d === "object") {
          var items = [];
          if (d.ahp) items.push(t("ev.cr") + ": " + num(d.ahp.consistency_ratio, 3));
          Object.keys(d.excluded || {}).forEach(function (k) { items.push(k + ": " + d.excluded[k]); });
          if (items.length) extra = el("ul", { class: "cs-list" }, items.map(function (x) { return el("li", { text: x }); }));
        }
        showError(slots.error, "ev.errorTitle", err.status === 0 ? t("login.unreachable") : err.message, extra);
      });
    }

    document.addEventListener("cs:lang", function () { renderAll(); });

    Promise.all([API.get("/criteria"), API.get("/providers"), API.get("/pricing/options")]).then(function (res) {
      st.criteria = res[0].items.filter(function (c) { return c.is_active; });
      st.providers = res[1].items;
      st.options = res[2].profiles;
      st.providers.forEach(function (p) { st.chosen[p.slug] = true; });
      ["cost", "performance", "security"].forEach(function (k) { if (critByKey(k)) st.selected[k] = true; });
      if (st.options.length) { st.profile = st.options[0].profile; st.region = (st.options[0].regions[0] || {}).region || ""; }
      build();
      schedulePreview();
    }, function (err) {
      if (err.status === 401) return;
      showError(root, "ev.errorTitle", t("ev.loadError"));
    });
  }

  /* =====================================================================
     RESULTS
     ===================================================================== */
  function initResults() {
    var ctx = mainRoot();
    var root = ctx.root;
    var id = new URLSearchParams(location.search).get("id");
    var data = null;

    function actionsBar(extra) {
      return el("div", { class: "cs-actions" }, [el("a", { class: "cs-btn cs-btn-ghost", href: "evaluate.html", i18n: "rs.newEval" })].concat(extra || []));
    }

    /* ---- list view (no id) ---- */
    function renderList() {
      root.textContent = "";
      API.get("/evaluations?limit=20").then(function (r) {
        root.textContent = "";
        if (!r.items.length) {
          root.appendChild(el("div", { class: "cs-empty" }, [el("p", { i18n: "rs.none" }), el("p", {}, [el("a", { class: "cs-btn", href: "evaluate.html", i18n: "rs.start" })])]));
          return;
        }
        var rows = r.items.map(function (e) {
          return [e.title || e.id.slice(0, 8), when(e.created_at), e.top || "—",
            el("a", { class: "cs-btn cs-btn-ghost", href: "results.html?id=" + encodeURIComponent(e.id), text: t("rs.open") })];
        });
        root.appendChild(card("rs.recent", null, [table(["#", t("rs.created"), t("rs.leader"), ""], rows)]));
        root.appendChild(actionsBar());
      }, function (err) { if (err.status !== 401) showError(root, null, t("rs.loadError")); });
    }

    /* ---- detail view ---- */
    function render() {
      var ev = data.ev, ex = data.ex, crits = data.crit;
      root.textContent = "";
      var det = ex.deterministic;
      var names = {};
      ev.results.forEach(function (r) { names[r.provider] = r.provider_name; });
      var cmap = {};
      crits.forEach(function (c) { cmap[c.key] = c; });
      var cn = function (k) { return cmap[k] ? cname(cmap[k]) : k; };

      // header
      var head = el("div", { class: "cs-card" }, [
        el("h2", { text: ev.title || ev.id }),
        el("div", { class: "cs-meta" }, [
          el("span", { text: t("rs.created") + ": " + when(ev.created_at) }),
          el("span", { text: t("rs.method") + ": " + ev.algorithm_version }),
          el("span", { text: ev.requirements.profile + " · " + ev.requirements.region + " · " + ev.requirements.hours_per_month + "h" }),
        ]),
      ]);
      root.appendChild(head);

      var anySample = false;
      Object.keys(ev.decision_matrix.raw || {}).forEach(function (p) {
        Object.keys(ev.decision_matrix.raw[p]).forEach(function (c) { if (ev.decision_matrix.raw[p][c].is_sample) anySample = true; });
      });
      if (anySample) root.appendChild(el("div", { class: "cs-alert", role: "note", text: t("rs.sampleWarn") }));

      // ranking
      var rows = ev.results.map(function (r) {
        return [
          r.rank ? el("span", { class: "cs-rank" + (r.rank === 1 ? " is-first" : ""), text: r.rank }) : badge(t("rs.excluded"), "danger"),
          r.provider_name,
          r.closeness === null ? el("span", { class: "cs-muted", text: r.ineligible_reason }) :
            el("div", { style: "display:flex;align-items:center;gap:.75rem" }, [bar(r.closeness, true), el("span", { class: "cs-num", text: num(r.closeness) })]),
          r.d_plus === null ? "—" : num(r.d_plus) + " / " + num(r.d_minus),
        ];
      });
      root.appendChild(card("rs.ranking", null, [table([t("rs.rank"), t("rs.provider"), t("rs.closeness"), "D⁺ / D⁻"], rows)]));

      // explanation
      var expBody = [el("ul", { class: "cs-list" }, det.summary.map(function (s) { return el("li", { text: s }); }))];
      var drivers = det.drivers.filter(function (d) { return Math.abs(d.advantage) > 1e-9; });
      if (drivers.length) {
        expBody.push(el("p", { class: "cs-sub", style: "margin-top:1rem", i18n: "rs.drivers" }));
        expBody.push(table([t("rs.criterion"), "Δ"], drivers.map(function (d) {
          return [cn(d.criterion), el("span", { class: "cs-num", text: (d.advantage > 0 ? "+" : "") + d.advantage.toFixed(3) })];
        })));
      }
      var sw = det.providers.filter(function (p) { return p.strengths.length || p.weaknesses.length; });
      if (sw.length) {
        expBody.push(table([t("rs.provider"), t("rs.strengths"), t("rs.weaknesses")], sw.map(function (p) {
          return [p.name, p.strengths.map(cn).join(", ") || "—", p.weaknesses.map(cn).join(", ") || "—"];
        })));
      }
      if (lang() === "ar") expBody.push(el("p", { class: "cs-hint", style: "margin-top:.75rem", i18n: "rs.englishOnly" }));
      root.appendChild(card("rs.explanation", null, expBody));

      // weights + AHP stats
      var ahp = ev.ahp;
      var wBody = ahp.criteria.map(function (k, i) {
        return el("div", { class: "cs-w-row" }, [el("span", { text: cn(k) }), bar(ahp.weights[i]), el("span", { text: pct(ahp.weights[i]) })]);
      });
      wBody.push(el("div", { class: "cs-meta" }, [
        el("span", { text: t("rs.lambda") + " = " + num(ahp.lambda_max, 4) }), el("span", { text: "CI = " + num(ahp.consistency_index, 4) }),
        el("span", { text: "RI = " + ahp.random_index }), el("span", { text: "CR = " + num(ahp.consistency_ratio, 4) }),
        badge(ahp.consistent ? t("ev.consistent") : t("ev.inconsistent"), ahp.consistent ? "success" : "danger"),
      ]));
      root.appendChild(card("rs.weights", null, wBody));

      // measurements
      var raw = ev.decision_matrix.raw;
      var provs = Object.keys(raw);
      var mrows = [];
      provs.forEach(function (p) {
        ev.criteria_snapshot.forEach(function (c) {
          var m = raw[p][c.key] || {};
          mrows.push([names[p] || p, cn(c.key),
            m.value === null || m.value === undefined ? el("span", { class: "cs-muted", text: t("rs.missing") }) :
              el("span", { class: "cs-num", text: (Math.round(m.value * 1000) / 1000) + " " + (m.unit || "") }),
            el("span", {}, [m.source || "—", m.is_sample ? " " : null, m.is_sample ? badge(t("rs.sample"), "warning") : null]),
            when(m.timestamp)]);
        });
      });
      root.appendChild(card("rs.measurements", null, [table([t("rs.provider"), t("rs.criterion"), "", t("rs.source"), t("rs.timestamp")], mrows)]));

      // cost assumptions
      var ca = ev.cost_assumptions || {};
      if (Object.keys(ca).length) {
        root.appendChild(card("rs.assumptions", null, [el("p", { class: "cs-sub", i18n: "rs.formula" }),
          table([t("rs.provider"), "SKU", t("ev.region"), "USD/h", t("ev.hours")], Object.keys(ca).map(function (p) {
            var a = ca[p];
            return [names[p] || p, a.sku, a.region, a.unit_price + " " + a.currency + "/" + (a.price_unit || "hour"), String(a.hours_per_month)];
          }))]));
      }

      // uncertainty
      root.appendChild(card("rs.uncertainty", null, [det.uncertainty.length ?
        el("ul", { class: "cs-list" }, det.uncertainty.map(function (u) { return el("li", { text: u }); })) :
        el("p", { class: "cs-sub", i18n: "rs.noUncertainty" })]));

      // sensitivity
      var sens = ex.sensitivity;
      if (sens && sens.criteria && sens.criteria.length) {
        var srows = sens.criteria.map(function (c) {
          return [cn(c.criterion), pct(c.base_weight, 0)].concat(c.scenarios.map(function (s) {
            return el("span", { text: names[s.leader] || s.leader, style: s.leader_changed ? "font-weight:700" : "" });
          })).concat([c.robust ? badge(t("rs.robust"), "success") :
            badge(t("rs.flipsAt", { w: Math.round(c.leader_flip.weight * 100), p: names[c.leader_flip.new_leader] || c.leader_flip.new_leader }), "warning")]);
        });
        root.appendChild(card("rs.sensitivity", "rs.sensHint", [table(
          [t("rs.criterion"), t("rs.weight"), "−50%", "−25%", "+25%", "+50%", ""], srows)]));
      }

      // AI
      var aiBody = el("div");
      var aiCard = card("rs.ai", null, [aiBody]);
      function showAi(text) {
        aiBody.textContent = "";
        aiBody.appendChild(el("p", { class: "cs-ai-text", text: text }));
        aiBody.appendChild(el("p", { class: "cs-hint", i18n: "rs.aiLabel" }));
      }
      if (ex.ai && ex.ai.text) showAi(ex.ai.text);
      else if (data.aiAvailable) {
        var b = el("button", { class: "cs-btn", type: "button", text: t("rs.aiGenerate") });
        b.addEventListener("click", function () {
          b.disabled = true; b.textContent = t("rs.aiBusy");
          API.post("/evaluations/" + encodeURIComponent(ev.id) + "/ai-explanation").then(function (r) { showAi(r.text); },
            function (err) { b.disabled = false; b.textContent = t("rs.aiGenerate"); aiBody.appendChild(el("div", { class: "cs-alert is-error", role: "alert", text: err.message || t("rs.aiFailed") })); });
        });
        aiBody.appendChild(b);
      } else aiBody.appendChild(el("p", { class: "cs-sub", i18n: "rs.aiUnavailable" }));
      root.appendChild(aiCard);

      // actions
      var rb = el("button", { class: "cs-btn", type: "button", text: t("rs.report") });
      rb.addEventListener("click", function () {
        rb.disabled = true;
        API.post("/reports", { evaluation_id: ev.id }, { "Idempotency-Key": "rep-" + ev.id.slice(0, 40) }).then(function () {
          rb.disabled = false;
          var n = document.createElement("div"); n.className = "toast"; n.setAttribute("role", "status"); n.textContent = t("rs.reportDone");
          document.body.appendChild(n); setTimeout(function () { n.remove(); }, 3500);
        }, function () { rb.disabled = false; showError(root, null, t("rs.reportFailed")); });
      });
      root.appendChild(actionsBar([rb]));
    }

    function load() {
      root.textContent = "";
      Promise.all([
        API.get("/evaluations/" + encodeURIComponent(id)), API.get("/evaluations/" + encodeURIComponent(id) + "/explanation"),
        API.get("/criteria"), API.get("/ai/availability").then(function (r) { return r.available; }, function () { return false; }),
      ]).then(function (r) {
        data = { ev: r[0], ex: r[1], crit: r[2].items, aiAvailable: r[3] };
        render();
      }, function (err) {
        if (err.status === 401) return;
        showError(root, null, err.status === 404 ? t("rs.notFound") : t("rs.loadError"));
        root.appendChild(actionsBar());
      });
    }

    document.addEventListener("cs:lang", function () { if (data) render(); else if (!id) renderList(); });
    if (id) load(); else renderList();
  }

  if (page === "evaluate") initEvaluate();
  else initResults();
})();

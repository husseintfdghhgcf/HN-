/* CloudSelector AI — page behaviour (theme, language, login, menus, filters) */
(function () {
  "use strict";

  var ICONS = {
    eyeOff:
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye-off size-4" aria-hidden="true"><path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"></path><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"></path><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"></path><path d="m2 2 20 20"></path></svg>',
    eye: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye size-4" aria-hidden="true"><path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"></path><circle cx="12" cy="12" r="3"></circle></svg>',
    loader:
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-loader-circle size-4 animate-spin" aria-hidden="true"><path d="M21 12a9 9 0 1 1-6.219-8.56"></path></svg>',
    check:
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check size-4" aria-hidden="true"><path d="M20 6 9 17l-5-5"></path></svg>',
    sun: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sun size-4" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path></svg>',
    moon: '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-moon size-4" aria-hidden="true"><path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"></path></svg>',
    shield:
      '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield-check size-4" aria-hidden="true"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"></path><path d="m9 12 2 2 4-4"></path></svg>',
  };
  var PROFILE_KEY = "cs-demo-profile";
  var page = document.body.dataset.page;
  var html = document.documentElement;
  var lang = "en";

  /* ---------- helpers ---------- */
  function $(sel, root) {
    return (root || document).querySelector(sel);
  }
  function $all(sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }
  function t(key) {
    return (window.I18N[lang] && window.I18N[lang][key]) || key;
  }
  window.CS_T = t;
  window.CS_LANG = function () {
    return lang;
  };
  function read(store, key) {
    try {
      return store.getItem(key);
    } catch (e) {
      return null;
    }
  }
  function write(store, key, value) {
    try {
      store.setItem(key, value);
    } catch (e) {
      /* ignore */
    }
  }
  function on(sel, event, handler) {
    $all(sel).forEach(function (el) {
      el.addEventListener(event, handler);
    });
  }

  /* ---------- theme & language ---------- */
  function applyTheme(theme) {
    html.classList.toggle("dark", theme === "dark");
    write(localStorage, "cs-theme", theme);
    $all('[data-action="toggle-theme"]').forEach(function (b) {
      b.innerHTML = theme === "dark" ? ICONS.sun : ICONS.moon;
    });
  }

  function translate() {
    $all("[data-i18n]").forEach(function (el) {
      el.textContent = t(el.dataset.i18n);
    });
    ["placeholder", "aria-label", "title"].forEach(function (attr) {
      $all("[data-i18n-" + attr + "]").forEach(function (el) {
        el.setAttribute(attr, t(el.getAttribute("data-i18n-" + attr)));
      });
    });
  }

  function applyLang(next) {
    lang = next;
    html.lang = lang;
    html.dir = lang === "ar" ? "rtl" : "ltr";
    write(localStorage, "cs-lang", lang);
    translate();
    document.dispatchEvent(new CustomEvent("cs:lang", { detail: lang }));
  }

  var savedTheme = read(localStorage, "cs-theme");
  var savedLang = read(localStorage, "cs-lang");
  if (savedTheme === "dark") applyTheme("dark");
  if (savedLang === "ar") applyLang("ar");

  on('[data-action="toggle-theme"]', "click", function () {
    applyTheme(html.classList.contains("dark") ? "light" : "dark");
  });
  on('[data-action="toggle-lang"]', "click", function () {
    applyLang(lang === "en" ? "ar" : "en");
  });

  /* ---------- session ---------- */
  /* The profile cache is display-only (name/email/role). Authentication is the server's
     HttpOnly session cookie, verified with GET /auth/me on every protected page. */
  function getProfile() {
    var raw = read(sessionStorage, PROFILE_KEY);
    try {
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function cacheProfile(user) {
    write(
      sessionStorage,
      PROFILE_KEY,
      JSON.stringify({
        name: user.full_name || user.email.split("@")[0],
        email: user.email,
        role: user.role,
        organization: user.organization || "",
      })
    );
  }

  function logout() {
    window.CS_API.logout().then(function () {
      try {
        sessionStorage.removeItem(PROFILE_KEY);
      } catch (e) {
        /* ignore */
      }
      location.href = "index.html";
    });
  }

  /* ---------- toast ---------- */
  function toast(message) {
    var el = document.createElement("div");
    el.className = "toast";
    el.setAttribute("role", "status");
    el.textContent = message;
    document.body.appendChild(el);
    setTimeout(function () {
      el.remove();
    }, 3500);
  }

  /* ---------- modals ---------- */
  function openModal(name) {
    var m = $('[data-modal="' + name + '"]');
    if (!m) return;
    if (name === "drawer") syncDrawerNav();
    m.hidden = false;
    var input = $("input", m);
    if (input) {
      input.value = "";
      filterSearch("");
      input.focus();
    }
  }
  function closeModals() {
    $all(".modal").forEach(function (m) {
      m.hidden = true;
    });
  }

  function syncDrawerNav() {
    var side = $("aside nav");
    var drawerNav = $('[data-modal="drawer"] nav');
    if (side && drawerNav) drawerNav.innerHTML = side.innerHTML;
    translate();
  }

  on("[data-open-modal]", "click", function (e) {
    openModal(e.currentTarget.dataset.openModal);
  });
  on('[data-action="open-search"]', "click", function () {
    openModal("search");
  });
  on('[data-action="open-drawer"]', "click", function () {
    openModal("drawer");
  });

  $all(".modal").forEach(function (m) {
    m.addEventListener("click", function (e) {
      var overlay = e.target.classList.contains("bg-black/80") || e.target === m;
      var close = e.target.closest("[data-close]");
      var link = e.target.closest("a");
      if (overlay || close || link) closeModals();
    });
  });

  /* ---------- popups (notifications / profile) ---------- */
  function closePopups() {
    $all(".popup").forEach(function (p) {
      p.hidden = true;
    });
  }

  $all("[data-popup-trigger]").forEach(function (btn) {
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      var popup = $('[data-popup="' + btn.dataset.popupTrigger + '"]');
      var wasOpen = !popup.hidden;
      closePopups();
      if (wasOpen) return;
      var r = btn.getBoundingClientRect();
      popup.style.top = r.bottom + 4 + "px";
      if (html.dir === "rtl") {
        popup.style.left = r.left + "px";
        popup.style.right = "auto";
      } else {
        popup.style.right = window.innerWidth - r.right + "px";
        popup.style.left = "auto";
      }
      popup.hidden = false;
    });
  });
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".popup")) closePopups();
  });
  $all(".popup").forEach(function (p) {
    p.addEventListener("click", function (e) {
      var item = e.target.closest("[data-href], [data-action]");
      if (!item) return;
      if (item.dataset.action === "logout") logout();
      else if (item.dataset.href) location.href = item.dataset.href;
    });
  });

  /* ---------- command search ---------- */
  function filterSearch(q) {
    var modal = $('[data-modal="search"]');
    if (!modal) return;
    var shown = 0;
    $all("[cmdk-item]", modal).forEach(function (item) {
      var match = item.textContent.toLowerCase().indexOf(q.toLowerCase()) !== -1;
      item.hidden = !match;
      if (match) shown++;
    });
    $all("[cmdk-group]", modal).forEach(function (g) {
      g.hidden = !$all("[cmdk-item]:not([hidden])", g).length;
    });
    var empty = $("[data-empty]", modal);
    if (!empty) {
      empty = document.createElement("div");
      empty.setAttribute("data-empty", "");
      empty.className = "py-6 text-center text-sm";
      empty.setAttribute("data-i18n", "noResults");
      $("[cmdk-list]", modal).appendChild(empty);
      empty.textContent = t("noResults");
    }
    empty.hidden = shown > 0;
  }
  var searchInput = $('[data-modal="search"] input');
  if (searchInput)
    searchInput.addEventListener("input", function () {
      filterSearch(searchInput.value);
    });
  on("[cmdk-item]", "click", function (e) {
    location.href = e.currentTarget.dataset.href;
  });

  document.addEventListener("keydown", function (e) {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k" && $('[data-modal="search"]')) {
      e.preventDefault();
      var modal = $('[data-modal="search"]');
      if (modal.hidden) openModal("search");
      else closeModals();
    }
    if (e.key === "Escape") {
      closeModals();
      closePopups();
    }
  });

  /* ---------- sidebar ---------- */
  on('[data-action="toggle-sidebar"]', "click", function () {
    $("aside.sidebar").classList.toggle("is-collapsed");
  });

  /* ---------- logged-in pages ---------- */
  if (page !== "index") {
    var fillProfile = function (profile) {
      $all('[data-user="initials"]').forEach(function (el) {
        el.textContent = profile.name.slice(0, 2);
      });
      $all('[data-user="name"]').forEach(function (el) {
        el.textContent = profile.name;
      });
      $all('[data-user="meta"]').forEach(function (el) {
        el.textContent = profile.email + " · " + profile.role;
      });
      /* Role-based navigation is cosmetic only; the server enforces permissions on every API call. */
      if (profile.role === "customer") {
        $all('a[href="admin.html"], a[href="integrations.html"]').forEach(function (el) {
          el.hidden = true;
        });
      }
    };
    var cached = getProfile();
    if (cached) fillProfile(cached);
    window.CS_API.me().then(
      function (user) {
        cacheProfile(user);
        fillProfile(getProfile());
      },
      function (err) {
        if (err.status === 401 || !cached) {
          try {
            sessionStorage.removeItem(PROFILE_KEY);
          } catch (e) {
            /* ignore */
          }
          if (err.status === 401) location.replace("index.html");
          else toast(t("login.unreachable"));
        }
      }
    );
  }

  /* ---------- providers: filter ---------- */
  if (page === "providers") {
    var filter = $("main input");
    var cards = $all("main article");
    var grid = cards.length ? cards[0].parentElement : null;
    var noResult = document.createElement("div");
    noResult.className = "panel p-10 text-center text-sm text-muted-foreground";
    noResult.hidden = true;
    noResult.setAttribute("data-i18n", "noResults");
    noResult.textContent = t("noResults");
    if (grid) grid.parentElement.insertBefore(noResult, grid);
    filter.addEventListener("input", function () {
      var q = filter.value.toLowerCase();
      var visible = 0;
      cards.forEach(function (card) {
        var name = $("h2", card).textContent;
        var cats = $all(".flex-wrap > *", card)
          .map(function (b) {
            return b.textContent;
          })
          .join(" ");
        var match = (name + cats).toLowerCase().indexOf(q) !== -1;
        card.hidden = !match;
        if (match) visible++;
      });
      noResult.hidden = visible > 0;
    });
  }

  /* ---------- login page ---------- */
  if (page === "index") {
    window.CS_API.me().then(
      function () {
        location.replace("dashboard.html");
      },
      function () {
        /* not signed in: stay on the login page */
      }
    );
    var params = new URLSearchParams(location.search);
    var authError = params.get("auth_error");

    var form = $("#login-form");
    var idInput = $("#identifier");
    var pwInput = $("#password");
    var submit = $("[data-submit]");
    var remember = $('[data-action="toggle-remember"]');
    var phase = "idle";

    function setError(input, message) {
      var field = input.closest(".relative").parentElement;
      var old = $("[role=alert]", field);
      if (old) old.remove();
      input.setAttribute("aria-invalid", message ? "true" : "false");
      input.classList.toggle("border-destructive/70", !!message);
      input.classList.toggle("border-navy-foreground/15", !message);
      if (message) {
        var p = document.createElement("p");
        p.setAttribute("role", "alert");
        p.className = "mt-1.5 text-xs text-destructive animate-in fade-in slide-in-from-top-1";
        p.textContent = message;
        field.appendChild(p);
      }
    }

    function setPhase(next) {
      phase = next;
      submit.disabled = next === "loading" || next === "success";
      submit.classList.toggle("animate-[shake_.4s]", next === "error");
      if (next === "loading")
        submit.innerHTML = ICONS.loader + "<span>" + t("login.signing") + "</span>";
      else if (next === "success")
        submit.innerHTML = ICONS.check + "<span>" + t("login.success") + "</span>";
      else
        submit.innerHTML =
          ICONS.shield + '<span data-i18n="login.submit">' + t("login.submit") + "</span>";
    }

    remember.addEventListener("click", function () {
      var checked = remember.getAttribute("aria-checked") !== "true";
      remember.setAttribute("aria-checked", checked);
      remember.dataset.state = checked ? "checked" : "unchecked";
      remember.innerHTML = checked
        ? '<span data-state="checked" class="flex items-center justify-center text-current">' +
          ICONS.check +
          "</span>"
        : "";
    });

    $('[data-action="toggle-password"]').addEventListener("click", function (e) {
      var btn = e.currentTarget;
      var show = pwInput.type === "password";
      pwInput.type = show ? "text" : "password";
      btn.setAttribute("aria-label", show ? "Hide password" : "Show password");
      btn.innerHTML = show ? ICONS.eyeOff : ICONS.eye;
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var id = idInput.value.trim();
      var pw = pwInput.value;
      var idOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(id) && id.length <= 254;
      var pwOk = pw.length >= 1 && pw.length <= 128;
      setError(idInput, idOk ? "" : t("val.identifier"));
      setError(pwInput, pwOk ? "" : t("val.password"));
      if (!idOk || !pwOk) return;

      setPhase("loading");
      window.CS_API.login(id, pw).then(
        function (user) {
          cacheProfile(user);
          setPhase("success");
          setTimeout(function () {
            location.href = "dashboard.html";
          }, 500);
        },
        function (err) {
          setPhase("error");
          if (err.status === 0) toast(t("login.unreachable"));
          else if (err.status === 401) toast(t("login.error"));
          else toast(err.message);
          setTimeout(function () {
            setPhase("idle");
          }, 1600);
        }
      );
    });

    var googleBtn = $('[data-action="google-login"]');
    if (googleBtn) {
      window.CS_API.googleConfigured().then(
        function (ok) {
          googleBtn.hidden = !ok;
        },
        function () {
          googleBtn.hidden = true;
        }
      );
      googleBtn.addEventListener("click", function () {
        location.href = window.CS_API.googleStartUrl();
      });
    }
    if (authError) {
      var key = { google_cancelled: "login.googleCancelled", account_disabled: "login.disabled" }[authError] || "login.googleFailed";
      toast(t(key));
    }
  }
})();

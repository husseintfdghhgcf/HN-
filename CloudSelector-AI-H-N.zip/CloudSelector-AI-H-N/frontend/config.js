/* Deployment configuration. Contains NO secrets: only the public URL of the backend API. */
window.CS_CONFIG = {
  API_BASE_URL: "http://localhost:8000/api/v1",
};
